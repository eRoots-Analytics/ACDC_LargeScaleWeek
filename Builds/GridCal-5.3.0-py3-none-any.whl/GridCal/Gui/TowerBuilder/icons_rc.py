# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.6.2
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x0d\x94\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22g\
ear.svg\x22\x0d\x0a   ink\
scape:version=\x220\
.92.2 (5c3e80d, \
2017-08-06)\x22>\x0d\x0a \
 <metadata\x0d\x0a    \
 id=\x22metadata8\x22>\
\x0d\x0a    <rdf:RDF>\x0d\
\x0a      <cc:Work\x0d\
\x0a         rdf:ab\
out=\x22\x22>\x0d\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0d\x0a        <\
dc:type\x0d\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 />\x0d\x0a  \
      <dc:title \
/>\x0d\x0a      </cc:W\
ork>\x0d\x0a    </rdf:\
RDF>\x0d\x0a  </metada\
ta>\x0d\x0a  <defs\x0d\x0a  \
   id=\x22defs6\x22 />\
\x0d\x0a  <sodipodi:na\
medview\x0d\x0a     pa\
gecolor=\x22#ffffff\
\x22\x0d\x0a     borderco\
lor=\x22#666666\x22\x0d\x0a \
    borderopacit\
y=\x221\x22\x0d\x0a     obje\
cttolerance=\x2210\x22\
\x0d\x0a     gridtoler\
ance=\x2210\x22\x0d\x0a     \
guidetolerance=\x22\
10\x22\x0d\x0a     inksca\
pe:pageopacity=\x22\
0\x22\x0d\x0a     inkscap\
e:pageshadow=\x222\x22\
\x0d\x0a     inkscape:\
window-width=\x2278\
4\x22\x0d\x0a     inkscap\
e:window-height=\
\x22480\x22\x0d\x0a     id=\x22\
namedview4\x22\x0d\x0a   \
  showgrid=\x22fals\
e\x22\x0d\x0a     inkscap\
e:zoom=\x221.229166\
7\x22\x0d\x0a     inkscap\
e:cx=\x22-47.999997\
\x22\x0d\x0a     inkscape\
:cy=\x2296.000003\x22\x0d\
\x0a     inkscape:w\
indow-x=\x2257\x22\x0d\x0a  \
   inkscape:wind\
ow-y=\x2227\x22\x0d\x0a     \
inkscape:window-\
maximized=\x220\x22\x0d\x0a \
    inkscape:cur\
rent-layer=\x22svg2\
\x22 />\x0d\x0a  <path\x0d\x0a \
    style=\x22fill:\
#999999;stroke-w\
idth:1.33333337\x22\
\x0d\x0a     d=\x22m 77.6\
85212,176.62546 \
c -0.36495,-0.59\
051 -1.359378,-6\
.15571 -2.20984,\
-12.36712 -0.850\
46,-6.21142 -1.6\
47284,-11.29448 \
-1.77072,-11.295\
7 -0.292876,-0.0\
03 -8.928958,-4.\
7575 -11.737142,\
-6.46193 -1.6054\
74,-0.97444 -5.0\
33267,-0.14448 -\
13.016802,3.1516\
8 -6.691473,2.76\
271 -11.300681,3\
.99631 -12.04838\
1,3.22459 -2.638\
601,-2.72336 -17\
.422101,-29.3715\
3 -17.422101,-31\
.4044 0,-1.19223\
 3.885057,-5.095\
18 8.63346,-8.67\
324 l 8.63346,-6\
.50555 v -8.6666\
71 -8.666667 l -\
8.63346,-6.50555\
6 c -4.748403,-3\
.578056 -8.63346\
,-7.481016 -8.63\
346,-8.673242 0,\
-2.039252 14.787\
98,-28.686171 17\
.435789,-31.4180\
9 0.765807,-0.79\
0132 5.266256,0.\
388912 12.011621\
,3.146851 10.735\
632,4.389415 10.\
808082,4.399033 \
15.223394,2.0212\
32 9.226118,-4.9\
68593 9.854293,-\
5.918176 11.4033\
1,-17.237861 0.8\
02812,-5.866667 \
1.912158,-11.134\
266 2.465212,-11\
.705775 0.553056\
,-0.571509 9.357\
958,-0.871509 19\
.566452,-0.66666\
7 l 18.560886,0.\
372442 2,11.7414\
16 2,11.741416 6\
.3294,3.92525 c \
3.48117,2.158888\
 6.79253,3.92525\
1 7.35858,3.9252\
51 0.56605,0 5.4\
1918,-1.844483 1\
0.78474,-4.09885\
1 5.36556,-2.254\
369 10.45926,-3.\
828818 11.31934,\
-3.498777 2.0332\
4,0.780228 18.20\
794,29.028695 18\
.20794,31.799445\
 0,1.166222 -3.8\
8505,5.047904 -8\
.63345,8.62596 l\
 -8.63347,6.5055\
56 v 8.666667 8.\
666671 l 8.63347\
,6.50555 c 4.748\
4,3.57806 8.6334\
5,7.48101 8.6334\
5,8.67324 0,2.03\
287 -14.7835,28.\
68104 -17.4221,3\
1.4044 -0.74772,\
0.77174 -5.29872\
,-0.43786 -11.89\
703,-3.1621 l -1\
0.68606,-4.41197\
 -7.21862,3.7794\
4 -7.21861,3.779\
43 -1.77879,12.0\
4933 -1.77879,12\
.04933 -18.89906\
6,0.36932 c -10.\
394484,0.20314 -\
19.19766,-0.1138\
6 -19.562612,-0.\
7043 z m 29.5045\
08,-53.06908 c 1\
4.62521,-6.10929\
 21.57602,-23.26\
646 15.09602,-37\
.262594 -10.2021\
7,-22.03565 -40.\
74219,-22.03565 \
-50.944364,0 -10\
.329641,22.31097\
4 13.168754,46.7\
36394 35.848344,\
37.262594 z\x22\x0d\x0a  \
   id=\x22path817\x22\x0d\
\x0a     inkscape:c\
onnector-curvatu\
re=\x220\x22 />\x0d\x0a</svg\
>\x0d\x0a\
\x00\x00\x08\x85\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22d\
elete.svg\x22\x0d\x0a   i\
nkscape:version=\
\x220.92.2 (5c3e80d\
, 2017-08-06)\x22>\x0d\
\x0a  <metadata\x0d\x0a  \
   id=\x22metadata8\
\x22>\x0d\x0a    <rdf:RDF\
>\x0d\x0a      <cc:Wor\
k\x0d\x0a         rdf:\
about=\x22\x22>\x0d\x0a     \
   <dc:format>im\
age/svg+xml</dc:\
format>\x0d\x0a       \
 <dc:type\x0d\x0a     \
      rdf:resour\
ce=\x22http://purl.\
org/dc/dcmitype/\
StillImage\x22 />\x0d\x0a\
        <dc:titl\
e />\x0d\x0a      </cc\
:Work>\x0d\x0a    </rd\
f:RDF>\x0d\x0a  </meta\
data>\x0d\x0a  <defs\x0d\x0a\
     id=\x22defs6\x22 \
/>\x0d\x0a  <sodipodi:\
namedview\x0d\x0a     \
pagecolor=\x22#ffff\
ff\x22\x0d\x0a     border\
color=\x22#666666\x22\x0d\
\x0a     borderopac\
ity=\x221\x22\x0d\x0a     ob\
jecttolerance=\x221\
0\x22\x0d\x0a     gridtol\
erance=\x2210\x22\x0d\x0a   \
  guidetolerance\
=\x2210\x22\x0d\x0a     inks\
cape:pageopacity\
=\x220\x22\x0d\x0a     inksc\
ape:pageshadow=\x22\
2\x22\x0d\x0a     inkscap\
e:window-width=\x22\
784\x22\x0d\x0a     inksc\
ape:window-heigh\
t=\x22480\x22\x0d\x0a     id\
=\x22namedview4\x22\x0d\x0a \
    showgrid=\x22fa\
lse\x22\x0d\x0a     inksc\
ape:zoom=\x221.2291\
667\x22\x0d\x0a     inksc\
ape:cx=\x22-47.9999\
97\x22\x0d\x0a     inksca\
pe:cy=\x2296.000003\
\x22\x0d\x0a     inkscape\
:window-x=\x2257\x22\x0d\x0a\
     inkscape:wi\
ndow-y=\x2227\x22\x0d\x0a   \
  inkscape:windo\
w-maximized=\x220\x22\x0d\
\x0a     inkscape:c\
urrent-layer=\x22sv\
g2\x22 />\x0d\x0a  <path\x0d\
\x0a     style=\x22fil\
l:#999999;stroke\
-width:1.3333333\
7\x22\x0d\x0a     d=\x22M 44\
.01994,147.1665 \
38.367572,141.51\
412 60.68885,119\
.16384 83.010129\
,96.813559 60.68\
885,74.463272 38\
.367572,52.11298\
6 44.01994,46.46\
0618 49.672308,4\
0.80825 72.02259\
4,63.129528 94.3\
72885,85.450807 \
116.72318,63.129\
528 139.07346,40\
.80825 l 5.65238\
,5.652368 5.6523\
6,5.652368 -22.3\
2128,22.350286 -\
22.32128,22.3502\
87 22.32128,22.3\
50281 22.32128,2\
2.35028 -5.65236\
,5.65238 -5.6523\
8,5.65236 -22.35\
028,-22.32128 -2\
2.350295,-22.321\
27 -22.350291,22\
.32127 -22.35028\
6,22.32128 z\x22\x0d\x0a \
    id=\x22path817\x22\
\x0d\x0a     inkscape:\
connector-curvat\
ure=\x220\x22 />\x0d\x0a</sv\
g>\x0d\x0a\
\x00\x00\x08Y\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22e\
dit.svg\x22\x0d\x0a   ink\
scape:version=\x220\
.92.2 (5c3e80d, \
2017-08-06)\x22>\x0d\x0a \
 <metadata\x0d\x0a    \
 id=\x22metadata8\x22>\
\x0d\x0a    <rdf:RDF>\x0d\
\x0a      <cc:Work\x0d\
\x0a         rdf:ab\
out=\x22\x22>\x0d\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0d\x0a        <\
dc:type\x0d\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 />\x0d\x0a  \
      <dc:title \
/>\x0d\x0a      </cc:W\
ork>\x0d\x0a    </rdf:\
RDF>\x0d\x0a  </metada\
ta>\x0d\x0a  <defs\x0d\x0a  \
   id=\x22defs6\x22 />\
\x0d\x0a  <sodipodi:na\
medview\x0d\x0a     pa\
gecolor=\x22#ffffff\
\x22\x0d\x0a     borderco\
lor=\x22#666666\x22\x0d\x0a \
    borderopacit\
y=\x221\x22\x0d\x0a     obje\
cttolerance=\x2210\x22\
\x0d\x0a     gridtoler\
ance=\x2210\x22\x0d\x0a     \
guidetolerance=\x22\
10\x22\x0d\x0a     inksca\
pe:pageopacity=\x22\
0\x22\x0d\x0a     inkscap\
e:pageshadow=\x222\x22\
\x0d\x0a     inkscape:\
window-width=\x2218\
63\x22\x0d\x0a     inksca\
pe:window-height\
=\x221025\x22\x0d\x0a     id\
=\x22namedview4\x22\x0d\x0a \
    showgrid=\x22fa\
lse\x22\x0d\x0a     inksc\
ape:zoom=\x222.4583\
333\x22\x0d\x0a     inksc\
ape:cx=\x2225.8523\x22\
\x0d\x0a     inkscape:\
cy=\x22102.01301\x22\x0d\x0a\
     inkscape:wi\
ndow-x=\x2257\x22\x0d\x0a   \
  inkscape:windo\
w-y=\x2227\x22\x0d\x0a     i\
nkscape:window-m\
aximized=\x221\x22\x0d\x0a  \
   inkscape:curr\
ent-layer=\x22svg2\x22\
 />\x0d\x0a  <path\x0d\x0a  \
   style=\x22fill:#\
999999;stroke:#9\
99999;stroke-wid\
th:1.33333337\x22\x0d\x0a\
     d=\x22M 24.406\
78,148.92473 V 1\
33.91728 L 68.75\
4672,89.5842 113\
.10257,45.251123\
 l 14.97875,15.0\
21359 14.97874,1\
5.02136 -44.3339\
88,44.319178 -44\
.334,44.31918 H \
39.399422 24.406\
78 Z m 112.28181\
,-97.356802 -15.\
0515,-15.114105 \
8.60277,-8.26081\
1 c 5.40008,-5.1\
85426 9.73241,-8\
.260809 11.63711\
,-8.260809 4.221\
02,0 26.52981,22\
.334624 26.52981\
,26.560551 0,1.9\
57621 -3.01092,6\
.158632 -8.33333\
,11.627168 l -8.\
33334,8.562112 z\
\x22\x0d\x0a     id=\x22path\
817\x22\x0d\x0a     inksc\
ape:connector-cu\
rvature=\x220\x22 />\x0d\x0a\
</svg>\x0d\x0a\
\x00\x00\x04\xeb\
\x00\
\x00 Gx\xda\xed\x99[o\xdb6\x14\xc7\xdf\x0b\xf4\
;h\xcaK\x8bM\x14o\xe2E\xb3S`\x0b\x0a\xf4\
u\xeb\xb0gE\xa2m5\xb2hHJ\x9c\xf4\xd3\xef\
\xd0\xb6d\xdaN\x86z\x0e\xb0\x16\x90\x83\xc0\xe09\x87\
\xb7\xff\xef\xf0\xd0\xb2'\x1f\x1e\x97U\xf0`\x9a\xb6\xb4\
\xf54$\x08\x87\x81\xa9s[\x94\xf5|\x1a\xfe\xf5\xf9\
c\xa4\xc2\xa0\xed\xb2\xba\xc8*[\x9biX\xdb\xf0\xc3\
\xf5\xdb7\x93\x9f\xa2(\xf8\xbd1Yg\x8a`]v\
\x8b\xe0S}\xd7\xe6\xd9\xca\x04\xef\x16]\xb7J\xe3x\
\xbd^\xa3rgD\xb6\x99\xc7\xef\x83(\x82\xae\xd0\xb9\
}\x98\xbf}\x13\x04\x01\xcc]\xb7i\x91O\xc3]\x9f\
\xd5}Smb\x8b<6\x95Y\x9a\xbakc\x82H\
\x1cz\xf1\xf9>>w+(\x1fLn\x97K[\xb7\
\x9b\xaeu{\xe5G7\xc5l\x08wKZ\xb3M\x14\
\xd1Z\xc7\x98\xc6\x94F\x10\x11\xb5Ou\x97=FG\
}a\x9d\xcf\xf5\xa5\x18\xe3\x18|^\xe87\x86\xa5-\
(\xbb\x82\xff!\xbe7\xa0\xd6\xde7\xb9\x99AG\x83\
j\xd3\xc57\x9fo\x06g\x84Q\xd1\x15\xfe8\xbd\xb0\
\x07\xf3\x1e\xa8]gK\xd3\xae\xb2\xdc\xb4qo\xdf\x0e\
\xe0\xc1&[KYLCX'\xdd\xb6\xd6e\xd1-\
\xc0\xabw\xed\x85)\xe7\x8b\xce3<\x94f\xfd\x9b}\
\x9c\x868\xc0\x01X\x83\xc1\xd3\xaf7-l\xee\xe6\x9f\
\x86yV\xe5h\xd0\xa0_H:\xac\x01#M\x11\x0b\
\xdeQ\x8e\x93\x84\x8b_\x02\x8a\x89\x8a0\x8b\x08y\x1f\
^\xbbN\x93\xa5\xe9\xb2\x22\xeb\xb2\xcd\x08\xdb\xc5\xf6&\
\xb5\x0d\x81 `\x98\xfeq\xf3q\xd7\x04C\x9e\xa7\x7f\
\xdb\xe6\xaeo\xc3\xcb\x85d\xb7\xf6\x1e\xb6\x12^\xef\xed\
\x93\x22OA\xf5e\xd6]\x97\xcbln\x1c\xb1\x9fA\
\xe4I\xbcw\x1cFwO+\xe3\x8d\xbb\x1d\xb91[\
\x80\xcf\xa6r\x91/K\xd7+\xfe\xb3+\xab\xea\x93\x9b\
&\x0c\xe2\xe3a\xcb\xae2\x9eu\x12\xef\xf6\xd0\xef1\
\xf679\x89{\x11\xb6\xcd\xc2\xccZO!\xd7\x14\xfd\
\x1c\x93\x81\x8b\x83R8~\xbb\xd0\x15\xac$\xb7\x95m\
\xa6\xe1\xd5l\xf3\x0aw\x9e[\xdb\x14\xa6\xe9}b\xf3\
:\xf4YH.\xd8\x15$Fo\xb7\xb7_L\xdeu\
\xb62MV;)\x08\xee]\xf3\x06\xb2\xeaY\xc7}\
Y\x98g=C\xb2\xb8E\x0e\x93=\xefn\x17Ya\
\xd7\xd3\x90\x9ex\xd7e\x0d\x9e\xa8Oj%\xd8K!\
C\x9ec\x9a\x84\x9e\x94\x83f\xbc\xb7\xb6\x0b\xbbv\x1b\
\x9a\x86\xb3\xacj\xcd\xc9\x80_\xad]NC\x86\x98\xc6\
\xc2\x1b\xabw\xe7pt\x12\xc4h\x22\x95\xe6\xa7^\xa7\
(\xd6\x88\x09\xc9\xe5Kku#\xbc\xe8\x84\x01\xe8\x8b\
\xcee\xf6X.\xcb\xaf\xa6\xf0\xb8\xed\xe7\xbeo\x1a(\
\xb9Q\x95=\x99fW\x13\xfa\x1cj\x00m\xbf\xff\xee\
\xa9\x02T;&)\xf9u\x06Y\x9d^1\x99\xab\xec\
v\xd3\x88\xf6\xbe\xb6k\xec\x9d\x19\xbc\xdb\xe6\x96G*\
\xfafU\xd6\x06V\x906\xf6\xbe.|\xe3\x17[\xd6\
\xe9\xady0Uo\x85\x93d\x9a\x0a\xf6\xd0\xa5\xbc\xb7\
\x15\x19$@\xd3dOi\x0d\x97\x94o\xb5\xb3Yk\
\xba\x14\xf7\xb6\xfd\xbaVY\x09;\xddd2\xf4\x82c\
^\xf9\xd0\xddn\x15\x19\xd2\xa9O\x1fF\x91 \x98\x0c\
\xea\x0e9\x93h\xc4\x13\xb9O.\x00\xc4 \x01\x92D\
\xd3\xc1\xe6\xc0J\x84\x15\xf7\xc06\xce\xc8\x91\xe0\x1c\x0b\
u\x86\xd6\xdb\xc3\xfa\x82\xd6\xbe\x08[\xa1\x15\x12Xs\
A\xa4\xfa\xce\x15\xe7\xc7\x8aK\xc4\x99\xd6L\x9f*\x8e\
\xa8\xd4\x04D\xdb+\xce%\xd2\x9c\xc0E\xe2+\x8e1\
\x22\x02S\xea+N\x11\x16L\x88do|t\xd7\xa1\
\x16\x98+<b\x00\x0c\x11\xbb\x04\x84\xe4HI\xa8n\
\xf4\x08\x04\x83$\x1fA\x9c\x07B\x5c\x02\x02j\x15\x82\
A$;\x02\xc1\x13\xc6\xf9\x08\xe2,\x10\xf2\xd2\xd2$\
\xe1\xcf\xe7@\xe12Q#\x87\xb3+S\x94\x5cX\x9b\
\xc0\x22\xa88B\xa1\x18\xc6bDq^m\xba\xec\x9a\
\xd8T'\xa8D\xc9\x11\x0a-\x85\x90#\x8a\xb3P$\
\xaf]\x9d\xb8@\x84'\x9c\x8d\x1c\xce\xacN\xe2\xd5\xab\
\x13\xa0\xa0\x9a\xe2\xf1\xa28\xb7:\xd1W\xafN\x80\x82\
3%\xbe\x0b\x14T!B\x99\xe2\x9c$?\x00\x0b}\
\xcc\x02'\x90JJ\x9d\xb0\xa0\x02i\xca\x09\xe5~\x81\
\x12(!\x98)\xe9\xb1`\x18\x1e\x9b%\xc6\xdag\xc1\
\x10\xa0\xe0\x80\xf2\x80\x05\x80\x94Dq2\x1e\x0b@A\
.\xba) \xe7\x94P\x92{ \xa0fq\xa2\x12\xa2\
\xc6\xfat\xe6UqQ}\x92\x89;\xfe\x92\x90C\x14\
\x89H\x08\x1b\x1f\xb2\xcf-O\xf2\xb2\xab\xc2i\x8c\x93\
\xa3S\x01l$\xd3#\x8asQD\xf8\x22\x18TC\
\x8d\xd2\x89>\x84A\x19\x5c*\xe3G\xa8\xff\x00\xe3\xf4\
\xea>\x17\x07v\xe2\x1f}\x05\xa5\xb8\xde\x7f\xb4\xfa?\
q\x10\xf7\x99AK\xc9\x19\xfdAx|\xf3C7S\
\x88q-\xf7\xbfclx(\xa4\xa0V\xa9\x83\x87n\
\x06\x0f{\xe4\xf0Kr\xb8^\xa4\x16\x82\x8b\x7f\xe11\
q\xbf\x96\xc2\xfb?F\x09\x8b\x1d\
\x00\x00\x07\xdf\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22m\
inus.svg\x22\x0d\x0a   in\
kscape:version=\x22\
0.92.2 (5c3e80d,\
 2017-08-06)\x22>\x0d\x0a\
  <metadata\x0d\x0a   \
  id=\x22metadata8\x22\
>\x0d\x0a    <rdf:RDF>\
\x0d\x0a      <cc:Work\
\x0d\x0a         rdf:a\
bout=\x22\x22>\x0d\x0a      \
  <dc:format>ima\
ge/svg+xml</dc:f\
ormat>\x0d\x0a        \
<dc:type\x0d\x0a      \
     rdf:resourc\
e=\x22http://purl.o\
rg/dc/dcmitype/S\
tillImage\x22 />\x0d\x0a \
       <dc:title\
></dc:title>\x0d\x0a  \
    </cc:Work>\x0d\x0a\
    </rdf:RDF>\x0d\x0a\
  </metadata>\x0d\x0a \
 <defs\x0d\x0a     id=\
\x22defs6\x22 />\x0d\x0a  <s\
odipodi:namedvie\
w\x0d\x0a     pagecolo\
r=\x22#ffffff\x22\x0d\x0a   \
  bordercolor=\x22#\
666666\x22\x0d\x0a     bo\
rderopacity=\x221\x22\x0d\
\x0a     objecttole\
rance=\x2210\x22\x0d\x0a    \
 gridtolerance=\x22\
10\x22\x0d\x0a     guidet\
olerance=\x2210\x22\x0d\x0a \
    inkscape:pag\
eopacity=\x220\x22\x0d\x0a  \
   inkscape:page\
shadow=\x222\x22\x0d\x0a    \
 inkscape:window\
-width=\x221863\x22\x0d\x0a \
    inkscape:win\
dow-height=\x221025\
\x22\x0d\x0a     id=\x22name\
dview4\x22\x0d\x0a     sh\
owgrid=\x22false\x22\x0d\x0a\
     inkscape:zo\
om=\x221.7383042\x22\x0d\x0a\
     inkscape:cx\
=\x22-108.27277\x22\x0d\x0a \
    inkscape:cy=\
\x22209.44504\x22\x0d\x0a   \
  inkscape:windo\
w-x=\x2257\x22\x0d\x0a     i\
nkscape:window-y\
=\x2227\x22\x0d\x0a     inks\
cape:window-maxi\
mized=\x221\x22\x0d\x0a     \
inkscape:current\
-layer=\x22g831\x22 />\
\x0d\x0a  <g\x0d\x0a     id=\
\x22g831\x22\x0d\x0a     sty\
le=\x22stroke:#b3b3\
b3;stroke-lineca\
p:round\x22>\x0d\x0a    <\
path\x0d\x0a       sod\
ipodi:nodetypes=\
\x22cc\x22\x0d\x0a       ink\
scape:connector-\
curvature=\x220\x22\x0d\x0a \
      id=\x22path81\
2-3\x22\x0d\x0a       d=\x22\
m 134.96147,95.5\
94487 -79.795108\
,0.0945\x22\x0d\x0a      \
 style=\x22fill:non\
e;fill-rule:even\
odd;stroke:#b3b3\
b3;stroke-width:\
16;stroke-lineca\
p:round;stroke-l\
inejoin:miter;st\
roke-miterlimit:\
4;stroke-dasharr\
ay:none;stroke-o\
pacity:1\x22 />\x0d\x0a  \
</g>\x0d\x0a</svg>\x0d\x0a\
\x00\x00\x09&\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22p\
lus.svg\x22\x0d\x0a   ink\
scape:version=\x220\
.92.2 (5c3e80d, \
2017-08-06)\x22>\x0d\x0a \
 <metadata\x0d\x0a    \
 id=\x22metadata8\x22>\
\x0d\x0a    <rdf:RDF>\x0d\
\x0a      <cc:Work\x0d\
\x0a         rdf:ab\
out=\x22\x22>\x0d\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0d\x0a        <\
dc:type\x0d\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 />\x0d\x0a  \
      <dc:title \
/>\x0d\x0a      </cc:W\
ork>\x0d\x0a    </rdf:\
RDF>\x0d\x0a  </metada\
ta>\x0d\x0a  <defs\x0d\x0a  \
   id=\x22defs6\x22 />\
\x0d\x0a  <sodipodi:na\
medview\x0d\x0a     pa\
gecolor=\x22#ffffff\
\x22\x0d\x0a     borderco\
lor=\x22#666666\x22\x0d\x0a \
    borderopacit\
y=\x221\x22\x0d\x0a     obje\
cttolerance=\x2210\x22\
\x0d\x0a     gridtoler\
ance=\x2210\x22\x0d\x0a     \
guidetolerance=\x22\
10\x22\x0d\x0a     inksca\
pe:pageopacity=\x22\
0\x22\x0d\x0a     inkscap\
e:pageshadow=\x222\x22\
\x0d\x0a     inkscape:\
window-width=\x2218\
63\x22\x0d\x0a     inksca\
pe:window-height\
=\x221025\x22\x0d\x0a     id\
=\x22namedview4\x22\x0d\x0a \
    showgrid=\x22fa\
lse\x22\x0d\x0a     inksc\
ape:zoom=\x221.7383\
042\x22\x0d\x0a     inksc\
ape:cx=\x22-108.272\
77\x22\x0d\x0a     inksca\
pe:cy=\x22209.44504\
\x22\x0d\x0a     inkscape\
:window-x=\x2257\x22\x0d\x0a\
     inkscape:wi\
ndow-y=\x2227\x22\x0d\x0a   \
  inkscape:windo\
w-maximized=\x221\x22\x0d\
\x0a     inkscape:c\
urrent-layer=\x22sv\
g2\x22 />\x0d\x0a  <g\x0d\x0a  \
   id=\x22g831\x22\x0d\x0a  \
   style=\x22stroke\
:#b3b3b3;stroke-\
linecap:round\x22>\x0d\
\x0a    <path\x0d\x0a    \
   sodipodi:node\
types=\x22cc\x22\x0d\x0a    \
   inkscape:conn\
ector-curvature=\
\x220\x22\x0d\x0a       id=\x22\
path812\x22\x0d\x0a      \
 d=\x22m 95.091973,\
56.172243 0.0944\
7,79.795097\x22\x0d\x0a  \
     style=\x22fill\
:none;fill-rule:\
evenodd;stroke:#\
b3b3b3;stroke-wi\
dth:16;stroke-li\
necap:round;stro\
ke-linejoin:mite\
r;stroke-miterli\
mit:4;stroke-das\
harray:none;stro\
ke-opacity:1\x22 />\
\x0d\x0a    <path\x0d\x0a   \
    sodipodi:nod\
etypes=\x22cc\x22\x0d\x0a   \
    inkscape:con\
nector-curvature\
=\x220\x22\x0d\x0a       id=\
\x22path812-3\x22\x0d\x0a   \
    d=\x22m 134.961\
47,95.594487 -79\
.795108,0.0945\x22\x0d\
\x0a       style=\x22f\
ill:none;fill-ru\
le:evenodd;strok\
e:#b3b3b3;stroke\
-width:16;stroke\
-linecap:round;s\
troke-linejoin:m\
iter;stroke-mite\
rlimit:4;stroke-\
dasharray:none;s\
troke-opacity:1\x22\
 />\x0d\x0a  </g>\x0d\x0a</s\
vg>\x0d\x0a\
"

qt_resource_name = b"\
\x00\x05\
\x00O\xa6S\
\x00I\
\x00c\x00o\x00n\x00s\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x08\
\x0b\x85Wg\
\x00g\
\x00e\x00a\x00r\x00.\x00s\x00v\x00g\
\x00\x0a\
\x0c\xad\x02\x87\
\x00d\
\x00e\x00l\x00e\x00t\x00e\x00.\x00s\x00v\x00g\
\x00\x08\
\x0b\x07W\xa7\
\x00e\
\x00d\x00i\x00t\x00.\x00s\x00v\x00g\
\x00\x08\
\x08&W\xe7\
\x00c\
\x00a\x00l\x00c\x00.\x00s\x00v\x00g\
\x00\x09\
\x05\xc6\xb2\xc7\
\x00m\
\x00i\x00n\x00u\x00s\x00.\x00s\x00v\x00g\
\x00\x08\
\x03\xc6T'\
\x00p\
\x00l\x00u\x00s\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x10\x00\x02\x00\x00\x00\x06\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x94\x00\x00\x00\x00\x00\x01\x00\x00+P\
\x00\x00\x01\x8e4\x85\xff?\
\x00\x00\x00|\x00\x00\x00\x00\x00\x01\x00\x00#m\
\x00\x00\x01\x8e4\x85\xff?\
\x00\x00\x00f\x00\x01\x00\x00\x00\x01\x00\x00\x1e~\
\x00\x00\x01\x8e4\x85\xff=\
\x00\x00\x00P\x00\x00\x00\x00\x00\x01\x00\x00\x16!\
\x00\x00\x01\x8e4\x85\xff>\
\x00\x00\x00 \x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x8e4\x85\xff?\
\x00\x00\x006\x00\x00\x00\x00\x00\x01\x00\x00\x0d\x98\
\x00\x00\x01\x8e4\x85\xff>\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
