# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.6.2
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x09U\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22d\
elete3.svg\x22\x0d\x0a   \
inkscape:version\
=\x220.92.4 (unknow\
n)\x22>\x0d\x0a  <metadat\
a\x0d\x0a     id=\x22meta\
data8\x22>\x0d\x0a    <rd\
f:RDF>\x0d\x0a      <c\
c:Work\x0d\x0a        \
 rdf:about=\x22\x22>\x0d\x0a\
        <dc:form\
at>image/svg+xml\
</dc:format>\x0d\x0a  \
      <dc:type\x0d\x0a\
           rdf:r\
esource=\x22http://\
purl.org/dc/dcmi\
type/StillImage\x22\
 />\x0d\x0a        <dc\
:title />\x0d\x0a     \
 </cc:Work>\x0d\x0a   \
 </rdf:RDF>\x0d\x0a  <\
/metadata>\x0d\x0a  <d\
efs\x0d\x0a     id=\x22de\
fs6\x22 />\x0d\x0a  <sodi\
podi:namedview\x0d\x0a\
     pagecolor=\x22\
#ffffff\x22\x0d\x0a     b\
ordercolor=\x22#666\
666\x22\x0d\x0a     borde\
ropacity=\x221\x22\x0d\x0a  \
   objecttoleran\
ce=\x2210\x22\x0d\x0a     gr\
idtolerance=\x2210\x22\
\x0d\x0a     guidetole\
rance=\x2210\x22\x0d\x0a    \
 inkscape:pageop\
acity=\x220\x22\x0d\x0a     \
inkscape:pagesha\
dow=\x222\x22\x0d\x0a     in\
kscape:window-wi\
dth=\x221863\x22\x0d\x0a    \
 inkscape:window\
-height=\x221025\x22\x0d\x0a\
     id=\x22namedvi\
ew4\x22\x0d\x0a     showg\
rid=\x22false\x22\x0d\x0a   \
  inkscape:zoom=\
\x221.7383042\x22\x0d\x0a   \
  inkscape:cx=\x222\
8.86947\x22\x0d\x0a     i\
nkscape:cy=\x226.57\
51461\x22\x0d\x0a     ink\
scape:window-x=\x22\
57\x22\x0d\x0a     inksca\
pe:window-y=\x2227\x22\
\x0d\x0a     inkscape:\
window-maximized\
=\x221\x22\x0d\x0a     inksc\
ape:current-laye\
r=\x22g831\x22 />\x0d\x0a  <\
g\x0d\x0a     id=\x22g831\
\x22\x0d\x0a     style=\x22s\
troke:#37c8ab;st\
roke-width:21;st\
roke-miterlimit:\
4;stroke-dasharr\
ay:none\x22>\x0d\x0a    <\
path\x0d\x0a       ink\
scape:connector-\
curvature=\x220\x22\x0d\x0a \
      id=\x22path81\
2\x22\x0d\x0a       d=\x22M \
59.837063,61.191\
958 134.85037,13\
5.42536\x22\x0d\x0a      \
 style=\x22fill:non\
e;fill-rule:even\
odd;stroke:#ff80\
80;stroke-width:\
15.57077312;stro\
ke-linecap:round\
;stroke-linejoin\
:miter;stroke-mi\
terlimit:4;strok\
e-dasharray:none\
;stroke-opacity:\
1\x22\x0d\x0a       sodip\
odi:nodetypes=\x22c\
c\x22 />\x0d\x0a    <path\
\x0d\x0a       inkscap\
e:connector-curv\
ature=\x220\x22\x0d\x0a     \
  id=\x22path812-3\x22\
\x0d\x0a       d=\x22M 13\
3.89064,61.51186\
6 60.79679,135.1\
0545\x22\x0d\x0a       st\
yle=\x22fill:none;f\
ill-rule:evenodd\
;stroke:#ff8080;\
stroke-width:15.\
57077312;stroke-\
linecap:round;st\
roke-linejoin:mi\
ter;stroke-miter\
limit:4;stroke-d\
asharray:none;st\
roke-opacity:1\x22\x0d\
\x0a       sodipodi\
:nodetypes=\x22cc\x22 \
/>\x0d\x0a  </g>\x0d\x0a</sv\
g>\x0d\x0a\
\x00\x00\x0c\x92\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22d\
elete2.svg\x22\x0d\x0a   \
inkscape:version\
=\x220.92.3 (240554\
6, 2018-03-11)\x22>\
\x0d\x0a  <metadata\x0d\x0a \
    id=\x22metadata\
8\x22>\x0d\x0a    <rdf:RD\
F>\x0d\x0a      <cc:Wo\
rk\x0d\x0a         rdf\
:about=\x22\x22>\x0d\x0a    \
    <dc:format>i\
mage/svg+xml</dc\
:format>\x0d\x0a      \
  <dc:type\x0d\x0a    \
       rdf:resou\
rce=\x22http://purl\
.org/dc/dcmitype\
/StillImage\x22 />\x0d\
\x0a        <dc:tit\
le />\x0d\x0a      </c\
c:Work>\x0d\x0a    </r\
df:RDF>\x0d\x0a  </met\
adata>\x0d\x0a  <defs\x0d\
\x0a     id=\x22defs6\x22\
 />\x0d\x0a  <sodipodi\
:namedview\x0d\x0a    \
 pagecolor=\x22#fff\
fff\x22\x0d\x0a     borde\
rcolor=\x22#666666\x22\
\x0d\x0a     borderopa\
city=\x221\x22\x0d\x0a     o\
bjecttolerance=\x22\
10\x22\x0d\x0a     gridto\
lerance=\x2210\x22\x0d\x0a  \
   guidetoleranc\
e=\x2210\x22\x0d\x0a     ink\
scape:pageopacit\
y=\x220\x22\x0d\x0a     inks\
cape:pageshadow=\
\x222\x22\x0d\x0a     inksca\
pe:window-width=\
\x221853\x22\x0d\x0a     ink\
scape:window-hei\
ght=\x221025\x22\x0d\x0a    \
 id=\x22namedview4\x22\
\x0d\x0a     showgrid=\
\x22false\x22\x0d\x0a     in\
kscape:zoom=\x221.7\
383042\x22\x0d\x0a     in\
kscape:cx=\x22-105.\
16921\x22\x0d\x0a     ink\
scape:cy=\x226.5751\
461\x22\x0d\x0a     inksc\
ape:window-x=\x2267\
\x22\x0d\x0a     inkscape\
:window-y=\x2227\x22\x0d\x0a\
     inkscape:wi\
ndow-maximized=\x22\
1\x22\x0d\x0a     inkscap\
e:current-layer=\
\x22g831\x22 />\x0d\x0a  <g\x0d\
\x0a     id=\x22g831\x22\x0d\
\x0a     style=\x22str\
oke:#37c8ab;stro\
ke-width:21;stro\
ke-miterlimit:4;\
stroke-dasharray\
:none\x22>\x0d\x0a    <g\x0d\
\x0a       id=\x22g858\
\x22\x0d\x0a       transf\
orm=\x22translate(-\
336.53488,3.4516\
398)\x22>\x0d\x0a      <p\
ath\x0d\x0a         so\
dipodi:nodetypes\
=\x22cc\x22\x0d\x0a         \
style=\x22fill:none\
;fill-rule:eveno\
dd;stroke:#ff808\
0;stroke-width:1\
5.57077312;strok\
e-linecap:round;\
stroke-linejoin:\
miter;stroke-mit\
erlimit:4;stroke\
-dasharray:none;\
stroke-opacity:1\
\x22\x0d\x0a         d=\x22M\
 58.686516,34.15\
4113 133.69982,1\
08.38751\x22\x0d\x0a     \
    id=\x22path812\x22\
\x0d\x0a         inksc\
ape:connector-cu\
rvature=\x220\x22 />\x0d\x0a\
      <path\x0d\x0a   \
      sodipodi:n\
odetypes=\x22cc\x22\x0d\x0a \
        style=\x22f\
ill:none;fill-ru\
le:evenodd;strok\
e:#ff8080;stroke\
-width:15.570773\
12;stroke-lineca\
p:round;stroke-l\
inejoin:miter;st\
roke-miterlimit:\
4;stroke-dasharr\
ay:none;stroke-o\
pacity:1\x22\x0d\x0a     \
    d=\x22M 132.740\
09,34.474021 59.\
646243,108.0676\x22\
\x0d\x0a         id=\x22p\
ath812-3\x22\x0d\x0a     \
    inkscape:con\
nector-curvature\
=\x220\x22 />\x0d\x0a    </g\
>\x0d\x0a    <path\x0d\x0a  \
     inkscape:co\
nnector-curvatur\
e=\x220\x22\x0d\x0a       id\
=\x22path812-7\x22\x0d\x0a  \
     d=\x22M 48.209\
069,89.302145 12\
3.22237,163.5355\
4\x22\x0d\x0a       style\
=\x22fill:none;fill\
-rule:evenodd;st\
roke:#ff8080;str\
oke-width:15.570\
77312;stroke-lin\
ecap:round;strok\
e-linejoin:miter\
;stroke-miterlim\
it:4;stroke-dash\
array:none;strok\
e-opacity:1\x22\x0d\x0a  \
     sodipodi:no\
detypes=\x22cc\x22 />\x0d\
\x0a    <path\x0d\x0a    \
   inkscape:conn\
ector-curvature=\
\x220\x22\x0d\x0a       id=\x22\
path812-3-5\x22\x0d\x0a  \
     d=\x22M 122.26\
264,89.622055 49\
.168796,163.2156\
3\x22\x0d\x0a       style\
=\x22fill:none;fill\
-rule:evenodd;st\
roke:#ff8080;str\
oke-width:15.570\
77312;stroke-lin\
ecap:round;strok\
e-linejoin:miter\
;stroke-miterlim\
it:4;stroke-dash\
array:none;strok\
e-opacity:1\x22\x0d\x0a  \
     sodipodi:no\
detypes=\x22cc\x22 />\x0d\
\x0a  </g>\x0d\x0a</svg>\x0d\
\x0a\
\x00\x00\x079\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<svg\x0d\x0a   \
xmlns:dc=\x22http:/\
/purl.org/dc/ele\
ments/1.1/\x22\x0d\x0a   \
xmlns:cc=\x22http:/\
/creativecommons\
.org/ns#\x22\x0d\x0a   xm\
lns:rdf=\x22http://\
www.w3.org/1999/\
02/22-rdf-syntax\
-ns#\x22\x0d\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0d\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0d\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0d\x0a   width=\x2248\x22\x0d\
\x0a   height=\x2248\x22\x0d\
\x0a   viewBox=\x220 0\
 48 48\x22\x0d\x0a   vers\
ion=\x221.1\x22\x0d\x0a   id\
=\x22svg4\x22\x0d\x0a   sodi\
podi:docname=\x22ac\
cept.svg\x22\x0d\x0a   in\
kscape:version=\x22\
0.92.3 (2405546,\
 2018-03-11)\x22>\x0d\x0a\
  <metadata\x0d\x0a   \
  id=\x22metadata10\
\x22>\x0d\x0a    <rdf:RDF\
>\x0d\x0a      <cc:Wor\
k\x0d\x0a         rdf:\
about=\x22\x22>\x0d\x0a     \
   <dc:format>im\
age/svg+xml</dc:\
format>\x0d\x0a       \
 <dc:type\x0d\x0a     \
      rdf:resour\
ce=\x22http://purl.\
org/dc/dcmitype/\
StillImage\x22 />\x0d\x0a\
      </cc:Work>\
\x0d\x0a    </rdf:RDF>\
\x0d\x0a  </metadata>\x0d\
\x0a  <defs\x0d\x0a     i\
d=\x22defs8\x22 />\x0d\x0a  \
<sodipodi:namedv\
iew\x0d\x0a     pageco\
lor=\x22#ffffff\x22\x0d\x0a \
    bordercolor=\
\x22#666666\x22\x0d\x0a     \
borderopacity=\x221\
\x22\x0d\x0a     objectto\
lerance=\x2210\x22\x0d\x0a  \
   gridtolerance\
=\x2210\x22\x0d\x0a     guid\
etolerance=\x2210\x22\x0d\
\x0a     inkscape:p\
ageopacity=\x220\x22\x0d\x0a\
     inkscape:pa\
geshadow=\x222\x22\x0d\x0a  \
   inkscape:wind\
ow-width=\x221853\x22\x0d\
\x0a     inkscape:w\
indow-height=\x2210\
25\x22\x0d\x0a     id=\x22na\
medview6\x22\x0d\x0a     \
showgrid=\x22false\x22\
\x0d\x0a     inkscape:\
zoom=\x222.4583333\x22\
\x0d\x0a     inkscape:\
cx=\x22-184.4643\x22\x0d\x0a\
     inkscape:cy\
=\x2239.302561\x22\x0d\x0a  \
   inkscape:wind\
ow-x=\x2267\x22\x0d\x0a     \
inkscape:window-\
y=\x2227\x22\x0d\x0a     ink\
scape:window-max\
imized=\x221\x22\x0d\x0a    \
 inkscape:curren\
t-layer=\x22svg4\x22 /\
>\x0d\x0a  <path\x0d\x0a    \
 style=\x22fill:#00\
d4aa;fill-rule:e\
venodd;stroke:#0\
0d4aa;stroke-wid\
th:1.15240359px;\
stroke-linecap:b\
utt;stroke-linej\
oin:miter;stroke\
-opacity:1\x22\x0d\x0a   \
  d=\x22M 4.1877492\
,25.155303 15.67\
2719,39.687308 4\
5.908665,13.9047\
18 41.455309,10.\
857686 17.079041\
,29.139883 8.875\
4915,23.748979 Z\
\x22\x0d\x0a     id=\x22path\
815\x22\x0d\x0a     inksc\
ape:connector-cu\
rvature=\x220\x22 />\x0d\x0a\
</svg>\x0d\x0a\
\x00\x00\x0a\xb1\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<svg\x0d\x0a   \
xmlns:dc=\x22http:/\
/purl.org/dc/ele\
ments/1.1/\x22\x0d\x0a   \
xmlns:cc=\x22http:/\
/creativecommons\
.org/ns#\x22\x0d\x0a   xm\
lns:rdf=\x22http://\
www.w3.org/1999/\
02/22-rdf-syntax\
-ns#\x22\x0d\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0d\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0d\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0d\x0a   width=\x2248\x22\x0d\
\x0a   height=\x2248\x22\x0d\
\x0a   viewBox=\x220 0\
 48 48\x22\x0d\x0a   vers\
ion=\x221.1\x22\x0d\x0a   id\
=\x22svg4\x22\x0d\x0a   sodi\
podi:docname=\x22ac\
cept2.svg\x22\x0d\x0a   i\
nkscape:version=\
\x220.92.3 (2405546\
, 2018-03-11)\x22>\x0d\
\x0a  <metadata\x0d\x0a  \
   id=\x22metadata1\
0\x22>\x0d\x0a    <rdf:RD\
F>\x0d\x0a      <cc:Wo\
rk\x0d\x0a         rdf\
:about=\x22\x22>\x0d\x0a    \
    <dc:format>i\
mage/svg+xml</dc\
:format>\x0d\x0a      \
  <dc:type\x0d\x0a    \
       rdf:resou\
rce=\x22http://purl\
.org/dc/dcmitype\
/StillImage\x22 />\x0d\
\x0a      </cc:Work\
>\x0d\x0a    </rdf:RDF\
>\x0d\x0a  </metadata>\
\x0d\x0a  <defs\x0d\x0a     \
id=\x22defs8\x22 />\x0d\x0a \
 <sodipodi:named\
view\x0d\x0a     pagec\
olor=\x22#ffffff\x22\x0d\x0a\
     bordercolor\
=\x22#666666\x22\x0d\x0a    \
 borderopacity=\x22\
1\x22\x0d\x0a     objectt\
olerance=\x2210\x22\x0d\x0a \
    gridtoleranc\
e=\x2210\x22\x0d\x0a     gui\
detolerance=\x2210\x22\
\x0d\x0a     inkscape:\
pageopacity=\x220\x22\x0d\
\x0a     inkscape:p\
ageshadow=\x222\x22\x0d\x0a \
    inkscape:win\
dow-width=\x221853\x22\
\x0d\x0a     inkscape:\
window-height=\x221\
025\x22\x0d\x0a     id=\x22n\
amedview6\x22\x0d\x0a    \
 showgrid=\x22false\
\x22\x0d\x0a     inkscape\
:zoom=\x226.3333333\
\x22\x0d\x0a     inkscape\
:cx=\x2226.339228\x22\x0d\
\x0a     inkscape:c\
y=\x2250.577833\x22\x0d\x0a \
    inkscape:win\
dow-x=\x2267\x22\x0d\x0a    \
 inkscape:window\
-y=\x2227\x22\x0d\x0a     in\
kscape:window-ma\
ximized=\x221\x22\x0d\x0a   \
  inkscape:curre\
nt-layer=\x22svg4\x22 \
/>\x0d\x0a  <path\x0d\x0a   \
  style=\x22fill:#0\
0d4aa;fill-rule:\
evenodd;stroke:#\
00d4aa;stroke-wi\
dth:0.73550624px\
;stroke-linecap:\
butt;stroke-line\
join:miter;strok\
e-opacity:1\x22\x0d\x0a  \
   d=\x22M 2.255002\
2,35.606185 9.58\
51314,44.881044 \
28.882821,28.425\
649 26.040526,26\
.480922 10.48269\
8,38.14929 5.246\
8912,34.708618 Z\
\x22\x0d\x0a     id=\x22path\
815\x22\x0d\x0a     inksc\
ape:connector-cu\
rvature=\x220\x22 />\x0d\x0a\
  <g\x0d\x0a     style\
=\x22stroke:#37c8ab\
;stroke-width:21\
;stroke-miterlim\
it:4;stroke-dash\
array:none\x22\x0d\x0a   \
  id=\x22g858\x22\x0d\x0a   \
  transform=\x22mat\
rix(0.22597714,0\
,0,0.22597714,-8\
.857672,-3.39504\
78)\x22>\x0d\x0a    <path\
\x0d\x0a       sodipod\
i:nodetypes=\x22cc\x22\
\x0d\x0a       style=\x22\
fill:none;fill-r\
ule:evenodd;stro\
ke:#ff8080;strok\
e-width:15.57077\
312;stroke-linec\
ap:round;stroke-\
linejoin:miter;s\
troke-miterlimit\
:4;stroke-dashar\
ray:none;stroke-\
opacity:1\x22\x0d\x0a    \
   d=\x22M 58.68651\
6,34.154113 133.\
69982,108.38751\x22\
\x0d\x0a       id=\x22pat\
h812\x22\x0d\x0a       in\
kscape:connector\
-curvature=\x220\x22 /\
>\x0d\x0a    <path\x0d\x0a  \
     sodipodi:no\
detypes=\x22cc\x22\x0d\x0a  \
     style=\x22fill\
:none;fill-rule:\
evenodd;stroke:#\
ff8080;stroke-wi\
dth:15.57077312;\
stroke-linecap:r\
ound;stroke-line\
join:miter;strok\
e-miterlimit:4;s\
troke-dasharray:\
none;stroke-opac\
ity:1\x22\x0d\x0a       d\
=\x22M 132.74009,34\
.474021 59.64624\
3,108.0676\x22\x0d\x0a   \
    id=\x22path812-\
3\x22\x0d\x0a       inksc\
ape:connector-cu\
rvature=\x220\x22 />\x0d\x0a\
  </g>\x0d\x0a</svg>\x0d\x0a\
\
"

qt_resource_name = b"\
\x00\x05\
\x00O\xa6S\
\x00I\
\x00c\x00o\x00n\x00s\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x0a\
\x0c\xad\x02\x87\
\x00d\
\x00e\x00l\x00e\x00t\x00e\x00.\x00s\x00v\x00g\
\x00\x0b\
\x0aP\xdfG\
\x00d\
\x00e\x00l\x00e\x00t\x00e\x002\x00.\x00s\x00v\x00g\
\x00\x0a\
\x0c{\xa9\xe7\
\x00a\
\x00c\x00c\x00e\x00p\x00t\x00.\x00s\x00v\x00g\
\x00\x0b\
\x07\xbaiG\
\x00a\
\x00c\x00c\x00e\x00p\x00t\x002\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x10\x00\x02\x00\x00\x00\x04\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00p\x00\x00\x00\x00\x00\x01\x00\x00\x1d,\
\x00\x00\x01\x8e4\x85\xff7\
\x00\x00\x00:\x00\x00\x00\x00\x00\x01\x00\x00\x09Y\
\x00\x00\x01\x8e4\x85\xff9\
\x00\x00\x00V\x00\x00\x00\x00\x00\x01\x00\x00\x15\xef\
\x00\x00\x01\x8e4\x85\xff6\
\x00\x00\x00 \x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x8e4\x85\xff7\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
