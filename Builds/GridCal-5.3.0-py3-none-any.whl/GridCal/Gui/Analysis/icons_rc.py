# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.7.2
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x0dZ\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22g\
ear.svg\x22\x0a   inks\
cape:version=\x220.\
92.2 (5c3e80d, 2\
017-08-06)\x22>\x0a  <\
metadata\x0a     id\
=\x22metadata8\x22>\x0a  \
  <rdf:RDF>\x0a    \
  <cc:Work\x0a     \
    rdf:about=\x22\x22\
>\x0a        <dc:fo\
rmat>image/svg+x\
ml</dc:format>\x0a \
       <dc:type\x0a\
           rdf:r\
esource=\x22http://\
purl.org/dc/dcmi\
type/StillImage\x22\
 />\x0a        <dc:\
title />\x0a      <\
/cc:Work>\x0a    </\
rdf:RDF>\x0a  </met\
adata>\x0a  <defs\x0a \
    id=\x22defs6\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0a     bordercolo\
r=\x22#666666\x22\x0a    \
 borderopacity=\x22\
1\x22\x0a     objectto\
lerance=\x2210\x22\x0a   \
  gridtolerance=\
\x2210\x22\x0a     guidet\
olerance=\x2210\x22\x0a  \
   inkscape:page\
opacity=\x220\x22\x0a    \
 inkscape:pagesh\
adow=\x222\x22\x0a     in\
kscape:window-wi\
dth=\x22784\x22\x0a     i\
nkscape:window-h\
eight=\x22480\x22\x0a    \
 id=\x22namedview4\x22\
\x0a     showgrid=\x22\
false\x22\x0a     inks\
cape:zoom=\x221.229\
1667\x22\x0a     inksc\
ape:cx=\x22-47.9999\
97\x22\x0a     inkscap\
e:cy=\x2296.000003\x22\
\x0a     inkscape:w\
indow-x=\x2257\x22\x0a   \
  inkscape:windo\
w-y=\x2227\x22\x0a     in\
kscape:window-ma\
ximized=\x220\x22\x0a    \
 inkscape:curren\
t-layer=\x22svg2\x22 /\
>\x0a  <path\x0a     s\
tyle=\x22fill:#9999\
99;stroke-width:\
1.33333337\x22\x0a    \
 d=\x22m 77.685212,\
176.62546 c -0.3\
6495,-0.59051 -1\
.359378,-6.15571\
 -2.20984,-12.36\
712 -0.85046,-6.\
21142 -1.647284,\
-11.29448 -1.770\
72,-11.2957 -0.2\
92876,-0.003 -8.\
928958,-4.7575 -\
11.737142,-6.461\
93 -1.605474,-0.\
97444 -5.033267,\
-0.14448 -13.016\
802,3.15168 -6.6\
91473,2.76271 -1\
1.300681,3.99631\
 -12.048381,3.22\
459 -2.638601,-2\
.72336 -17.42210\
1,-29.37153 -17.\
422101,-31.4044 \
0,-1.19223 3.885\
057,-5.09518 8.6\
3346,-8.67324 l \
8.63346,-6.50555\
 v -8.666671 -8.\
666667 l -8.6334\
6,-6.505556 c -4\
.748403,-3.57805\
6 -8.63346,-7.48\
1016 -8.63346,-8\
.673242 0,-2.039\
252 14.78798,-28\
.686171 17.43578\
9,-31.41809 0.76\
5807,-0.790132 5\
.266256,0.388912\
 12.011621,3.146\
851 10.735632,4.\
389415 10.808082\
,4.399033 15.223\
394,2.021232 9.2\
26118,-4.968593 \
9.854293,-5.9181\
76 11.40331,-17.\
237861 0.802812,\
-5.866667 1.9121\
58,-11.134266 2.\
465212,-11.70577\
5 0.553056,-0.57\
1509 9.357958,-0\
.871509 19.56645\
2,-0.666667 l 18\
.560886,0.372442\
 2,11.741416 2,1\
1.741416 6.3294,\
3.92525 c 3.4811\
7,2.158888 6.792\
53,3.925251 7.35\
858,3.925251 0.5\
6605,0 5.41918,-\
1.844483 10.7847\
4,-4.098851 5.36\
556,-2.254369 10\
.45926,-3.828818\
 11.31934,-3.498\
777 2.03324,0.78\
0228 18.20794,29\
.028695 18.20794\
,31.799445 0,1.1\
66222 -3.88505,5\
.047904 -8.63345\
,8.62596 l -8.63\
347,6.505556 v 8\
.666667 8.666671\
 l 8.63347,6.505\
55 c 4.7484,3.57\
806 8.63345,7.48\
101 8.63345,8.67\
324 0,2.03287 -1\
4.7835,28.68104 \
-17.4221,31.4044\
 -0.74772,0.7717\
4 -5.29872,-0.43\
786 -11.89703,-3\
.1621 l -10.6860\
6,-4.41197 -7.21\
862,3.77944 -7.2\
1861,3.77943 -1.\
77879,12.04933 -\
1.77879,12.04933\
 -18.899066,0.36\
932 c -10.394484\
,0.20314 -19.197\
66,-0.11386 -19.\
562612,-0.7043 z\
 m 29.504508,-53\
.06908 c 14.6252\
1,-6.10929 21.57\
602,-23.26646 15\
.09602,-37.26259\
4 -10.20217,-22.\
03565 -40.74219,\
-22.03565 -50.94\
4364,0 -10.32964\
1,22.310974 13.1\
68754,46.736394 \
35.848344,37.262\
594 z\x22\x0a     id=\x22\
path817\x22\x0a     in\
kscape:connector\
-curvature=\x220\x22 /\
>\x0a</svg>\x0a\
\x00\x00\x0b\x1a\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   version\
=\x221.1\x22\x0a   id=\x22sv\
g2\x22\x0a   width=\x2219\
2\x22\x0a   height=\x2219\
2\x22\x0a   viewBox=\x220\
 0 192 192\x22\x0a   s\
odipodi:docname=\
\x22fix.svg\x22\x0a   ink\
scape:version=\x221\
.2.1 (9c6d41e410\
, 2022-07-14)\x22\x0a \
  xml:space=\x22pre\
serve\x22\x0a   xmlns:\
inkscape=\x22http:/\
/www.inkscape.or\
g/namespaces/ink\
scape\x22\x0a   xmlns:\
sodipodi=\x22http:/\
/sodipodi.source\
forge.net/DTD/so\
dipodi-0.dtd\x22\x0a  \
 xmlns=\x22http://w\
ww.w3.org/2000/s\
vg\x22\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0a  \
 xmlns:rdf=\x22http\
://www.w3.org/19\
99/02/22-rdf-syn\
tax-ns#\x22\x0a   xmln\
s:cc=\x22http://cre\
ativecommons.org\
/ns#\x22\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22><metadata\x0a \
    id=\x22metadata\
8\x22><rdf:RDF><cc:\
Work\x0a         rd\
f:about=\x22\x22><dc:f\
ormat>image/svg+\
xml</dc:format><\
dc:type\x0a        \
   rdf:resource=\
\x22http://purl.org\
/dc/dcmitype/Sti\
llImage\x22 /><dc:t\
itle /></cc:Work\
></rdf:RDF></met\
adata><defs\x0a    \
 id=\x22defs6\x22 /><s\
odipodi:namedvie\
w\x0a     pagecolor\
=\x22#ffffff\x22\x0a     \
bordercolor=\x22#66\
6666\x22\x0a     borde\
ropacity=\x221\x22\x0a   \
  objecttoleranc\
e=\x2210\x22\x0a     grid\
tolerance=\x2210\x22\x0a \
    guidetoleran\
ce=\x2210\x22\x0a     ink\
scape:pageopacit\
y=\x220\x22\x0a     inksc\
ape:pageshadow=\x22\
2\x22\x0a     inkscape\
:window-width=\x221\
464\x22\x0a     inksca\
pe:window-height\
=\x22794\x22\x0a     id=\x22\
namedview4\x22\x0a    \
 showgrid=\x22false\
\x22\x0a     inkscape:\
zoom=\x221.2291667\x22\
\x0a     inkscape:c\
x=\x22-49.220338\x22\x0a \
    inkscape:cy=\
\x2234.57627\x22\x0a     \
inkscape:window-\
x=\x2262\x22\x0a     inks\
cape:window-y=\x222\
7\x22\x0a     inkscape\
:window-maximize\
d=\x220\x22\x0a     inksc\
ape:current-laye\
r=\x22svg2\x22\x0a     in\
kscape:showpages\
hadow=\x222\x22\x0a     i\
nkscape:pagechec\
kerboard=\x220\x22\x0a   \
  inkscape:deskc\
olor=\x22#d1d1d1\x22 /\
><path\x0a     styl\
e=\x22fill:#6f918a;\
fill-opacity:1;s\
troke-width:0.30\
0662\x22\x0a     d=\x22m \
36.340703,171.79\
795 c -3.97833,-\
0.71265 -8.7795,\
-3.60044 -11.327\
78,-6.81336 -5.0\
9529,-6.42425 -5\
.71619,-14.92478\
 -1.60584,-21.98\
497 0.73721,-1.2\
663 9.07821,-9.8\
0866 32.50674,-3\
3.29153 l 31.515\
08,-31.588162 -0\
.33671,-0.883283\
 c -0.80447,-2.1\
10379 -1.80535,-\
7.121939 -2.0956\
9,-10.493515 -1.\
9458,-22.595466 \
13.81048,-43.360\
566 36.196807,-4\
7.703547 4.45104\
,-0.863513 9.795\
38,-1.033616 14.\
16305,-0.4508 4.\
0845,0.545031 7.\
46795,1.429469 8\
.55027,2.235047 \
1.91852,1.427959\
 2.6303,3.88839 \
1.67657,5.795394\
 -0.28248,0.5648\
35 -5.18274,5.70\
9943 -10.88947,1\
1.433565 l -10.3\
7586,10.4066 2.2\
1995,7.775444 2.\
21994,7.775449 7\
.7694,2.218221 7\
.76939,2.218216 \
10.71331,-10.679\
652 c 9.31022,-9\
.280966 10.86097\
,-10.706897 11.8\
4079,-10.887715 \
1.5796,-0.291501\
 3.05707,0.05105\
 4.13604,0.95894\
7 1.21065,1.0186\
91 1.60481,1.843\
738 2.34724,4.91\
3136 2.40487,9.9\
42484 1.14429,21\
.012323 -3.43052\
,30.125085 -8.37\
487,16.682302 -2\
5.5031,26.3756 -\
43.95811,24.8770\
1 -3.20737,-0.26\
044 -9.95924,-1.\
66471 -10.9509,-\
2.27759 -0.1642,\
-0.10148 -14.523\
95,14.02179 -31.\
910567,31.38504 \
-34.03679,33.991\
04 -32.69591,32.\
76088 -37.43377,\
34.3429 -2.21742\
,0.74042 -6.8441\
9,1.03568 -9.309\
36,0.59407 z\x22\x0a  \
   id=\x22path300\x22 \
/></svg>\x0a\
\x00\x00\x08L\
\x00\
\x00\x1d\xa9x\xda\xedYY\x8f\xdb\xc8\x11~\xf7\xaf \
8/\x1eD\xa4\xfa>4\xd2,\x12\x18\x8b\x0d\xb0A\
\x80]{s\xbc\x04\x1c\xb2\xa5\xe1\x0eE\x0aMJ\x9a\
\xf1\xafO5\xc5S\xa2\xc6c\xac\xb3@\x90\xc8\xb0\xad\
\xae\xea\xa3\xce\xaf\xaa[\xcb\xef\x9e\xb7\x99w0\xb6L\
\x8b|\xe5\xe3\x10\xf9\x9e\xc9\xe3\x22I\xf3\xcd\xca\xff\xf4\
\xf1\xfb@\xf9^YEy\x12eEnV~^\xf8\
\xdf\xdd\xbf[\x96\x87\xcd;\xcf\xf3\x8eiR=\xae|\
\xa6|7z4\xe9\xe6\xb1\xea\x86\x87\xd4\x1c\xffT<\
\xaf|\xe4!\x8f)\xaf!\xa7\xc9\xca\x87\xe5\xe44\xa7\
?\x19\x9f\xb8\xf9S\x19G;\xb3\x18r\xbc\xf7\xb1P\
\x86\x90\x98*9\xf3\x08\x228@< \xf4\xb6^R\
\x82\xb4;\xf8\xbbH\x8a8\x8f\xb6 d\x9a\xef\xf6U\
\xf9\xaf(\x8f\xb2\x972-=\x12\xc2\x81\xf5\x5c\xd06\
/\x17\xed!+\xff\xb1\xaav\x8b\xf9\xfcx<\x86-\
1,\xecf\xee\xf6)wQl\xcayK\x1f\xaco\
O\xec\xd6\xb7\x84\xb0,\xf666k\xd8\xc2\x84\xb9\xa9\
\xe6\x1f>~\xe8\x98\x01\x0a\x93*\xe9\xb7\x19\x9d~\xa4\
\xf5\xb9\x04!4\x1f\x0b\x0b\xa37\xce\xb4\xc9zj&\
\xd6Z\xcf\x11\x99\x13\x12\xc0\x8c\xa0|\xc9\xab\xe89\xc8\
\xcb\x9b\xc1\xd28\xeeV\xc6\xd6DUz0q\xb1\xdd\
\x16yy2\xc7hr\xd2O\xde\xedmV\xcfH\xe2\
\xb9\xc9\xcc\xd6\xe4U9\x07\x8f\xcd\xfd{\x98\xbf\xdc\x9a\
*J\xa2*rkO\x9eo)\x98\xd43`\x0e\xc8\
\xb4\xf8\xe9\xc3\xf7\xa7\x11\x8c\xe3x\xf1\xb7\xc2>5C\
\xf8\xb8\x09\xd1C\xb1\x87\xc8\xf2\xef;\xf22\x89\x17`\
\xe7mT\xdd\xa7\xdbhc\x9c-\xfe\x00\xf2-\xe7=\
c4\xb9z\xd9\x99~\xd3\xd3\xb6\xd6\x9c\x1c6\xa9O\
\x12oS\xb7h\xfes\x95f\xd9\x9f\xdd!\xbe7\xef\
\xe4\x9c7\x826j\xcc\x07z,\xe7\xad\x9a\xf5(1\
\xeb\xb2\xb7\x80\x1ba\xd4j\xbf\x8d\xec\x93\xb1\xad\x5c]\
\xf4\x97U\x11?\xb9\xd9\x7f\xb4\xb68\xe2\x1f!\x05m\
\xe5\xb7\xd3\x0a\x9b\x82\xa1W~\xb4\xaf\x8a\x8eh\xcd\xfa\
\x1f\x90k\x90\xc1\x03\xca\xdf\xc7\x94\xab;\x96\xd5K\x06\
V( \xeb\xd6Yq\x5c\x1c\xd22}\xc8\x8c\x7f!\
XZ\xd6\xa2\xad\xfc\xca\xeeM\xe7\x8e\xe5.\xaa\x1e{\
\xe3\xbac\x1c\x85q\xad\xfc\x9e\x0c\xd4\xbfx \xce\x0c\
\xfez?z\x1c\xbe\x05\xbc\xfe\x1a`\x12\xf2\x01\xf9D\
m\xa7~\xf6\x06\x9b4\x92\xae\xc1%\x81\xddgfa\
\x0e&/\x92\xe4\xae\xacl\xf1d\x167\xa8\xfe4\xc3\
\xa0F\xa8\x05\xe0\xda\xae\x1alR\xd9(/]\x90\x00\
\x14\xc5Qf\xde\xa3P\xdd\x9e\xa8YT\x99\xf7'q\
n;w\x83Ck?5#\xd0\xad26o\xf7k\
\x86\x9f\xf2\xb4\x82\xa4\xde\x97\xc6\xfe\xec\xa0\xe3\xaf\xf9\xa7\
\xb2\xb7`\x03\x954\xa4\x88\x11ID\xc7\xe8P3\xd4\
\x5c\x0b\x8czN\xb3\xef\xc7^\xd8^B\x19\x0a\xc1\xb5\
\x96|\xa6CF%l\xaanGnn\x16\xbb9\xbd\
\x9b*\xf3\x5c\xf5V\x80lY\xd4 \x07\xb3!\x13\x8c\
=\x98\x09C\x17y\x15\xd4\xdf\x17\xb9\xcb\xaa\xec\xae\xa6\
\x1ck\xa9G\xa42\xfdl\x16\x22\xe4\x5cR\xb2{\xbe\
\xcb\xd2\xdc\x04'\xe5\xc0\xfe\x84\x9f&\xad\xa3m\x9a\xbd\
,J\xd0#\x80\x13\xd3\xf5\x9d\xf3\xe4\xe2\xe6\x81\xba?\
\xf5 (@&\xc8\xbc\x05n}\x9aC\xe9\x19;\x14\
\x85XPM\xe9@^(4\x80\xb0\x8c\x12\xc2\x98\x16\
\x03\xc6\x8b\xb3\xad\x12Br\xa9\xfdq\x90:{`.\
\x85\x7f\xbf\xac\xc0\x12\xf9\x10\x1f\xba\xb2b\x0bg\x07\xa7\
\x8e?\xe4\xd7\xeb\xdd\x22\xd8\x80\x8d8\x83\x10}]\xb1\
\xeb\xca\xbc\xa2\xce\x99B\xf7h9\xaf\xc5\xb8\x87\xffA\
\x9d6`\x1b\xff\x9f\xe0\xc8aN\xfd\xadS\xca\x15\xb8\
\xc4U\xe8wM\xa8m\x00\xf0\xb3\xc2\xae\xfc\x9bu\xfd\
iN|(lbl\xcb\x12\xf5g\xc4jt\x82:\
\xdd\x90\x8b\x87_M\x5cU`4\x08V\x17[\xb8\xc5\
\x9f\x8d\x05u\xa7\xe8\xfb41S\x8c\x0eu\x9cx\xdd\
A\x93\xdc\xf21J\x8a\xe3\xca'\xe7\xccc\x9a\x03#\
h\xd2\x0f+\xae\xae\xcch\xf3\x10#.\xfd\x1e\xae;\
C\xb5\xeb\xca\xc7\xe2\xe84\x01\x07GY\x97\xe0\xddn\
\x9f\x8b\x02\x12\x15\xd3\x90\x13\xa4:\x9fv\xec\x18\xfcJ\
5\x80\x80\x96\xe8B\x92\x18\xb4\xa38\x14\x1a+\xca\xae\
\x88\x09\xeb\xf95\x1e,\x0f\xae\xa9\xb7\x8d\x9e\xd3-d\
h\xd2{\xaa?wo-\x14\x94 \x8b^\x0c\xb8y\
\x83\x09\x9f4r\xfchb@\xc1\x87\x22\xb2\x89\xf3\xc3\
\x09\x1e\x97\x9b\xdeZ\x1b\x86yW\xdb6C<\xda0\
\xce\xd8\x97\x0b\x06E\x17\x05c\x86\xbc\x1f\x5c\xff\xf8\x8b\
\xfb\xe7\x07\xe8%\xff9\xcc\xe2N\x87\x22\xcf!\xee\x0a\
\x1b\x806\x87\xa8\xda[\xd3\x87\xcayV:@\x19\xd6\
\xf2\xcdX\x94\x8dFx\xbaZ@Wa\xd3\xe7\xf7P\
O$\xd5D\xb3\x19H7\xebGB\x87\xd0lq\xcc\
gD\x86X\x11M\xf1\xed\xb0g\xb1 \xe15\xa4\x18\
\x80\xdc\xe2F\xd7\x9f1L@HQ\xc5\x90\x14\xbc\xa5\
;L\x02\xe5\x01\xa1\xf6y2$\xfeZ\xa4\xf9\x98\x0a\
\xad\x8c\xb1\x19D@\xb5`--\x89 k\xac\x8d^\
F\x00\xdb\x81\xd4\x05\xda9\xe95\x1bcQ[\xd6D\
((\x15z\x0c\x84mJQ\x1eb\xaa\xe8\x19L:\
\x84\x13(\x94\x12i\xca\xcf\x01.\xc0:\x84$\x80U\
#\x8e\x05\x16\x0f\xa9\x96\x9a\x0b6\xf0\xe0\xd8\x87\x8d\x17\
%\xd3r\xb4\xba\x9a\xaa\xa4(\xe4\x0a\xd2\x11a=t\
\xd5\xf9\x86\xcd\x96\x83\xcc\xb8\x1e\x1d4D\x08#@\xee\
::\xa0\x95\xe0\x1a\x11\xc4g\x18\x83\x1d\xa4\xc2\xcaE\
\x87@\x9a\x102>\xf2\x22/\xc6\xb6\x17\x08a\xff\x9c\
y%\x84\xba\xd2\xa2\xa4\xd2\x9a^,s\xad\xb8\x17p\
\xe9\x84\xa3J\xcc\x02,C\x821b\xda{\x84\xfb\x92\
F\x8cQ\xea\x1d<\x16R\x0e>\x17@\x0d:\xf2\xe7\
\x91\xe5_\x95\x1b\xba!\x09\xed\xc9\x7f\xa7\xd8\xfc?'\
6\x0a\x85\x84b\x84'\xc5\xa6\xfc7\xc9\xad\xbe\xb5\xdc\
8\xa4\x0c1,'\xe5fW\xe4fSro\xceO\
\x88l\x1aA\xddy0Y_\x97\xbc\xcb\x1eM*q\
=\xf4\x07\xcd'\xa5\x9c\xd1\xc9\xe6\xb3n\xc6\x10JX\
\x14]t_\x00\x00J\x5cl\x7f\x99\xd8\x00V\x94S\
\x00\xba\x13\xee\x0f\x86\xee\x02#\x88V\x92B\xbeK)\
\x00M\xe8yn_q[ge\x0a-=!\x14\xf6\
b\xa1\x84\x86\x10+\xb0&\xd4\x16\xe8#\x98\x00#\x07\
\xae\xa7\xa0L0/\x83\x0bS\x08Q\xcf\xb9\x00!\x00\
F\xa4\x0b\x1eh\x179\xb4\x0eZ\x03\x1f\xd8\x88\x01\x1e\
\xcf\x82\x96\xff\x08\xd7)A\x98R\xa4\xf6\x17\xa0\x8f\x10\
\xb4?\x80\x03\x15\xd6\x13\xae\xf4\xc9\x87B 0\x0a\xf8\
\xf0R\xde\xaeZSL\xd4\xa5\x8f\xe7\x9b3\xc2\xf8\xd6\
\xf1\x96\xbb\xc7o\xb9\x81\xb8X\x14\x8a~\xf5\x0d\xa4)\
\xb9_q\x03AJ\x93\x0b\xa1]U\xe3\x02\x12\x0a\x0b\
&/\xb8\xae\xb2\x89P\x0b\x81\x99\xd0W\xc3\x1d\x92\x9e\
N\xdeI\xdev39\xbb\x9f\xb8\xdd\xd8\xc4\x84\xd15\
\xe55\xed\xbf\xa0\xf1\x97t>\xd7z\xfa\xc6\xf2?\x1d\
-\x12\xec\x82'\x83\x05pEA\xcb\x87\xd8k\xc1\xc2\
\xd07\x0d\x16\xf5{\x04\xcb\xb4\xca\xe7J\xff?V\xce\
\x0c\x87C\xe6\xdaIq-X\xa0\x8feR\xbd\x1e,\
\xc1\xb7\xc5\x16\x15\xfc\x0e\xe8rU\xefs\xcd_\x8b\x98\
\xb3\xd2t\xa5\xc3\x17\xec\x8b\x1d~]J1\x81\x1a\xdb\
4\x02\xdd0\xe0\xee5\x87c<\x0bT\x88\xb5T\x84\
\xb375\xf9o\xb8\xeb\x8e\xab\xef\xa5\xa9\x9cy\xdd/\
4\xa3\xbbm\xfb\xaa\x9e\xda83W\xf2\xa0wI\xdf\
 NG\xebd\x07\x05y!)\xa6o\xbb\x95>\x98\
\x83\xc9\xbe\xfeV\xea\xa8\xc5z]\x9aj\x81.n\xaa\
w\xbb(\x85\xfc\xab\xdf\xa3\x9a\xb4\xbdj6\x8c&\xfa\
\x5c\xf7*\x03\x17N\xaa\x05\xe1\x97\xc1\xec\x9ee\xb0\x0a\
%\x22\x92]Z\xdd\x02\x93\x01\x06Ph\xa3\xde\xd6\xa8\
\x8fR\xa31\xe8k\xef\xd9\x97\x16\x97!TR\xc1\xde\
f\xf1\xda\xc8\xdf\xea\x1d\xa0\xebW\x09\x98\x8b\x11h2\
g\x14\xae\x0fD\xc3m\xd6\x03\x1bA?,\xb5{\x93\
\xc6\x081\xf5\x9a\x17./)o\x7f\xcb9\xc3*\xb0\
\x97q\xbf\xd4\x94+?\x8e\xcf|0\xca\xf9\xc1\xa0\xfb\
\xda\x7f\xe9\xe0`\xf2\x9d\x00\x1ae$$Q\xd0\xa0\x13\
\x1e*%A\xe7\xf1\x93\xfb\x86a\xd6?J\x9c?\x7f\
\x09\xdck|\xed!\x02\x13\xa6\x89n\x7fw\xa8%[\
\xba\x1f\xb6\xee\xdf\xfd\x1b\xda\x80\xb5 \
\x00\x00\x07\xdd\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22s\
avec.svg\x22\x0a   ink\
scape:version=\x220\
.92.4 (unknown)\x22\
>\x0a  <metadata\x0a  \
   id=\x22metadata8\
\x22>\x0a    <rdf:RDF>\
\x0a      <cc:Work\x0a\
         rdf:abo\
ut=\x22\x22>\x0a        <\
dc:format>image/\
svg+xml</dc:form\
at>\x0a        <dc:\
type\x0a           \
rdf:resource=\x22ht\
tp://purl.org/dc\
/dcmitype/StillI\
mage\x22 />\x0a       \
 <dc:title />\x0a  \
    </cc:Work>\x0a \
   </rdf:RDF>\x0a  \
</metadata>\x0a  <d\
efs\x0a     id=\x22def\
s6\x22 />\x0a  <sodipo\
di:namedview\x0a   \
  pagecolor=\x22#ff\
ffff\x22\x0a     borde\
rcolor=\x22#666666\x22\
\x0a     borderopac\
ity=\x221\x22\x0a     obj\
ecttolerance=\x2210\
\x22\x0a     gridtoler\
ance=\x2210\x22\x0a     g\
uidetolerance=\x221\
0\x22\x0a     inkscape\
:pageopacity=\x220\x22\
\x0a     inkscape:p\
ageshadow=\x222\x22\x0a  \
   inkscape:wind\
ow-width=\x221863\x22\x0a\
     inkscape:wi\
ndow-height=\x22102\
5\x22\x0a     id=\x22name\
dview4\x22\x0a     sho\
wgrid=\x22false\x22\x0a  \
   inkscape:zoom\
=\x221.1020922\x22\x0a   \
  inkscape:cx=\x22-\
112.84034\x22\x0a     \
inkscape:cy=\x22120\
.23219\x22\x0a     ink\
scape:window-x=\x22\
57\x22\x0a     inkscap\
e:window-y=\x2227\x22\x0a\
     inkscape:wi\
ndow-maximized=\x22\
1\x22\x0a     inkscape\
:current-layer=\x22\
svg2\x22 />\x0a  <path\
\x0a     style=\x22fil\
l:#5555ff;stroke\
-width:4;stroke:\
none;stroke-opac\
ity:1;stroke-mit\
erlimit:4;stroke\
-dasharray:none\x22\
\x0a     d=\x22m 37.55\
9322,153.62712 v\
 -8 h 56 55.9999\
98 v 8 8 h -55.9\
99998 -56 z m 28\
,-52.66667 -27.3\
0894,-27.333331 \
h 15.654471 15.6\
54469 v -24 -24 \
h 24 23.999998 v\
 24 24 h 15.6544\
7 15.65446 l -27\
.30893,27.333331\
 c -15.01992,15.\
03334 -27.619918\
,27.33334 -27.99\
9998,27.33334 -0\
.38008,0 -12.980\
08,-12.3 -28,-27\
.33334 z\x22\x0a     i\
d=\x22path817\x22\x0a    \
 inkscape:connec\
tor-curvature=\x220\
\x22 />\x0a</svg>\x0a\
\x00\x00\x07\x9c\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22s\
ave.svg\x22\x0a   inks\
cape:version=\x220.\
92.4 (unknown)\x22>\
\x0a  <metadata\x0a   \
  id=\x22metadata8\x22\
>\x0a    <rdf:RDF>\x0a\
      <cc:Work\x0a \
        rdf:abou\
t=\x22\x22>\x0a        <d\
c:format>image/s\
vg+xml</dc:forma\
t>\x0a        <dc:t\
ype\x0a           r\
df:resource=\x22htt\
p://purl.org/dc/\
dcmitype/StillIm\
age\x22 />\x0a        \
<dc:title />\x0a   \
   </cc:Work>\x0a  \
  </rdf:RDF>\x0a  <\
/metadata>\x0a  <de\
fs\x0a     id=\x22defs\
6\x22 />\x0a  <sodipod\
i:namedview\x0a    \
 pagecolor=\x22#fff\
fff\x22\x0a     border\
color=\x22#666666\x22\x0a\
     borderopaci\
ty=\x221\x22\x0a     obje\
cttolerance=\x2210\x22\
\x0a     gridtolera\
nce=\x2210\x22\x0a     gu\
idetolerance=\x2210\
\x22\x0a     inkscape:\
pageopacity=\x220\x22\x0a\
     inkscape:pa\
geshadow=\x222\x22\x0a   \
  inkscape:windo\
w-width=\x22902\x22\x0a  \
   inkscape:wind\
ow-height=\x22480\x22\x0a\
     id=\x22namedvi\
ew4\x22\x0a     showgr\
id=\x22false\x22\x0a     \
inkscape:zoom=\x221\
.2291667\x22\x0a     i\
nkscape:cx=\x22-47.\
999998\x22\x0a     ink\
scape:cy=\x2296.000\
006\x22\x0a     inksca\
pe:window-x=\x2257\x22\
\x0a     inkscape:w\
indow-y=\x2227\x22\x0a   \
  inkscape:windo\
w-maximized=\x220\x22\x0a\
     inkscape:cu\
rrent-layer=\x22svg\
2\x22 />\x0a  <path\x0a  \
   style=\x22fill:#\
999999;stroke-wi\
dth:1.33333337\x22\x0a\
     d=\x22m 37.559\
322,153.62712 v \
-8 h 56 55.99999\
8 v 8 8 h -55.99\
9998 -56 z m 28,\
-52.66667 -27.30\
894,-27.333331 h\
 15.654471 15.65\
4469 v -24 -24 h\
 24 23.999998 v \
24 24 h 15.65447\
 15.65446 l -27.\
30893,27.333331 \
c -15.01992,15.0\
3334 -27.619918,\
27.33334 -27.999\
998,27.33334 -0.\
38008,0 -12.9800\
8,-12.3 -28,-27.\
33334 z\x22\x0a     id\
=\x22path817\x22\x0a     \
inkscape:connect\
or-curvature=\x220\x22\
 />\x0a</svg>\x0a\
"

qt_resource_name = b"\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x08\
\x0b\x85Wg\
\x00g\
\x00e\x00a\x00r\x00.\x00s\x00v\x00g\
\x00\x07\
\x0d\x0bZ\x07\
\x00f\
\x00i\x00x\x00.\x00s\x00v\x00g\
\x00\x15\
\x0d\x18\x91g\
\x00i\
\x00n\x00p\x00u\x00t\x00s\x00_\x00a\x00n\x00a\x00l\x00y\x00s\x00i\x00s\x00 \x002\
\x00.\x00s\x00v\x00g\
\x00\x09\
\x0c\xb6\xa9\xc7\
\x00s\
\x00a\x00v\x00e\x00c\x00.\x00s\x00v\x00g\
\x00\x08\
\x08\xc8U\xe7\
\x00s\
\x00a\x00v\x00e\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x05\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x82\x00\x00\x00\x00\x00\x01\x00\x00(\xad\
\x00\x00\x01\x88\xae\xf9[!\
\x00\x00\x00\x10\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x88\xae\xf9[!\
\x00\x00\x00j\x00\x00\x00\x00\x00\x01\x00\x00 \xcc\
\x00\x00\x01\x88\xae\xf9[!\
\x00\x00\x00&\x00\x00\x00\x00\x00\x01\x00\x00\x0d^\
\x00\x00\x01\x88\xae\xf9[!\
\x00\x00\x00:\x00\x01\x00\x00\x00\x01\x00\x00\x18|\
\x00\x00\x01\x88\xae\xf9[!\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
