# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.6.2
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x09+\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22p\
lus.svg\x22\x0d\x0a   ink\
scape:version=\x220\
.92.4 (unknown)\x22\
>\x0d\x0a  <metadata\x0d\x0a\
     id=\x22metadat\
a8\x22>\x0d\x0a    <rdf:R\
DF>\x0d\x0a      <cc:W\
ork\x0d\x0a         rd\
f:about=\x22\x22>\x0d\x0a   \
     <dc:format>\
image/svg+xml</d\
c:format>\x0d\x0a     \
   <dc:type\x0d\x0a   \
        rdf:reso\
urce=\x22http://pur\
l.org/dc/dcmityp\
e/StillImage\x22 />\
\x0d\x0a        <dc:ti\
tle />\x0d\x0a      </\
cc:Work>\x0d\x0a    </\
rdf:RDF>\x0d\x0a  </me\
tadata>\x0d\x0a  <defs\
\x0d\x0a     id=\x22defs6\
\x22 />\x0d\x0a  <sodipod\
i:namedview\x0d\x0a   \
  pagecolor=\x22#ff\
ffff\x22\x0d\x0a     bord\
ercolor=\x22#666666\
\x22\x0d\x0a     borderop\
acity=\x221\x22\x0d\x0a     \
objecttolerance=\
\x2210\x22\x0d\x0a     gridt\
olerance=\x2210\x22\x0d\x0a \
    guidetoleran\
ce=\x2210\x22\x0d\x0a     in\
kscape:pageopaci\
ty=\x220\x22\x0d\x0a     ink\
scape:pageshadow\
=\x222\x22\x0d\x0a     inksc\
ape:window-width\
=\x221863\x22\x0d\x0a     in\
kscape:window-he\
ight=\x221025\x22\x0d\x0a   \
  id=\x22namedview4\
\x22\x0d\x0a     showgrid\
=\x22false\x22\x0d\x0a     i\
nkscape:zoom=\x221.\
7383042\x22\x0d\x0a     i\
nkscape:cx=\x22-213\
.83542\x22\x0d\x0a     in\
kscape:cy=\x22209.4\
4504\x22\x0d\x0a     inks\
cape:window-x=\x225\
7\x22\x0d\x0a     inkscap\
e:window-y=\x2227\x22\x0d\
\x0a     inkscape:w\
indow-maximized=\
\x221\x22\x0d\x0a     inksca\
pe:current-layer\
=\x22svg2\x22 />\x0d\x0a  <g\
\x0d\x0a     id=\x22g831\x22\
\x0d\x0a     style=\x22st\
roke:#37c8ab;str\
oke-linecap:roun\
d;stroke-opacity\
:1\x22>\x0d\x0a    <path\x0d\
\x0a       sodipodi\
:nodetypes=\x22cc\x22\x0d\
\x0a       inkscape\
:connector-curva\
ture=\x220\x22\x0d\x0a      \
 id=\x22path812\x22\x0d\x0a \
      d=\x22m 95.09\
1973,56.172243 0\
.09447,79.795097\
\x22\x0d\x0a       style=\
\x22fill:none;fill-\
rule:evenodd;str\
oke:#37c8ab;stro\
ke-width:16;stro\
ke-linecap:round\
;stroke-linejoin\
:miter;stroke-mi\
terlimit:4;strok\
e-dasharray:none\
;stroke-opacity:\
1\x22 />\x0d\x0a    <path\
\x0d\x0a       sodipod\
i:nodetypes=\x22cc\x22\
\x0d\x0a       inkscap\
e:connector-curv\
ature=\x220\x22\x0d\x0a     \
  id=\x22path812-3\x22\
\x0d\x0a       d=\x22m 13\
4.96147,95.59448\
7 -79.795108,0.0\
945\x22\x0d\x0a       sty\
le=\x22fill:none;fi\
ll-rule:evenodd;\
stroke:#37c8ab;s\
troke-width:16;s\
troke-linecap:ro\
und;stroke-linej\
oin:miter;stroke\
-miterlimit:4;st\
roke-dasharray:n\
one;stroke-opaci\
ty:1\x22 />\x0d\x0a  </g>\
\x0d\x0a</svg>\x0d\x0a\
\x00\x00\x07\xba\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<svg\x0d\x0a   \
xmlns:dc=\x22http:/\
/purl.org/dc/ele\
ments/1.1/\x22\x0d\x0a   \
xmlns:cc=\x22http:/\
/creativecommons\
.org/ns#\x22\x0d\x0a   xm\
lns:rdf=\x22http://\
www.w3.org/1999/\
02/22-rdf-syntax\
-ns#\x22\x0d\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0d\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0d\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0d\x0a   inkscape:ve\
rsion=\x221.0 (4035\
a4fb49, 2020-05-\
01)\x22\x0d\x0a   sodipod\
i:docname=\x22down.\
svg\x22\x0d\x0a   id=\x22svg\
6\x22\x0d\x0a   version=\x22\
1.1\x22\x0d\x0a   viewBox\
=\x220 0 48 48\x22\x0d\x0a  \
 height=\x2248\x22\x0d\x0a  \
 width=\x2248\x22>\x0d\x0a  \
<metadata\x0d\x0a     \
id=\x22metadata12\x22>\
\x0d\x0a    <rdf:RDF>\x0d\
\x0a      <cc:Work\x0d\
\x0a         rdf:ab\
out=\x22\x22>\x0d\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0d\x0a        <\
dc:type\x0d\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 />\x0d\x0a  \
      <dc:title \
/>\x0d\x0a      </cc:W\
ork>\x0d\x0a    </rdf:\
RDF>\x0d\x0a  </metada\
ta>\x0d\x0a  <defs\x0d\x0a  \
   id=\x22defs10\x22 /\
>\x0d\x0a  <sodipodi:n\
amedview\x0d\x0a     i\
nkscape:document\
-rotation=\x220\x22\x0d\x0a \
    inkscape:cur\
rent-layer=\x22svg6\
\x22\x0d\x0a     inkscape\
:window-maximize\
d=\x221\x22\x0d\x0a     inks\
cape:window-y=\x222\
6\x22\x0d\x0a     inkscap\
e:window-x=\x2260\x22\x0d\
\x0a     inkscape:c\
y=\x2224\x22\x0d\x0a     ink\
scape:cx=\x22-34.05\
977\x22\x0d\x0a     inksc\
ape:zoom=\x224.9166\
667\x22\x0d\x0a     showg\
rid=\x22false\x22\x0d\x0a   \
  id=\x22namedview8\
\x22\x0d\x0a     inkscape\
:window-height=\x22\
1017\x22\x0d\x0a     inks\
cape:window-widt\
h=\x221860\x22\x0d\x0a     i\
nkscape:pageshad\
ow=\x222\x22\x0d\x0a     ink\
scape:pageopacit\
y=\x220\x22\x0d\x0a     guid\
etolerance=\x2210\x22\x0d\
\x0a     gridtolera\
nce=\x2210\x22\x0d\x0a     o\
bjecttolerance=\x22\
10\x22\x0d\x0a     border\
opacity=\x221\x22\x0d\x0a   \
  bordercolor=\x22#\
666666\x22\x0d\x0a     pa\
gecolor=\x22#ffffff\
\x22 />\x0d\x0a  <path\x0d\x0a \
    fill=\x22none\x22\x0d\
\x0a     id=\x22path2\x22\
\x0d\x0a     d=\x22M0 0h4\
8v48h-48z\x22 />\x0d\x0a \
 <path\x0d\x0a     ink\
scape:connector-\
curvature=\x220\x22\x0d\x0a \
    id=\x22path4489\
\x22\x0d\x0a     d=\x22M 7.6\
708428,9.3577254\
 40.934572,9.206\
4897 23.565339,3\
8.459516 Z\x22\x0d\x0a   \
  style=\x22fill:#c\
ccccc;fill-rule:\
evenodd;stroke:n\
one;stroke-width\
:2.973;stroke-li\
necap:butt;strok\
e-linejoin:round\
;stroke-miterlim\
it:4;stroke-dash\
array:none;strok\
e-opacity:1;pain\
t-order:stroke f\
ill markers\x22 />\x0d\
\x0a</svg>\x0d\x0a\
\x00\x00\x09q\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22p\
lus (gray).svg\x22\x0d\
\x0a   inkscape:ver\
sion=\x220.92.4 (un\
known)\x22>\x0d\x0a  <met\
adata\x0d\x0a     id=\x22\
metadata8\x22>\x0d\x0a   \
 <rdf:RDF>\x0d\x0a    \
  <cc:Work\x0d\x0a    \
     rdf:about=\x22\
\x22>\x0d\x0a        <dc:\
format>image/svg\
+xml</dc:format>\
\x0d\x0a        <dc:ty\
pe\x0d\x0a           r\
df:resource=\x22htt\
p://purl.org/dc/\
dcmitype/StillIm\
age\x22 />\x0d\x0a       \
 <dc:title />\x0d\x0a \
     </cc:Work>\x0d\
\x0a    </rdf:RDF>\x0d\
\x0a  </metadata>\x0d\x0a\
  <defs\x0d\x0a     id\
=\x22defs6\x22 />\x0d\x0a  <\
sodipodi:namedvi\
ew\x0d\x0a     pagecol\
or=\x22#ffffff\x22\x0d\x0a  \
   bordercolor=\x22\
#666666\x22\x0d\x0a     b\
orderopacity=\x221\x22\
\x0d\x0a     objecttol\
erance=\x2210\x22\x0d\x0a   \
  gridtolerance=\
\x2210\x22\x0d\x0a     guide\
tolerance=\x2210\x22\x0d\x0a\
     inkscape:pa\
geopacity=\x220\x22\x0d\x0a \
    inkscape:pag\
eshadow=\x222\x22\x0d\x0a   \
  inkscape:windo\
w-width=\x221863\x22\x0d\x0a\
     inkscape:wi\
ndow-height=\x22102\
5\x22\x0d\x0a     id=\x22nam\
edview4\x22\x0d\x0a     s\
howgrid=\x22false\x22\x0d\
\x0a     inkscape:z\
oom=\x221.7383042\x22\x0d\
\x0a     inkscape:c\
x=\x22133.79315\x22\x0d\x0a \
    inkscape:cy=\
\x2271.379447\x22\x0d\x0a   \
  inkscape:windo\
w-x=\x2257\x22\x0d\x0a     i\
nkscape:window-y\
=\x2227\x22\x0d\x0a     inks\
cape:window-maxi\
mized=\x221\x22\x0d\x0a     \
inkscape:current\
-layer=\x22svg2\x22 />\
\x0d\x0a  <g\x0d\x0a     id=\
\x22g831\x22\x0d\x0a     sty\
le=\x22stroke:#aeae\
ae;stroke-lineca\
p:round;stroke-o\
pacity:1;fill:#a\
eaeae;fill-opaci\
ty:1\x22>\x0d\x0a    <pat\
h\x0d\x0a       sodipo\
di:nodetypes=\x22cc\
\x22\x0d\x0a       inksca\
pe:connector-cur\
vature=\x220\x22\x0d\x0a    \
   id=\x22path812\x22\x0d\
\x0a       d=\x22m 95.\
091973,56.172243\
 0.09447,79.7950\
97\x22\x0d\x0a       styl\
e=\x22fill:#aeaeae;\
fill-rule:evenod\
d;stroke:#aeaeae\
;stroke-width:16\
;stroke-linecap:\
round;stroke-lin\
ejoin:miter;stro\
ke-miterlimit:4;\
stroke-dasharray\
:none;stroke-opa\
city:1;fill-opac\
ity:1\x22 />\x0d\x0a    <\
path\x0d\x0a       sod\
ipodi:nodetypes=\
\x22cc\x22\x0d\x0a       ink\
scape:connector-\
curvature=\x220\x22\x0d\x0a \
      id=\x22path81\
2-3\x22\x0d\x0a       d=\x22\
m 134.96147,95.5\
94487 -79.795108\
,0.0945\x22\x0d\x0a      \
 style=\x22fill:#ae\
aeae;fill-rule:e\
venodd;stroke:#a\
eaeae;stroke-wid\
th:16;stroke-lin\
ecap:round;strok\
e-linejoin:miter\
;stroke-miterlim\
it:4;stroke-dash\
array:none;strok\
e-opacity:1;fill\
-opacity:1\x22 />\x0d\x0a\
  </g>\x0d\x0a</svg>\x0d\x0a\
\
\x00\x00\x07Q\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<svg\x0d\x0a   \
xmlns:dc=\x22http:/\
/purl.org/dc/ele\
ments/1.1/\x22\x0d\x0a   \
xmlns:cc=\x22http:/\
/creativecommons\
.org/ns#\x22\x0d\x0a   xm\
lns:rdf=\x22http://\
www.w3.org/1999/\
02/22-rdf-syntax\
-ns#\x22\x0d\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0d\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0d\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0d\x0a   width=\x2248\x22\x0d\
\x0a   height=\x2248\x22\x0d\
\x0a   viewBox=\x220 0\
 48 48\x22\x0d\x0a   vers\
ion=\x221.1\x22\x0d\x0a   id\
=\x22svg4\x22\x0d\x0a   sodi\
podi:docname=\x22ic\
_extension_48px.\
svg\x22\x0d\x0a   inkscap\
e:version=\x220.92.\
3 (2405546, 2018\
-03-11)\x22>\x0d\x0a  <me\
tadata\x0d\x0a     id=\
\x22metadata10\x22>\x0d\x0a \
   <rdf:RDF>\x0d\x0a  \
    <cc:Work\x0d\x0a  \
       rdf:about\
=\x22\x22>\x0d\x0a        <d\
c:format>image/s\
vg+xml</dc:forma\
t>\x0d\x0a        <dc:\
type\x0d\x0a          \
 rdf:resource=\x22h\
ttp://purl.org/d\
c/dcmitype/Still\
Image\x22 />\x0d\x0a     \
 </cc:Work>\x0d\x0a   \
 </rdf:RDF>\x0d\x0a  <\
/metadata>\x0d\x0a  <d\
efs\x0d\x0a     id=\x22de\
fs8\x22 />\x0d\x0a  <sodi\
podi:namedview\x0d\x0a\
     pagecolor=\x22\
#ffffff\x22\x0d\x0a     b\
ordercolor=\x22#666\
666\x22\x0d\x0a     borde\
ropacity=\x221\x22\x0d\x0a  \
   objecttoleran\
ce=\x2210\x22\x0d\x0a     gr\
idtolerance=\x2210\x22\
\x0d\x0a     guidetole\
rance=\x2210\x22\x0d\x0a    \
 inkscape:pageop\
acity=\x220\x22\x0d\x0a     \
inkscape:pagesha\
dow=\x222\x22\x0d\x0a     in\
kscape:window-wi\
dth=\x221055\x22\x0d\x0a    \
 inkscape:window\
-height=\x22803\x22\x0d\x0a \
    id=\x22namedvie\
w6\x22\x0d\x0a     showgr\
id=\x22false\x22\x0d\x0a    \
 inkscape:zoom=\x22\
4.9166667\x22\x0d\x0a    \
 inkscape:cx=\x2221\
.050847\x22\x0d\x0a     i\
nkscape:cy=\x2224\x22\x0d\
\x0a     inkscape:w\
indow-x=\x2269\x22\x0d\x0a  \
   inkscape:wind\
ow-y=\x2227\x22\x0d\x0a     \
inkscape:window-\
maximized=\x220\x22\x0d\x0a \
    inkscape:cur\
rent-layer=\x22svg4\
\x22 />\x0d\x0a  <path\x0d\x0a \
    d=\x22M41 22h-3\
v-8c0-2.21-1.79-\
4-4-4h-8V7c0-2.7\
6-2.24-5-5-5s-5 \
2.24-5 5v3H8c-2.\
21 0-3.98 1.79-3\
.98 4l-.01 7.6H7\
c2.98 0 5.4 2.42\
 5.4 5.4S9.98 32\
.4 7 32.4H4.01L4\
 40c0 2.21 1.79 \
4 4 4h7.6v-3c0-2\
.98 2.42-5.4 5.4\
-5.4 2.98 0 5.4 \
2.42 5.4 5.4v3H3\
4c2.21 0 4-1.79 \
4-4v-8h3c2.76 0 \
5-2.24 5-5s-2.24\
-5-5-5z\x22\x0d\x0a     i\
d=\x22path2\x22\x0d\x0a     \
style=\x22fill:#999\
999;fill-opacity\
:1\x22 />\x0d\x0a</svg>\x0d\x0a\
\
\x00\x00\x0d$\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<svg\x0d\x0a   \
xmlns:dc=\x22http:/\
/purl.org/dc/ele\
ments/1.1/\x22\x0d\x0a   \
xmlns:cc=\x22http:/\
/creativecommons\
.org/ns#\x22\x0d\x0a   xm\
lns:rdf=\x22http://\
www.w3.org/1999/\
02/22-rdf-syntax\
-ns#\x22\x0d\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0d\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0d\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0d\x0a   width=\x2248\x22\x0d\
\x0a   height=\x2248\x22\x0d\
\x0a   viewBox=\x220 0\
 48 48\x22\x0d\x0a   vers\
ion=\x221.1\x22\x0d\x0a   id\
=\x22svg6\x22\x0d\x0a   sodi\
podi:docname=\x22un\
do.svg\x22\x0d\x0a   inks\
cape:version=\x220.\
92.3 (2405546, 2\
018-03-11)\x22>\x0d\x0a  \
<metadata\x0d\x0a     \
id=\x22metadata12\x22>\
\x0d\x0a    <rdf:RDF>\x0d\
\x0a      <cc:Work\x0d\
\x0a         rdf:ab\
out=\x22\x22>\x0d\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0d\x0a        <\
dc:type\x0d\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 />\x0d\x0a  \
      <dc:title \
/>\x0d\x0a      </cc:W\
ork>\x0d\x0a    </rdf:\
RDF>\x0d\x0a  </metada\
ta>\x0d\x0a  <defs\x0d\x0a  \
   id=\x22defs10\x22 /\
>\x0d\x0a  <sodipodi:n\
amedview\x0d\x0a     p\
agecolor=\x22#fffff\
f\x22\x0d\x0a     borderc\
olor=\x22#666666\x22\x0d\x0a\
     borderopaci\
ty=\x221\x22\x0d\x0a     obj\
ecttolerance=\x2210\
\x22\x0d\x0a     gridtole\
rance=\x2210\x22\x0d\x0a    \
 guidetolerance=\
\x2210\x22\x0d\x0a     inksc\
ape:pageopacity=\
\x220\x22\x0d\x0a     inksca\
pe:pageshadow=\x222\
\x22\x0d\x0a     inkscape\
:window-width=\x229\
04\x22\x0d\x0a     inksca\
pe:window-height\
=\x22427\x22\x0d\x0a     id=\
\x22namedview8\x22\x0d\x0a  \
   showgrid=\x22fal\
se\x22\x0d\x0a     inksca\
pe:zoom=\x224.91666\
67\x22\x0d\x0a     inksca\
pe:cx=\x2224\x22\x0d\x0a    \
 inkscape:cy=\x2233\
.15853\x22\x0d\x0a     in\
kscape:window-x=\
\x22554\x22\x0d\x0a     inks\
cape:window-y=\x225\
53\x22\x0d\x0a     inksca\
pe:window-maximi\
zed=\x220\x22\x0d\x0a     in\
kscape:current-l\
ayer=\x22g820\x22 />\x0d\x0a\
  <path\x0d\x0a     d=\
\x22M0 0h48v48h-48z\
\x22\x0d\x0a     id=\x22path\
2\x22\x0d\x0a     fill=\x22n\
one\x22 />\x0d\x0a  <g\x0d\x0a \
    id=\x22g820\x22\x0d\x0a \
    transform=\x22m\
atrix(0.66577573\
,0,0,0.67580692,\
171.12831,3.1164\
509)\x22\x0d\x0a     styl\
e=\x22stroke:#37c8a\
b\x22>\x0d\x0a    <path\x0d\x0a\
       sodipodi:\
nodetypes=\x22csc\x22\x0d\
\x0a       inkscape\
:connector-curva\
ture=\x220\x22\x0d\x0a      \
 id=\x22path816\x22\x0d\x0a \
      d=\x22m -243.\
25424,36.20339 c\
 7.47466,23.4274\
49 32.21453,21.5\
03685 40.62787,8\
.634724 8.41086,\
-12.865143 1.314\
09,-37.4864107 -\
28.0177,-31.0076\
06\x22\x0d\x0a       styl\
e=\x22fill:none;fil\
l-rule:evenodd;s\
troke:#37c8ab;st\
roke-width:6;str\
oke-linecap:roun\
d;stroke-linejoi\
n:miter;stroke-m\
iterlimit:4;stro\
ke-dasharray:non\
e;stroke-opacity\
:1\x22 />\x0d\x0a    <pat\
h\x0d\x0a       inksca\
pe:connector-cur\
vature=\x220\x22\x0d\x0a    \
   id=\x22path4489\x22\
\x0d\x0a       d=\x22m -2\
25.0508,25.42373\
3 0.20339,-22.37\
28818 -19.72881,\
11.5932198 z\x22\x0d\x0a \
      style=\x22fil\
l:#37c8ab;fill-r\
ule:evenodd;stro\
ke:#37c8ab;strok\
e-width:2;stroke\
-linecap:butt;st\
roke-linejoin:ro\
und;stroke-miter\
limit:4;stroke-d\
asharray:none;st\
roke-opacity:1\x22 \
/>\x0d\x0a  </g>\x0d\x0a  <g\
\x0d\x0a     id=\x22g820-\
3\x22\x0d\x0a     transfo\
rm=\x22matrix(-0.66\
577573,0,0,0.675\
80692,-334.44009\
,-10.682883)\x22>\x0d\x0a\
    <path\x0d\x0a     \
  sodipodi:nodet\
ypes=\x22csc\x22\x0d\x0a    \
   inkscape:conn\
ector-curvature=\
\x220\x22\x0d\x0a       id=\x22\
path816-6\x22\x0d\x0a    \
   d=\x22m -243.254\
24,36.20339 c 7.\
47466,23.427449 \
32.21453,21.5036\
85 40.62787,8.63\
4724 8.41086,-12\
.865143 1.31409,\
-37.4864107 -28.\
0177,-31.007606\x22\
\x0d\x0a       style=\x22\
fill:none;fill-r\
ule:evenodd;stro\
ke:#999999;strok\
e-width:6;stroke\
-linecap:round;s\
troke-linejoin:m\
iter;stroke-mite\
rlimit:4;stroke-\
dasharray:none;s\
troke-opacity:1\x22\
 />\x0d\x0a    <path\x0d\x0a\
       inkscape:\
connector-curvat\
ure=\x220\x22\x0d\x0a       \
id=\x22path4489-7\x22\x0d\
\x0a       d=\x22m -22\
5.0508,25.423733\
 0.20339,-22.372\
8818 -19.72881,1\
1.5932198 z\x22\x0d\x0a  \
     style=\x22fill\
:#999999;fill-ru\
le:evenodd;strok\
e:#999999;stroke\
-width:2;stroke-\
linecap:butt;str\
oke-linejoin:rou\
nd;stroke-miterl\
imit:4;stroke-da\
sharray:none;str\
oke-opacity:1\x22 /\
>\x0d\x0a  </g>\x0d\x0a</svg\
>\x0d\x0a\
\x00\x00\x0d\x94\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22g\
ear.svg\x22\x0d\x0a   ink\
scape:version=\x220\
.92.2 (5c3e80d, \
2017-08-06)\x22>\x0d\x0a \
 <metadata\x0d\x0a    \
 id=\x22metadata8\x22>\
\x0d\x0a    <rdf:RDF>\x0d\
\x0a      <cc:Work\x0d\
\x0a         rdf:ab\
out=\x22\x22>\x0d\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0d\x0a        <\
dc:type\x0d\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 />\x0d\x0a  \
      <dc:title \
/>\x0d\x0a      </cc:W\
ork>\x0d\x0a    </rdf:\
RDF>\x0d\x0a  </metada\
ta>\x0d\x0a  <defs\x0d\x0a  \
   id=\x22defs6\x22 />\
\x0d\x0a  <sodipodi:na\
medview\x0d\x0a     pa\
gecolor=\x22#ffffff\
\x22\x0d\x0a     borderco\
lor=\x22#666666\x22\x0d\x0a \
    borderopacit\
y=\x221\x22\x0d\x0a     obje\
cttolerance=\x2210\x22\
\x0d\x0a     gridtoler\
ance=\x2210\x22\x0d\x0a     \
guidetolerance=\x22\
10\x22\x0d\x0a     inksca\
pe:pageopacity=\x22\
0\x22\x0d\x0a     inkscap\
e:pageshadow=\x222\x22\
\x0d\x0a     inkscape:\
window-width=\x2278\
4\x22\x0d\x0a     inkscap\
e:window-height=\
\x22480\x22\x0d\x0a     id=\x22\
namedview4\x22\x0d\x0a   \
  showgrid=\x22fals\
e\x22\x0d\x0a     inkscap\
e:zoom=\x221.229166\
7\x22\x0d\x0a     inkscap\
e:cx=\x22-47.999997\
\x22\x0d\x0a     inkscape\
:cy=\x2296.000003\x22\x0d\
\x0a     inkscape:w\
indow-x=\x2257\x22\x0d\x0a  \
   inkscape:wind\
ow-y=\x2227\x22\x0d\x0a     \
inkscape:window-\
maximized=\x220\x22\x0d\x0a \
    inkscape:cur\
rent-layer=\x22svg2\
\x22 />\x0d\x0a  <path\x0d\x0a \
    style=\x22fill:\
#999999;stroke-w\
idth:1.33333337\x22\
\x0d\x0a     d=\x22m 77.6\
85212,176.62546 \
c -0.36495,-0.59\
051 -1.359378,-6\
.15571 -2.20984,\
-12.36712 -0.850\
46,-6.21142 -1.6\
47284,-11.29448 \
-1.77072,-11.295\
7 -0.292876,-0.0\
03 -8.928958,-4.\
7575 -11.737142,\
-6.46193 -1.6054\
74,-0.97444 -5.0\
33267,-0.14448 -\
13.016802,3.1516\
8 -6.691473,2.76\
271 -11.300681,3\
.99631 -12.04838\
1,3.22459 -2.638\
601,-2.72336 -17\
.422101,-29.3715\
3 -17.422101,-31\
.4044 0,-1.19223\
 3.885057,-5.095\
18 8.63346,-8.67\
324 l 8.63346,-6\
.50555 v -8.6666\
71 -8.666667 l -\
8.63346,-6.50555\
6 c -4.748403,-3\
.578056 -8.63346\
,-7.481016 -8.63\
346,-8.673242 0,\
-2.039252 14.787\
98,-28.686171 17\
.435789,-31.4180\
9 0.765807,-0.79\
0132 5.266256,0.\
388912 12.011621\
,3.146851 10.735\
632,4.389415 10.\
808082,4.399033 \
15.223394,2.0212\
32 9.226118,-4.9\
68593 9.854293,-\
5.918176 11.4033\
1,-17.237861 0.8\
02812,-5.866667 \
1.912158,-11.134\
266 2.465212,-11\
.705775 0.553056\
,-0.571509 9.357\
958,-0.871509 19\
.566452,-0.66666\
7 l 18.560886,0.\
372442 2,11.7414\
16 2,11.741416 6\
.3294,3.92525 c \
3.48117,2.158888\
 6.79253,3.92525\
1 7.35858,3.9252\
51 0.56605,0 5.4\
1918,-1.844483 1\
0.78474,-4.09885\
1 5.36556,-2.254\
369 10.45926,-3.\
828818 11.31934,\
-3.498777 2.0332\
4,0.780228 18.20\
794,29.028695 18\
.20794,31.799445\
 0,1.166222 -3.8\
8505,5.047904 -8\
.63345,8.62596 l\
 -8.63347,6.5055\
56 v 8.666667 8.\
666671 l 8.63347\
,6.50555 c 4.748\
4,3.57806 8.6334\
5,7.48101 8.6334\
5,8.67324 0,2.03\
287 -14.7835,28.\
68104 -17.4221,3\
1.4044 -0.74772,\
0.77174 -5.29872\
,-0.43786 -11.89\
703,-3.1621 l -1\
0.68606,-4.41197\
 -7.21862,3.7794\
4 -7.21861,3.779\
43 -1.77879,12.0\
4933 -1.77879,12\
.04933 -18.89906\
6,0.36932 c -10.\
394484,0.20314 -\
19.19766,-0.1138\
6 -19.562612,-0.\
7043 z m 29.5045\
08,-53.06908 c 1\
4.62521,-6.10929\
 21.57602,-23.26\
646 15.09602,-37\
.262594 -10.2021\
7,-22.03565 -40.\
74219,-22.03565 \
-50.944364,0 -10\
.329641,22.31097\
4 13.168754,46.7\
36394 35.848344,\
37.262594 z\x22\x0d\x0a  \
   id=\x22path817\x22\x0d\
\x0a     inkscape:c\
onnector-curvatu\
re=\x220\x22 />\x0d\x0a</svg\
>\x0d\x0a\
\x00\x00\x0f\xf3\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22p\
lot.svg\x22\x0d\x0a   ink\
scape:version=\x220\
.92.3 (2405546, \
2018-03-11)\x22>\x0d\x0a \
 <metadata\x0d\x0a    \
 id=\x22metadata8\x22>\
\x0d\x0a    <rdf:RDF>\x0d\
\x0a      <cc:Work\x0d\
\x0a         rdf:ab\
out=\x22\x22>\x0d\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0d\x0a        <\
dc:type\x0d\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 />\x0d\x0a  \
      <dc:title \
/>\x0d\x0a      </cc:W\
ork>\x0d\x0a    </rdf:\
RDF>\x0d\x0a  </metada\
ta>\x0d\x0a  <defs\x0d\x0a  \
   id=\x22defs6\x22 />\
\x0d\x0a  <sodipodi:na\
medview\x0d\x0a     pa\
gecolor=\x22#ffffff\
\x22\x0d\x0a     borderco\
lor=\x22#666666\x22\x0d\x0a \
    borderopacit\
y=\x221\x22\x0d\x0a     obje\
cttolerance=\x2210\x22\
\x0d\x0a     gridtoler\
ance=\x2210\x22\x0d\x0a     \
guidetolerance=\x22\
10\x22\x0d\x0a     inksca\
pe:pageopacity=\x22\
0\x22\x0d\x0a     inkscap\
e:pageshadow=\x222\x22\
\x0d\x0a     inkscape:\
window-width=\x2218\
51\x22\x0d\x0a     inksca\
pe:window-height\
=\x221025\x22\x0d\x0a     id\
=\x22namedview4\x22\x0d\x0a \
    showgrid=\x22fa\
lse\x22\x0d\x0a     inksc\
ape:zoom=\x221.2291\
667\x22\x0d\x0a     inksc\
ape:cx=\x22-47.9999\
98\x22\x0d\x0a     inksca\
pe:cy=\x2296.000006\
\x22\x0d\x0a     inkscape\
:window-x=\x2269\x22\x0d\x0a\
     inkscape:wi\
ndow-y=\x2227\x22\x0d\x0a   \
  inkscape:windo\
w-maximized=\x221\x22\x0d\
\x0a     inkscape:c\
urrent-layer=\x22sv\
g2\x22 />\x0d\x0a  <path\x0d\
\x0a     style=\x22fil\
l:none;fill-rule\
:evenodd;stroke:\
#ff0000;stroke-w\
idth:6;stroke-li\
necap:round;stro\
ke-linejoin:mite\
r;stroke-miterli\
mit:4;stroke-das\
harray:none;stro\
ke-opacity:1\x22\x0d\x0a \
    d=\x22M 19.5144\
59,83.80134 C 28\
.173022,74.61643\
7 31.02386,60.80\
883 58.945963,57\
.741722 82.14712\
1,60.63598 84.91\
8418,80.7924 103\
.71939,80.546389\
 c 24.26383,-1.2\
74365 22.69186,-\
13.651999 44.243\
93,-13.027666 21\
.85487,-2.039903\
 20.28547,1.7992\
83 32.6583,-17.0\
5689\x22\x0d\x0a     id=\x22\
path814\x22\x0d\x0a     i\
nkscape:connecto\
r-curvature=\x220\x22\x0d\
\x0a     sodipodi:n\
odetypes=\x22ccccc\x22\
 />\x0d\x0a  <path\x0d\x0a  \
   style=\x22fill:n\
one;fill-rule:ev\
enodd;stroke:#ff\
cc00;stroke-widt\
h:6;stroke-linec\
ap:round;stroke-\
linejoin:miter;s\
troke-miterlimit\
:4;stroke-dashar\
ray:none;stroke-\
opacity:1\x22\x0d\x0a    \
 d=\x22M 19.351568,\
101.88747 C 28.0\
10131,92.702567 \
34.115206,77.267\
842 58.783072,75\
.827852 81.98423\
,78.72211 84.755\
527,98.87853 103\
.5565,98.632519 \
c 24.26383,-1.27\
4365 22.69186,-1\
3.651999 44.2439\
3,-13.027666 21.\
85487,-2.039903 \
20.28547,1.79928\
3 32.6583,-17.05\
689\x22\x0d\x0a     id=\x22p\
ath814-3\x22\x0d\x0a     \
inkscape:connect\
or-curvature=\x220\x22\
\x0d\x0a     sodipodi:\
nodetypes=\x22ccccc\
\x22 />\x0d\x0a  <path\x0d\x0a \
    style=\x22fill:\
none;fill-rule:e\
venodd;stroke:#0\
0aad4;stroke-wid\
th:6;stroke-line\
cap:round;stroke\
-linejoin:miter;\
stroke-miterlimi\
t:4;stroke-dasha\
rray:none;stroke\
-opacity:1\x22\x0d\x0a   \
  d=\x22m 17.724451\
,126.29425 c 8.6\
5856,-9.1849 19.\
644994,-24.61963\
 39.4315,-26.059\
61 23.20116,2.89\
425 25.97246,23.\
05067 44.773429,\
22.80466 24.2638\
3,-1.27436 22.69\
186,-13.652 44.2\
4393,-13.02766 2\
1.85487,-2.03991\
 20.28547,1.7992\
8 32.6583,-17.05\
6894\x22\x0d\x0a     id=\x22\
path814-3-6\x22\x0d\x0a  \
   inkscape:conn\
ector-curvature=\
\x220\x22\x0d\x0a     sodipo\
di:nodetypes=\x22cc\
ccc\x22 />\x0d\x0a  <path\
\x0d\x0a     style=\x22fi\
ll:none;fill-rul\
e:evenodd;stroke\
:#00d4aa;stroke-\
width:6;stroke-l\
inecap:round;str\
oke-linejoin:mit\
er;stroke-miterl\
imit:4;stroke-da\
sharray:none;str\
oke-opacity:1\x22\x0d\x0a\
     d=\x22m 19.351\
56,101.88746 c 8\
.65857,-9.184897\
 20.458553,-14.0\
43351 40.245069,\
-15.483346 17.50\
6235,1.267141 25\
.158891,5.152375\
 43.959861,4.906\
365 24.26384,-1.\
27436 16.99695,3\
.432746 38.54902\
,4.057086 21.854\
87,-2.03991 17.0\
3124,-5.522754 3\
9.16678,-15.4297\
81\x22\x0d\x0a     id=\x22pa\
th814-3-7\x22\x0d\x0a    \
 inkscape:connec\
tor-curvature=\x220\
\x22\x0d\x0a     sodipodi\
:nodetypes=\x22cccc\
c\x22 />\x0d\x0a  <path\x0d\x0a\
     style=\x22fill\
:none;fill-rule:\
evenodd;stroke:#\
999999;stroke-wi\
dth:10;stroke-li\
necap:round;stro\
ke-linejoin:mite\
r;stroke-opacity\
:1;stroke-miterl\
imit:4;stroke-da\
sharray:none\x22\x0d\x0a \
    d=\x22M 181.423\
73,170.84746 H 1\
6.271186 l 1e-6,\
-152.135596\x22\x0d\x0a  \
   id=\x22path812\x22\x0d\
\x0a     inkscape:c\
onnector-curvatu\
re=\x220\x22\x0d\x0a     sod\
ipodi:nodetypes=\
\x22ccc\x22 />\x0d\x0a</svg>\
\x0d\x0a\
\x00\x00\x0c\x88\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  width=\x2248\x22\x0d\x0a  \
 height=\x2248\x22\x0d\x0a  \
 viewBox=\x220 0 48\
.000001 48.00000\
1\x22\x0d\x0a   id=\x22svg2\x22\
\x0d\x0a   version=\x221.\
1\x22\x0d\x0a   inkscape:\
version=\x220.92.2 \
(5c3e80d, 2017-0\
8-06)\x22\x0d\x0a   sodip\
odi:docname=\x22res\
ize.svg\x22>\x0d\x0a  <de\
fs\x0d\x0a     id=\x22def\
s4\x22 />\x0d\x0a  <sodip\
odi:namedview\x0d\x0a \
    id=\x22base\x22\x0d\x0a \
    pagecolor=\x22#\
ffffff\x22\x0d\x0a     bo\
rdercolor=\x22#6666\
66\x22\x0d\x0a     border\
opacity=\x221.0\x22\x0d\x0a \
    inkscape:pag\
eopacity=\x220.0\x22\x0d\x0a\
     inkscape:pa\
geshadow=\x222\x22\x0d\x0a  \
   inkscape:zoom\
=\x227.9195959\x22\x0d\x0a  \
   inkscape:cx=\x22\
23.580795\x22\x0d\x0a    \
 inkscape:cy=\x2231\
.52398\x22\x0d\x0a     in\
kscape:document-\
units=\x22px\x22\x0d\x0a    \
 inkscape:curren\
t-layer=\x22layer1\x22\
\x0d\x0a     showgrid=\
\x22false\x22\x0d\x0a     un\
its=\x22px\x22\x0d\x0a     i\
nkscape:window-w\
idth=\x221863\x22\x0d\x0a   \
  inkscape:windo\
w-height=\x221025\x22\x0d\
\x0a     inkscape:w\
indow-x=\x2257\x22\x0d\x0a  \
   inkscape:wind\
ow-y=\x2227\x22\x0d\x0a     \
inkscape:window-\
maximized=\x221\x22 />\
\x0d\x0a  <metadata\x0d\x0a \
    id=\x22metadata\
7\x22>\x0d\x0a    <rdf:RD\
F>\x0d\x0a      <cc:Wo\
rk\x0d\x0a         rdf\
:about=\x22\x22>\x0d\x0a    \
    <dc:format>i\
mage/svg+xml</dc\
:format>\x0d\x0a      \
  <dc:type\x0d\x0a    \
       rdf:resou\
rce=\x22http://purl\
.org/dc/dcmitype\
/StillImage\x22 />\x0d\
\x0a        <dc:tit\
le />\x0d\x0a      </c\
c:Work>\x0d\x0a    </r\
df:RDF>\x0d\x0a  </met\
adata>\x0d\x0a  <g\x0d\x0a  \
   inkscape:labe\
l=\x22Capa 1\x22\x0d\x0a    \
 inkscape:groupm\
ode=\x22layer\x22\x0d\x0a   \
  id=\x22layer1\x22\x0d\x0a \
    transform=\x22t\
ranslate(0,-1004\
.3622)\x22>\x0d\x0a    <r\
ect\x0d\x0a       styl\
e=\x22fill:none;fil\
l-opacity:0.8495\
1453;stroke:#999\
999;stroke-width\
:3.85741425;stro\
ke-linejoin:roun\
d;stroke-miterli\
mit:4;stroke-das\
harray:none\x22\x0d\x0a  \
     id=\x22rect413\
6\x22\x0d\x0a       width\
=\x2244.142586\x22\x0d\x0a  \
     height=\x2244.\
142586\x22\x0d\x0a       \
x=\x221.9287071\x22\x0d\x0a \
      y=\x221006.29\
09\x22\x0d\x0a       ry=\x22\
10.186751\x22 />\x0d\x0a \
   <g\x0d\x0a       id\
=\x22g4157\x22\x0d\x0a      \
 transform=\x22matr\
ix(0.84603094,0,\
0,0.78857975,5.0\
434872,217.0903)\
\x22\x0d\x0a       style=\
\x22stroke:#999999;\
fill:#999999\x22>\x0d\x0a\
      <path\x0d\x0a   \
      sodipodi:n\
odetypes=\x22ccc\x22\x0d\x0a\
         inkscap\
e:connector-curv\
ature=\x220\x22\x0d\x0a     \
    id=\x22path4138\
\x22\x0d\x0a         d=\x22m\
 9.1882493,1043.\
1259 28.1788757,\
-28.9184 0,0\x22\x0d\x0a \
        style=\x22f\
ill:#999999;fill\
-rule:evenodd;st\
roke:#999999;str\
oke-width:4.7461\
7958;stroke-line\
cap:butt;stroke-\
linejoin:miter;s\
troke-miterlimit\
:4;stroke-dashar\
ray:none;stroke-\
opacity:1\x22 />\x0d\x0a \
     <path\x0d\x0a    \
     sodipodi:no\
detypes=\x22cccc\x22\x0d\x0a\
         inkscap\
e:connector-curv\
ature=\x220\x22\x0d\x0a     \
    id=\x22path4140\
-3\x22\x0d\x0a         d=\
\x22m 38.871283,101\
9.5549 -6.563179\
,-7.2978 8.29744\
8,-1.8083 z\x22\x0d\x0a  \
       style=\x22fi\
ll:#999999;fill-\
rule:evenodd;str\
oke:#999999;stro\
ke-width:1px;str\
oke-linecap:butt\
;stroke-linejoin\
:miter;stroke-op\
acity:1\x22 />\x0d\x0a   \
   <path\x0d\x0a      \
   sodipodi:node\
types=\x22cccc\x22\x0d\x0a  \
       inkscape:\
connector-curvat\
ure=\x220\x22\x0d\x0a       \
  id=\x22path4140-3\
-6\x22\x0d\x0a         d=\
\x22m 6.8693068,103\
8.4258 6.5632192\
,7.2979 -8.29745\
02,1.8083 z\x22\x0d\x0a  \
       style=\x22fi\
ll:#999999;fill-\
rule:evenodd;str\
oke:#999999;stro\
ke-width:1px;str\
oke-linecap:butt\
;stroke-linejoin\
:miter;stroke-op\
acity:1\x22 />\x0d\x0a   \
 </g>\x0d\x0a  </g>\x0d\x0a<\
/svg>\x0d\x0a\
\x00\x00\x0b\x0d\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22l\
oad_add.svg\x22\x0d\x0a  \
 inkscape:versio\
n=\x220.92.3 (24055\
46, 2018-03-11)\x22\
>\x0d\x0a  <metadata\x0d\x0a\
     id=\x22metadat\
a8\x22>\x0d\x0a    <rdf:R\
DF>\x0d\x0a      <cc:W\
ork\x0d\x0a         rd\
f:about=\x22\x22>\x0d\x0a   \
     <dc:format>\
image/svg+xml</d\
c:format>\x0d\x0a     \
   <dc:type\x0d\x0a   \
        rdf:reso\
urce=\x22http://pur\
l.org/dc/dcmityp\
e/StillImage\x22 />\
\x0d\x0a        <dc:ti\
tle />\x0d\x0a      </\
cc:Work>\x0d\x0a    </\
rdf:RDF>\x0d\x0a  </me\
tadata>\x0d\x0a  <defs\
\x0d\x0a     id=\x22defs6\
\x22 />\x0d\x0a  <sodipod\
i:namedview\x0d\x0a   \
  pagecolor=\x22#ff\
ffff\x22\x0d\x0a     bord\
ercolor=\x22#666666\
\x22\x0d\x0a     borderop\
acity=\x221\x22\x0d\x0a     \
objecttolerance=\
\x2210\x22\x0d\x0a     gridt\
olerance=\x2210\x22\x0d\x0a \
    guidetoleran\
ce=\x2210\x22\x0d\x0a     in\
kscape:pageopaci\
ty=\x220\x22\x0d\x0a     ink\
scape:pageshadow\
=\x222\x22\x0d\x0a     inksc\
ape:window-width\
=\x221525\x22\x0d\x0a     in\
kscape:window-he\
ight=\x22684\x22\x0d\x0a    \
 id=\x22namedview4\x22\
\x0d\x0a     showgrid=\
\x22false\x22\x0d\x0a     in\
kscape:zoom=\x221.2\
291667\x22\x0d\x0a     in\
kscape:cx=\x22-192.\
00001\x22\x0d\x0a     ink\
scape:cy=\x2296.000\
009\x22\x0d\x0a     inksc\
ape:window-x=\x2267\
\x22\x0d\x0a     inkscape\
:window-y=\x2227\x22\x0d\x0a\
     inkscape:wi\
ndow-maximized=\x22\
0\x22\x0d\x0a     inkscap\
e:current-layer=\
\x22svg2\x22 />\x0d\x0a  <pa\
th\x0d\x0a     style=\x22\
fill:#37c8ab;str\
oke-width:1.3333\
3337\x22\x0d\x0a     d=\x22m\
 37.559322,154.4\
4068 v -8 h 56.0\
00004 56.000004 \
v 8 8 H 93.55932\
6 37.559322 Z m \
32,-48 V 82.4406\
78 H 53.896671 3\
8.234021 l 27.66\
265,-27.662651 2\
7.662655,-27.662\
65 27.662654,27.\
66265 27.66266,2\
7.662651 h -15.6\
6266 -15.66265 v\
 24.000002 24 H \
93.559326 69.559\
322 Z\x22\x0d\x0a     id=\
\x22path817\x22\x0d\x0a     \
inkscape:connect\
or-curvature=\x220\x22\
 />\x0d\x0a  <g\x0d\x0a     \
style=\x22stroke:#f\
f6600;stroke-lin\
ecap:round;strok\
e-opacity:1\x22\x0d\x0a  \
   id=\x22g831\x22\x0d\x0a  \
   transform=\x22ma\
trix(0.71514701,\
0,0,0.67497496,8\
7.405149,-30.675\
212)\x22>\x0d\x0a    <pat\
h\x0d\x0a       style=\
\x22fill:none;fill-\
rule:evenodd;str\
oke:#ff6600;stro\
ke-width:16;stro\
ke-linecap:round\
;stroke-linejoin\
:miter;stroke-mi\
terlimit:4;strok\
e-dasharray:none\
;stroke-opacity:\
1\x22\x0d\x0a       d=\x22m \
95.091973,56.172\
243 0.09447,79.7\
95097\x22\x0d\x0a       i\
d=\x22path812\x22\x0d\x0a   \
    inkscape:con\
nector-curvature\
=\x220\x22\x0d\x0a       sod\
ipodi:nodetypes=\
\x22cc\x22 />\x0d\x0a    <pa\
th\x0d\x0a       style\
=\x22fill:none;fill\
-rule:evenodd;st\
roke:#ff6600;str\
oke-width:16;str\
oke-linecap:roun\
d;stroke-linejoi\
n:miter;stroke-m\
iterlimit:4;stro\
ke-dasharray:non\
e;stroke-opacity\
:1\x22\x0d\x0a       d=\x22m\
 134.96147,95.59\
4487 -79.795108,\
0.0945\x22\x0d\x0a       \
id=\x22path812-3\x22\x0d\x0a\
       inkscape:\
connector-curvat\
ure=\x220\x22\x0d\x0a       \
sodipodi:nodetyp\
es=\x22cc\x22 />\x0d\x0a  </\
g>\x0d\x0a</svg>\x0d\x0a\
\x00\x00\x09\xba\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<svg\x0d\x0a   \
xmlns:dc=\x22http:/\
/purl.org/dc/ele\
ments/1.1/\x22\x0d\x0a   \
xmlns:cc=\x22http:/\
/creativecommons\
.org/ns#\x22\x0d\x0a   xm\
lns:rdf=\x22http://\
www.w3.org/1999/\
02/22-rdf-syntax\
-ns#\x22\x0d\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0d\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0d\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0d\x0a   width=\x2248\x22\x0d\
\x0a   height=\x2248\x22\x0d\
\x0a   viewBox=\x220 0\
 48 48\x22\x0d\x0a   vers\
ion=\x221.1\x22\x0d\x0a   id\
=\x22svg6\x22\x0d\x0a   sodi\
podi:docname=\x22re\
do.svg\x22\x0d\x0a   inks\
cape:version=\x220.\
92.3 (2405546, 2\
018-03-11)\x22>\x0d\x0a  \
<metadata\x0d\x0a     \
id=\x22metadata12\x22>\
\x0d\x0a    <rdf:RDF>\x0d\
\x0a      <cc:Work\x0d\
\x0a         rdf:ab\
out=\x22\x22>\x0d\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0d\x0a        <\
dc:type\x0d\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 />\x0d\x0a  \
      <dc:title \
/>\x0d\x0a      </cc:W\
ork>\x0d\x0a    </rdf:\
RDF>\x0d\x0a  </metada\
ta>\x0d\x0a  <defs\x0d\x0a  \
   id=\x22defs10\x22 /\
>\x0d\x0a  <sodipodi:n\
amedview\x0d\x0a     p\
agecolor=\x22#fffff\
f\x22\x0d\x0a     borderc\
olor=\x22#666666\x22\x0d\x0a\
     borderopaci\
ty=\x221\x22\x0d\x0a     obj\
ecttolerance=\x2210\
\x22\x0d\x0a     gridtole\
rance=\x2210\x22\x0d\x0a    \
 guidetolerance=\
\x2210\x22\x0d\x0a     inksc\
ape:pageopacity=\
\x220\x22\x0d\x0a     inksca\
pe:pageshadow=\x222\
\x22\x0d\x0a     inkscape\
:window-width=\x221\
863\x22\x0d\x0a     inksc\
ape:window-heigh\
t=\x221025\x22\x0d\x0a     i\
d=\x22namedview8\x22\x0d\x0a\
     showgrid=\x22f\
alse\x22\x0d\x0a     inks\
cape:zoom=\x224.916\
6667\x22\x0d\x0a     inks\
cape:cx=\x22-43.204\
849\x22\x0d\x0a     inksc\
ape:cy=\x2224\x22\x0d\x0a   \
  inkscape:windo\
w-x=\x2257\x22\x0d\x0a     i\
nkscape:window-y\
=\x2227\x22\x0d\x0a     inks\
cape:window-maxi\
mized=\x221\x22\x0d\x0a     \
inkscape:current\
-layer=\x22g820\x22 />\
\x0d\x0a  <path\x0d\x0a     \
d=\x22M0 0h48v48h-4\
8z\x22\x0d\x0a     id=\x22pa\
th2\x22\x0d\x0a     fill=\
\x22none\x22 />\x0d\x0a  <g\x0d\
\x0a     id=\x22g820\x22\x0d\
\x0a     transform=\
\x22matrix(-0.66577\
573,0,0,0.675806\
92,-124.33839,3.\
757795)\x22\x0d\x0a     s\
tyle=\x22stroke:#00\
aad4\x22>\x0d\x0a    <pat\
h\x0d\x0a       sodipo\
di:nodetypes=\x22cs\
c\x22\x0d\x0a       inksc\
ape:connector-cu\
rvature=\x220\x22\x0d\x0a   \
    id=\x22path816\x22\
\x0d\x0a       d=\x22m -2\
43.25424,36.2033\
9 c 7.47466,23.4\
27449 32.21453,2\
1.503685 40.6278\
7,8.634724 8.410\
86,-12.865143 1.\
31409,-37.486410\
7 -28.0177,-31.0\
07606\x22\x0d\x0a       s\
tyle=\x22fill:none;\
fill-rule:evenod\
d;stroke:#00aad4\
;stroke-width:6;\
stroke-linecap:r\
ound;stroke-line\
join:miter;strok\
e-miterlimit:4;s\
troke-dasharray:\
none;stroke-opac\
ity:1\x22 />\x0d\x0a    <\
path\x0d\x0a       ink\
scape:connector-\
curvature=\x220\x22\x0d\x0a \
      id=\x22path44\
89-3\x22\x0d\x0a       d=\
\x22m -225.0508,25.\
423733 0.20339,-\
22.3728818 -19.7\
2881,11.5932198 \
z\x22\x0d\x0a       style\
=\x22fill:#00aad4;f\
ill-rule:evenodd\
;stroke:#00aad4;\
stroke-width:2;s\
troke-linecap:bu\
tt;stroke-linejo\
in:round;stroke-\
miterlimit:4;str\
oke-dasharray:no\
ne;stroke-opacit\
y:1\x22 />\x0d\x0a  </g>\x0d\
\x0a</svg>\x0d\x0a\
\x00\x00\x09\xd3\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<svg\x0d\x0a   \
xmlns:dc=\x22http:/\
/purl.org/dc/ele\
ments/1.1/\x22\x0d\x0a   \
xmlns:cc=\x22http:/\
/creativecommons\
.org/ns#\x22\x0d\x0a   xm\
lns:rdf=\x22http://\
www.w3.org/1999/\
02/22-rdf-syntax\
-ns#\x22\x0d\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0d\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0d\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0d\x0a   width=\x2248\x22\x0d\
\x0a   height=\x2248\x22\x0d\
\x0a   viewBox=\x220 0\
 48 48\x22\x0d\x0a   vers\
ion=\x221.1\x22\x0d\x0a   id\
=\x22svg6\x22\x0d\x0a   sodi\
podi:docname=\x22cl\
ear_runs.svg\x22\x0d\x0a \
  inkscape:versi\
on=\x221.0 (4035a4f\
b49, 2020-05-01)\
\x22>\x0d\x0a  <metadata\x0d\
\x0a     id=\x22metada\
ta12\x22>\x0d\x0a    <rdf\
:RDF>\x0d\x0a      <cc\
:Work\x0d\x0a         \
rdf:about=\x22\x22>\x0d\x0a \
       <dc:forma\
t>image/svg+xml<\
/dc:format>\x0d\x0a   \
     <dc:type\x0d\x0a \
          rdf:re\
source=\x22http://p\
url.org/dc/dcmit\
ype/StillImage\x22 \
/>\x0d\x0a        <dc:\
title />\x0d\x0a      \
</cc:Work>\x0d\x0a    \
</rdf:RDF>\x0d\x0a  </\
metadata>\x0d\x0a  <de\
fs\x0d\x0a     id=\x22def\
s10\x22 />\x0d\x0a  <sodi\
podi:namedview\x0d\x0a\
     pagecolor=\x22\
#ffffff\x22\x0d\x0a     b\
ordercolor=\x22#666\
666\x22\x0d\x0a     borde\
ropacity=\x221\x22\x0d\x0a  \
   objecttoleran\
ce=\x2210\x22\x0d\x0a     gr\
idtolerance=\x2210\x22\
\x0d\x0a     guidetole\
rance=\x2210\x22\x0d\x0a    \
 inkscape:pageop\
acity=\x220\x22\x0d\x0a     \
inkscape:pagesha\
dow=\x222\x22\x0d\x0a     in\
kscape:window-wi\
dth=\x22963\x22\x0d\x0a     \
inkscape:window-\
height=\x22753\x22\x0d\x0a  \
   id=\x22namedview\
8\x22\x0d\x0a     showgri\
d=\x22false\x22\x0d\x0a     \
inkscape:zoom=\x221\
.7383042\x22\x0d\x0a     \
inkscape:cx=\x2228.\
919447\x22\x0d\x0a     in\
kscape:cy=\x22-67.1\
63857\x22\x0d\x0a     ink\
scape:window-x=\x22\
173\x22\x0d\x0a     inksc\
ape:window-y=\x2220\
1\x22\x0d\x0a     inkscap\
e:window-maximiz\
ed=\x220\x22\x0d\x0a     ink\
scape:current-la\
yer=\x22svg6\x22\x0d\x0a    \
 inkscape:docume\
nt-rotation=\x220\x22 \
/>\x0d\x0a  <path\x0d\x0a   \
  sodipodi:nodet\
ypes=\x22csscc\x22\x0d\x0a  \
   id=\x22path836\x22\x0d\
\x0a     d=\x22m 6.234\
6543,22.700042 c\
 7.7159037,2.037\
933 15.1042447,-\
2.016672 16.7611\
707,-0.582958 0,\
0 5.484116,2.679\
027 6.127844,5.3\
02337 0.855518,3\
.486391 -5.30597\
4,14.009468 -5.3\
05974,14.009468 \
C 11.746956,38.0\
27462 7.0322016,\
31.259994 6.2346\
543,22.700042 Z\x22\
\x0d\x0a     style=\x22fi\
ll:#e6e6e6;strok\
e:#808080;stroke\
-width:1px;strok\
e-linecap:butt;s\
troke-linejoin:m\
iter;stroke-opac\
ity:1\x22 />\x0d\x0a  <pa\
th\x0d\x0a     sodipod\
i:nodetypes=\x22csc\
cc\x22\x0d\x0a     id=\x22pa\
th838\x22\x0d\x0a     d=\x22\
M 25.637402,23.5\
88184 41.85822,7\
.750306 c 0.7676\
88,-0.749564 2.4\
38884,0.876482 1\
.782516,1.614332\
 L 27.467472,24.\
948699 Z\x22\x0d\x0a     \
style=\x22fill:#808\
080;stroke:#8080\
80;stroke-width:\
1px;stroke-linec\
ap:butt;stroke-l\
inejoin:miter;st\
roke-opacity:1\x22 \
/>\x0d\x0a  <path\x0d\x0a   \
  id=\x22path840\x22\x0d\x0a\
     d=\x22M 28.501\
261,30.871441 18\
.215729,22.48209\
4\x22\x0d\x0a     style=\x22\
fill:none;stroke\
:#808080;stroke-\
width:1px;stroke\
-linecap:butt;st\
roke-linejoin:mi\
ter;stroke-opaci\
ty:1\x22 />\x0d\x0a</svg>\
\x0d\x0a\
\x00\x00\x0b[\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22c\
opy2down.svg\x22\x0d\x0a \
  inkscape:versi\
on=\x220.92.3 (2405\
546, 2018-03-11)\
\x22>\x0d\x0a  <metadata\x0d\
\x0a     id=\x22metada\
ta8\x22>\x0d\x0a    <rdf:\
RDF>\x0d\x0a      <cc:\
Work\x0d\x0a         r\
df:about=\x22\x22>\x0d\x0a  \
      <dc:format\
>image/svg+xml</\
dc:format>\x0d\x0a    \
    <dc:type\x0d\x0a  \
         rdf:res\
ource=\x22http://pu\
rl.org/dc/dcmity\
pe/StillImage\x22 /\
>\x0d\x0a        <dc:t\
itle />\x0d\x0a      <\
/cc:Work>\x0d\x0a    <\
/rdf:RDF>\x0d\x0a  </m\
etadata>\x0d\x0a  <def\
s\x0d\x0a     id=\x22defs\
6\x22 />\x0d\x0a  <sodipo\
di:namedview\x0d\x0a  \
   pagecolor=\x22#f\
fffff\x22\x0d\x0a     bor\
dercolor=\x22#66666\
6\x22\x0d\x0a     bordero\
pacity=\x221\x22\x0d\x0a    \
 objecttolerance\
=\x2210\x22\x0d\x0a     grid\
tolerance=\x2210\x22\x0d\x0a\
     guidetolera\
nce=\x2210\x22\x0d\x0a     i\
nkscape:pageopac\
ity=\x220\x22\x0d\x0a     in\
kscape:pageshado\
w=\x222\x22\x0d\x0a     inks\
cape:window-widt\
h=\x221863\x22\x0d\x0a     i\
nkscape:window-h\
eight=\x221025\x22\x0d\x0a  \
   id=\x22namedview\
4\x22\x0d\x0a     showgri\
d=\x22false\x22\x0d\x0a     \
inkscape:zoom=\x221\
.2291667\x22\x0d\x0a     \
inkscape:cx=\x22-32\
8.06314\x22\x0d\x0a     i\
nkscape:cy=\x2296.0\
00009\x22\x0d\x0a     ink\
scape:window-x=\x22\
57\x22\x0d\x0a     inksca\
pe:window-y=\x2227\x22\
\x0d\x0a     inkscape:\
window-maximized\
=\x221\x22\x0d\x0a     inksc\
ape:current-laye\
r=\x22g820\x22 />\x0d\x0a  <\
path\x0d\x0a     style\
=\x22fill:#999999;s\
troke-width:1.33\
333337\x22\x0d\x0a     d=\
\x22m 53.118644,179\
.49816 c -1.4666\
6,-0.62009 -4.16\
666,-2.7414 -6,-\
4.71401 l -3.333\
33,-3.58656 V 10\
8.66398 46.13037\
9 l 4.35897,-4.3\
58975 4.35898,-4\
.358974 h 50.615\
376 50.61539 l 4\
.35897,4.358974 \
4.35897,4.358975\
 v 62.615381 62.\
61539 l -4.35758\
,4.35897 -4.3576\
,4.35897 -48.975\
74,0.27327 c -26\
.936656,0.15029 \
-50.175736,-0.23\
409 -51.642406,-\
0.8542 z m 93.99\
9996,-70.7524 V \
52.745763 h -44 \
-43.999996 v 55.\
999997 56 h 43.9\
99996 44 z M 11.\
412064,73.437035\
 l 0.37325,-59.3\
08728 4.35767,-4\
.3579395 4.35768\
,-4.3579381 51.3\
0899,-0.3786652 \
51.308986,-0.378\
6654 v 8.0453322\
 8.045332 h -47.\
999996 -48 v 56 \
55.999997 h -8.0\
3992 -8.03991 z\x22\
\x0d\x0a     id=\x22path8\
17\x22\x0d\x0a     inksca\
pe:connector-cur\
vature=\x220\x22 />\x0d\x0a \
 <g\x0d\x0a     id=\x22g8\
20\x22\x0d\x0a     transf\
orm=\x22matrix(-4,0\
,0,-4,-202.16948\
,208.67797)\x22>\x0d\x0a \
   <path\x0d\x0a      \
 id=\x22path2\x22\x0d\x0a   \
    d=\x22M 0,0 H 4\
8 V 48 H 0 Z\x22\x0d\x0a \
      inkscape:c\
onnector-curvatu\
re=\x220\x22\x0d\x0a       s\
tyle=\x22fill:none\x22\
 />\x0d\x0a    <path\x0d\x0a\
       inkscape:\
connector-curvat\
ure=\x220\x22\x0d\x0a       \
id=\x22path4489\x22\x0d\x0a \
      d=\x22m -82.7\
14559,29.629973 \
13.037829,0.1185\
25 -6.755966,-11\
.496992 z\x22\x0d\x0a    \
   style=\x22fill:#\
37c8ab;fill-rule\
:evenodd;stroke:\
#37c8ab;stroke-w\
idth:1.16550279;\
stroke-linecap:b\
utt;stroke-linej\
oin:round;stroke\
-miterlimit:4;st\
roke-dasharray:n\
one;stroke-opaci\
ty:1\x22 />\x0d\x0a  </g>\
\x0d\x0a</svg>\x0d\x0a\
\x00\x00\x0e\x99\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   ver\
sion=\x221.1\x22\x0d\x0a   i\
d=\x22svg2\x22\x0d\x0a   wid\
th=\x22192\x22\x0d\x0a   hei\
ght=\x22192\x22\x0d\x0a   vi\
ewBox=\x220 0 192 1\
92\x22\x0d\x0a   sodipodi\
:docname=\x22area_t\
ransfer.svg\x22\x0d\x0a  \
 inkscape:versio\
n=\x221.1 (c68e22c3\
87, 2021-05-23)\x22\
\x0d\x0a   xmlns:inksc\
ape=\x22http://www.\
inkscape.org/nam\
espaces/inkscape\
\x22\x0d\x0a   xmlns:sodi\
podi=\x22http://sod\
ipodi.sourceforg\
e.net/DTD/sodipo\
di-0.dtd\x22\x0d\x0a   xm\
lns=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0d\x0a   \
xmlns:rdf=\x22http:\
//www.w3.org/199\
9/02/22-rdf-synt\
ax-ns#\x22\x0d\x0a   xmln\
s:cc=\x22http://cre\
ativecommons.org\
/ns#\x22\x0d\x0a   xmlns:\
dc=\x22http://purl.\
org/dc/elements/\
1.1/\x22>\x0d\x0a  <metad\
ata\x0d\x0a     id=\x22me\
tadata8\x22>\x0d\x0a    <\
rdf:RDF>\x0d\x0a      \
<cc:Work\x0d\x0a      \
   rdf:about=\x22\x22>\
\x0d\x0a        <dc:fo\
rmat>image/svg+x\
ml</dc:format>\x0d\x0a\
        <dc:type\
\x0d\x0a           rdf\
:resource=\x22http:\
//purl.org/dc/dc\
mitype/StillImag\
e\x22 />\x0d\x0a        <\
dc:title />\x0d\x0a   \
   </cc:Work>\x0d\x0a \
   </rdf:RDF>\x0d\x0a \
 </metadata>\x0d\x0a  \
<defs\x0d\x0a     id=\x22\
defs6\x22 />\x0d\x0a  <so\
dipodi:namedview\
\x0d\x0a     pagecolor\
=\x22#ffffff\x22\x0d\x0a    \
 bordercolor=\x22#6\
66666\x22\x0d\x0a     bor\
deropacity=\x221\x22\x0d\x0a\
     objecttoler\
ance=\x2210\x22\x0d\x0a     \
gridtolerance=\x221\
0\x22\x0d\x0a     guideto\
lerance=\x2210\x22\x0d\x0a  \
   inkscape:page\
opacity=\x220\x22\x0d\x0a   \
  inkscape:pages\
hadow=\x222\x22\x0d\x0a     \
inkscape:window-\
width=\x221858\x22\x0d\x0a  \
   inkscape:wind\
ow-height=\x221057\x22\
\x0d\x0a     id=\x22named\
view4\x22\x0d\x0a     sho\
wgrid=\x22false\x22\x0d\x0a \
    inkscape:zoo\
m=\x223.2578125\x22\x0d\x0a \
    inkscape:cx=\
\x2245.275779\x22\x0d\x0a   \
  inkscape:cy=\x221\
09.1223\x22\x0d\x0a     i\
nkscape:window-x\
=\x2254\x22\x0d\x0a     inks\
cape:window-y=\x22-\
8\x22\x0d\x0a     inkscap\
e:window-maximiz\
ed=\x221\x22\x0d\x0a     ink\
scape:current-la\
yer=\x22g833\x22\x0d\x0a    \
 inkscape:pagech\
eckerboard=\x220\x22 /\
>\x0d\x0a  <g\x0d\x0a     id\
=\x22g893\x22\x0d\x0a     tr\
ansform=\x22matrix(\
0.34525501,0,0,0\
.34525501,12.167\
256,11.139857)\x22>\
\x0d\x0a    <g\x0d\x0a      \
 id=\x22g835\x22>\x0d\x0a\x09<g\
\x0d\x0a   id=\x22g833\x22>\x0d\
\x0a\x09\x09<path\x0d\x0a   d=\x22\
m 356.7,0.45 h -\
43.8 c -6.8,0 -1\
2.3,5.5 -12.3,12\
.3 0,6.8 5.5,12.\
2 12.3,12.2 h 43\
.8 c 39.4,0 71.5\
,32.1 71.5,71.5 \
v 61.9 L 412,142\
.15 c -4.8,-4.8 \
-12.5,-4.8 -17.3\
,0 -4.8,4.8 -4.8\
,12.5 0,17.3 l 3\
7.1,37.1 c 2.3,2\
.3 5.4,3.6 8.7,3\
.6 3.2,0 6.4,-1.\
3 8.7,-3.6 l 37.\
1,-37.1 c 4.8,-4\
.8 4.8,-12.5 0,-\
17.3 -4.8,-4.8 -\
12.5,-4.8 -17.3,\
0 l -16.2,16.2 v\
 -61.9 c -0.1,-5\
2.9 -43.2,-96 -9\
6.1,-96 z\x22\x0d\x0a   i\
d=\x22path825\x22\x0d\x0a   \
style=\x22fill:#37a\
bc8\x22 />\x0d\x0a\x0d\x0a\x09\x09<pa\
th\x0d\x0a   d=\x22M 238.\
8,227.95 V 13.65\
 c 0,-6.8 -5.5,-\
12.3 -12.3,-12.3\
 H 12.3 C 5.5,1.\
35 0,6.85 0,13.6\
5 v 214.3 c 0,6.\
8 5.5,12.3 12.3,\
12.3 h 214.3 c 6\
.7,-0.1 12.2,-5.\
6 12.2,-12.3 z m\
 -24.5,-12.3 H 2\
4.5 V 25.95 h 18\
9.8 z\x22\x0d\x0a   id=\x22p\
ath827\x22\x0d\x0a   styl\
e=\x22fill:#37abc8\x22\
 />\x0d\x0a\x0d\x0a\x09\x09<path\x0d\x0a\
   d=\x22m 133.1,48\
9.45 h 43.8 c 6.\
8,0 12.3,-5.5 12\
.3,-12.3 0,-6.8 \
-5.5,-12.2 -12.3\
,-12.2 h -43.8 c\
 -39.4,0 -71.5,-\
32.1 -71.5,-71.5\
 v -61.9 l 16.2,\
16.2 c 2.4,2.4 5\
.5,3.6 8.7,3.6 3\
.2,0 6.3,-1.2 8.\
7,-3.6 4.8,-4.8 \
4.8,-12.5 0,-17.\
3 l -37.1,-37.1 \
c -2.3,-2.3 -5.4\
,-3.6 -8.7,-3.6 \
-3.2,0 -6.4,1.3 \
-8.7,3.6 l -37.1\
,37.1 c -4.8,4.8\
 -4.8,12.5 0,17.\
3 4.8,4.8 12.5,4\
.8 17.3,0 l 16.2\
,-16.2 v 61.9 c \
0,52.9 43.1,96 9\
6,96 z\x22\x0d\x0a   id=\x22\
path829\x22\x0d\x0a   sty\
le=\x22fill:#37c8ab\
\x22 />\x0d\x0a\x0d\x0a\x09\x09<path\x0d\
\x0a   d=\x22m 263.2,4\
88.45 h 214.3 c \
6.8,0 12.3,-5.5 \
12.3,-12.3 v -21\
4.2 c 0,-6.8 -5.\
5,-12.3 -12.3,-1\
2.3 H 263.2 c -6\
.8,0 -12.3,5.5 -\
12.3,12.3 v 214.\
3 c 0.1,6.8 5.6,\
12.2 12.3,12.2 z\
 m 12.3,-214.2 h\
 189.8 v 189.7 H\
 275.5 Z\x22\x0d\x0a   id\
=\x22path831\x22\x0d\x0a   s\
tyle=\x22fill:#37c8\
ab\x22 />\x0d\x0a\x0d\x0a\x09</g>\x0d\
\x0a\x0d\x0a</g>\x0d\x0a    <g\x0d\
\x0a       id=\x22g837\
\x22>\x0d\x0a</g>\x0d\x0a    <g\
\x0d\x0a       id=\x22g83\
9\x22>\x0d\x0a</g>\x0d\x0a    <\
g\x0d\x0a       id=\x22g8\
41\x22>\x0d\x0a</g>\x0d\x0a    \
<g\x0d\x0a       id=\x22g\
843\x22>\x0d\x0a</g>\x0d\x0a   \
 <g\x0d\x0a       id=\x22\
g845\x22>\x0d\x0a</g>\x0d\x0a  \
  <g\x0d\x0a       id=\
\x22g847\x22>\x0d\x0a</g>\x0d\x0a \
   <g\x0d\x0a       id\
=\x22g849\x22>\x0d\x0a</g>\x0d\x0a\
    <g\x0d\x0a       i\
d=\x22g851\x22>\x0d\x0a</g>\x0d\
\x0a    <g\x0d\x0a       \
id=\x22g853\x22>\x0d\x0a</g>\
\x0d\x0a    <g\x0d\x0a      \
 id=\x22g855\x22>\x0d\x0a</g\
>\x0d\x0a    <g\x0d\x0a     \
  id=\x22g857\x22>\x0d\x0a</\
g>\x0d\x0a    <g\x0d\x0a    \
   id=\x22g859\x22>\x0d\x0a<\
/g>\x0d\x0a    <g\x0d\x0a   \
    id=\x22g861\x22>\x0d\x0a\
</g>\x0d\x0a    <g\x0d\x0a  \
     id=\x22g863\x22>\x0d\
\x0a</g>\x0d\x0a    <g\x0d\x0a \
      id=\x22g865\x22>\
\x0d\x0a</g>\x0d\x0a  </g>\x0d\x0a\
</svg>\x0d\x0a\
\x00\x00\x07m\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<svg\x0d\x0a   \
xmlns:dc=\x22http:/\
/purl.org/dc/ele\
ments/1.1/\x22\x0d\x0a   \
xmlns:cc=\x22http:/\
/creativecommons\
.org/ns#\x22\x0d\x0a   xm\
lns:rdf=\x22http://\
www.w3.org/1999/\
02/22-rdf-syntax\
-ns#\x22\x0d\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0d\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0d\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0d\x0a   width=\x2248\x22\x0d\
\x0a   height=\x2248\x22\x0d\
\x0a   viewBox=\x220 0\
 48 48\x22\x0d\x0a   vers\
ion=\x221.1\x22\x0d\x0a   id\
=\x22svg6\x22\x0d\x0a   sodi\
podi:docname=\x22up\
.svg\x22\x0d\x0a   inksca\
pe:version=\x220.92\
.4 (unknown)\x22>\x0d\x0a\
  <metadata\x0d\x0a   \
  id=\x22metadata12\
\x22>\x0d\x0a    <rdf:RDF\
>\x0d\x0a      <cc:Wor\
k\x0d\x0a         rdf:\
about=\x22\x22>\x0d\x0a     \
   <dc:format>im\
age/svg+xml</dc:\
format>\x0d\x0a       \
 <dc:type\x0d\x0a     \
      rdf:resour\
ce=\x22http://purl.\
org/dc/dcmitype/\
StillImage\x22 />\x0d\x0a\
        <dc:titl\
e />\x0d\x0a      </cc\
:Work>\x0d\x0a    </rd\
f:RDF>\x0d\x0a  </meta\
data>\x0d\x0a  <defs\x0d\x0a\
     id=\x22defs10\x22\
 />\x0d\x0a  <sodipodi\
:namedview\x0d\x0a    \
 pagecolor=\x22#fff\
fff\x22\x0d\x0a     borde\
rcolor=\x22#666666\x22\
\x0d\x0a     borderopa\
city=\x221\x22\x0d\x0a     o\
bjecttolerance=\x22\
10\x22\x0d\x0a     gridto\
lerance=\x2210\x22\x0d\x0a  \
   guidetoleranc\
e=\x2210\x22\x0d\x0a     ink\
scape:pageopacit\
y=\x220\x22\x0d\x0a     inks\
cape:pageshadow=\
\x222\x22\x0d\x0a     inksca\
pe:window-width=\
\x221863\x22\x0d\x0a     ink\
scape:window-hei\
ght=\x221025\x22\x0d\x0a    \
 id=\x22namedview8\x22\
\x0d\x0a     showgrid=\
\x22false\x22\x0d\x0a     in\
kscape:zoom=\x224.9\
166667\x22\x0d\x0a     in\
kscape:cx=\x22-84.1\
91565\x22\x0d\x0a     ink\
scape:cy=\x2224\x22\x0d\x0a \
    inkscape:win\
dow-x=\x2257\x22\x0d\x0a    \
 inkscape:window\
-y=\x2227\x22\x0d\x0a     in\
kscape:window-ma\
ximized=\x221\x22\x0d\x0a   \
  inkscape:curre\
nt-layer=\x22svg6\x22 \
/>\x0d\x0a  <path\x0d\x0a   \
  d=\x22M0 0h48v48h\
-48z\x22\x0d\x0a     id=\x22\
path2\x22\x0d\x0a     fil\
l=\x22none\x22 />\x0d\x0a  <\
path\x0d\x0a     style\
=\x22fill:#cccccc;f\
ill-rule:evenodd\
;stroke:none;str\
oke-width:2.9734\
8356;stroke-line\
cap:butt;stroke-\
linejoin:round;s\
troke-miterlimit\
:4;stroke-dashar\
ray:none;stroke-\
opacity:1\x22\x0d\x0a    \
 d=\x22M 7.6054021,\
38.160028 40.868\
101,38.462416 23\
.631976,9.130763\
7 Z\x22\x0d\x0a     id=\x22p\
ath4489\x22\x0d\x0a     i\
nkscape:connecto\
r-curvature=\x220\x22 \
/>\x0d\x0a</svg>\x0d\x0a\
\x00\x00\x09\xe0\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22n\
ew.svg\x22\x0d\x0a   inks\
cape:version=\x220.\
92.4 (unknown)\x22>\
\x0d\x0a  <metadata\x0d\x0a \
    id=\x22metadata\
8\x22>\x0d\x0a    <rdf:RD\
F>\x0d\x0a      <cc:Wo\
rk\x0d\x0a         rdf\
:about=\x22\x22>\x0d\x0a    \
    <dc:format>i\
mage/svg+xml</dc\
:format>\x0d\x0a      \
  <dc:type\x0d\x0a    \
       rdf:resou\
rce=\x22http://purl\
.org/dc/dcmitype\
/StillImage\x22 />\x0d\
\x0a        <dc:tit\
le />\x0d\x0a      </c\
c:Work>\x0d\x0a    </r\
df:RDF>\x0d\x0a  </met\
adata>\x0d\x0a  <defs\x0d\
\x0a     id=\x22defs6\x22\
 />\x0d\x0a  <sodipodi\
:namedview\x0d\x0a    \
 pagecolor=\x22#fff\
fff\x22\x0d\x0a     borde\
rcolor=\x22#666666\x22\
\x0d\x0a     borderopa\
city=\x221\x22\x0d\x0a     o\
bjecttolerance=\x22\
10\x22\x0d\x0a     gridto\
lerance=\x2210\x22\x0d\x0a  \
   guidetoleranc\
e=\x2210\x22\x0d\x0a     ink\
scape:pageopacit\
y=\x220\x22\x0d\x0a     inks\
cape:pageshadow=\
\x222\x22\x0d\x0a     inksca\
pe:window-width=\
\x221863\x22\x0d\x0a     ink\
scape:window-hei\
ght=\x221025\x22\x0d\x0a    \
 id=\x22namedview4\x22\
\x0d\x0a     showgrid=\
\x22false\x22\x0d\x0a     in\
kscape:zoom=\x221.2\
291667\x22\x0d\x0a     in\
kscape:cx=\x22-268.\
70903\x22\x0d\x0a     ink\
scape:cy=\x22226.91\
964\x22\x0d\x0a     inksc\
ape:window-x=\x2257\
\x22\x0d\x0a     inkscape\
:window-y=\x2227\x22\x0d\x0a\
     inkscape:wi\
ndow-maximized=\x22\
1\x22\x0d\x0a     inkscap\
e:current-layer=\
\x22svg2\x22 />\x0d\x0a  <pa\
th\x0d\x0a     style=\x22\
fill:#37c8ab;str\
oke-width:1.5376\
3843;paint-order\
:stroke fill mar\
kers\x22\x0d\x0a     d=\x22m\
 36.108101,186.4\
3995 c -1.691407\
,-0.71413 -4.517\
488,-0.85858 -6.\
631737,-3.13345 \
-1.281364,-1.378\
71 -4.131729,-6.\
43722 -4.131729,\
-6.43722 V 95.52\
7895 14.186505 c\
 0,0 0.09785,-4.\
7987402 3.622112\
,-7.7953982 2.68\
2346,-2.2807839 \
6.426571,-2.2583\
917 6.426571,-2.\
2583917 L 75.729\
307,3.696707 116\
.0653,3.2606988 \
l 28.11566,28.18\
24962 28.11566,2\
8.182496 -0.4381\
7,58.717629 -0.4\
3817,58.71764 c \
0,0 -1.60321,4.7\
3908 -3.29965,6.\
46354 -1.78715,1\
.81668 -6.7513,3\
.58719 -6.7513,3\
.58719 l -61.092\
98,0.31333 c -33\
.601135,0.17234 \
-62.476843,-0.27\
095 -64.168249,-\
0.98507 z M 158.\
35036,67.542824 \
c 0,-0.221039 -1\
1.41697,-11.8031\
23 -25.37103,-25\
.737968 l -25.37\
104,-25.33608 v \
25.737967 25.737\
968 h 25.37104 c\
 13.95406,0 25.3\
7103,-0.180851 2\
5.37103,-0.40188\
7 z\x22\x0d\x0a     id=\x22p\
ath817\x22\x0d\x0a     in\
kscape:connector\
-curvature=\x220\x22\x0d\x0a\
     sodipodi:no\
detypes=\x22cscccsc\
ccccccscscsscccs\
s\x22 />\x0d\x0a</svg>\x0d\x0a\
\x00\x00\x07\xb5\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22l\
oadc.svg\x22\x0d\x0a   in\
kscape:version=\x22\
0.92.2 (5c3e80d,\
 2017-08-06)\x22>\x0d\x0a\
  <metadata\x0d\x0a   \
  id=\x22metadata8\x22\
>\x0d\x0a    <rdf:RDF>\
\x0d\x0a      <cc:Work\
\x0d\x0a         rdf:a\
bout=\x22\x22>\x0d\x0a      \
  <dc:format>ima\
ge/svg+xml</dc:f\
ormat>\x0d\x0a        \
<dc:type\x0d\x0a      \
     rdf:resourc\
e=\x22http://purl.o\
rg/dc/dcmitype/S\
tillImage\x22 />\x0d\x0a \
       <dc:title\
 />\x0d\x0a      </cc:\
Work>\x0d\x0a    </rdf\
:RDF>\x0d\x0a  </metad\
ata>\x0d\x0a  <defs\x0d\x0a \
    id=\x22defs6\x22 /\
>\x0d\x0a  <sodipodi:n\
amedview\x0d\x0a     p\
agecolor=\x22#fffff\
f\x22\x0d\x0a     borderc\
olor=\x22#666666\x22\x0d\x0a\
     borderopaci\
ty=\x221\x22\x0d\x0a     obj\
ecttolerance=\x2210\
\x22\x0d\x0a     gridtole\
rance=\x2210\x22\x0d\x0a    \
 guidetolerance=\
\x2210\x22\x0d\x0a     inksc\
ape:pageopacity=\
\x220\x22\x0d\x0a     inksca\
pe:pageshadow=\x222\
\x22\x0d\x0a     inkscape\
:window-width=\x221\
525\x22\x0d\x0a     inksc\
ape:window-heigh\
t=\x22684\x22\x0d\x0a     id\
=\x22namedview4\x22\x0d\x0a \
    showgrid=\x22fa\
lse\x22\x0d\x0a     inksc\
ape:zoom=\x221.2291\
667\x22\x0d\x0a     inksc\
ape:cx=\x22-192\x22\x0d\x0a \
    inkscape:cy=\
\x2296.000006\x22\x0d\x0a   \
  inkscape:windo\
w-x=\x2257\x22\x0d\x0a     i\
nkscape:window-y\
=\x2227\x22\x0d\x0a     inks\
cape:window-maxi\
mized=\x220\x22\x0d\x0a     \
inkscape:current\
-layer=\x22svg2\x22 />\
\x0d\x0a  <path\x0d\x0a     \
style=\x22fill:#37c\
8ab;stroke-width\
:1.33333337\x22\x0d\x0a  \
   d=\x22m 37.55932\
2,154.44068 v -8\
 h 56.000004 56.\
000004 v 8 8 H 9\
3.559326 37.5593\
22 Z m 32,-48 V \
82.440678 H 53.8\
96671 38.234021 \
l 27.66265,-27.6\
62651 27.662655,\
-27.66265 27.662\
654,27.66265 27.\
66266,27.662651 \
h -15.66266 -15.\
66265 v 24.00000\
2 24 H 93.559326\
 69.559322 Z\x22\x0d\x0a \
    id=\x22path817\x22\
\x0d\x0a     inkscape:\
connector-curvat\
ure=\x220\x22 />\x0d\x0a</sv\
g>\x0d\x0a\
\x00\x00\x13\x09\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   ver\
sion=\x221.1\x22\x0d\x0a   i\
d=\x22svg2\x22\x0d\x0a   wid\
th=\x22192\x22\x0d\x0a   hei\
ght=\x22192\x22\x0d\x0a   vi\
ewBox=\x220 0 192 1\
92\x22\x0d\x0a   sodipodi\
:docname=\x22import\
_models.svg\x22\x0d\x0a  \
 inkscape:versio\
n=\x221.2.1 (9c6d41\
e410, 2022-07-14\
)\x22\x0d\x0a   xml:space\
=\x22preserve\x22\x0d\x0a   \
xmlns:inkscape=\x22\
http://www.inksc\
ape.org/namespac\
es/inkscape\x22\x0d\x0a  \
 xmlns:sodipodi=\
\x22http://sodipodi\
.sourceforge.net\
/DTD/sodipodi-0.\
dtd\x22\x0d\x0a   xmlns=\x22\
http://www.w3.or\
g/2000/svg\x22\x0d\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:cc=\
\x22http://creative\
commons.org/ns#\x22\
\x0d\x0a   xmlns:dc=\x22h\
ttp://purl.org/d\
c/elements/1.1/\x22\
><metadata\x0d\x0a    \
 id=\x22metadata8\x22>\
<rdf:RDF><cc:Wor\
k\x0d\x0a         rdf:\
about=\x22\x22><dc:for\
mat>image/svg+xm\
l</dc:format><dc\
:type\x0d\x0a         \
  rdf:resource=\x22\
http://purl.org/\
dc/dcmitype/Stil\
lImage\x22 /><dc:ti\
tle /></cc:Work>\
</rdf:RDF></meta\
data><defs\x0d\x0a    \
 id=\x22defs6\x22 /><s\
odipodi:namedvie\
w\x0d\x0a     pagecolo\
r=\x22#ffffff\x22\x0d\x0a   \
  bordercolor=\x22#\
666666\x22\x0d\x0a     bo\
rderopacity=\x221\x22\x0d\
\x0a     objecttole\
rance=\x2210\x22\x0d\x0a    \
 gridtolerance=\x22\
10\x22\x0d\x0a     guidet\
olerance=\x2210\x22\x0d\x0a \
    inkscape:pag\
eopacity=\x220\x22\x0d\x0a  \
   inkscape:page\
shadow=\x222\x22\x0d\x0a    \
 inkscape:window\
-width=\x222544\x22\x0d\x0a \
    inkscape:win\
dow-height=\x221001\
\x22\x0d\x0a     id=\x22name\
dview4\x22\x0d\x0a     sh\
owgrid=\x22false\x22\x0d\x0a\
     inkscape:zo\
om=\x221.3085938\x22\x0d\x0a\
     inkscape:cx\
=\x22-341.58806\x22\x0d\x0a \
    inkscape:cy=\
\x222.2925373\x22\x0d\x0a   \
  inkscape:windo\
w-x=\x2224\x22\x0d\x0a     i\
nkscape:window-y\
=\x226\x22\x0d\x0a     inksc\
ape:window-maxim\
ized=\x220\x22\x0d\x0a     i\
nkscape:current-\
layer=\x22g2568\x22\x0d\x0a \
    inkscape:sho\
wpageshadow=\x222\x22\x0d\
\x0a     inkscape:p\
agecheckerboard=\
\x220\x22\x0d\x0a     inksca\
pe:deskcolor=\x22#d\
1d1d1\x22 /><g\x0d\x0a   \
  id=\x22g2678\x22\x0d\x0a  \
   transform=\x22ma\
trix(0.55320042,\
0,0,0.59846942,8\
.6310018,192.674\
97)\x22><path\x0d\x0a    \
   style=\x22opacit\
y:1;fill:#0066ff\
;fill-opacity:1;\
stroke-width:2.1\
1176;paint-order\
:stroke fill mar\
kers\x22\x0d\x0a       d=\
\x22m 23.837619,-39\
.213637 c -2.322\
935,-0.980768 -6\
.204202,-1.17915\
2 -9.107857,-4.3\
034 -1.759793,-1\
.893485 -5.67441\
11,-8.840713 -5.\
6744111,-8.84071\
3 V -164.06992 -\
275.7821 c 0,0 0\
.134385,-6.59047\
 4.9745161,-10.7\
0601 3.683865,-3\
.13236 8.826087,\
-3.10161 8.82608\
7,-3.10161 l 55.\
396413,-0.59881 \
55.396423,-0.598\
8 38.61332,38.70\
512 38.61333,38.\
70513 -0.60177,8\
0.64128 -0.60177\
,80.641299 c 0,0\
 -2.20181,6.5085\
31 -4.53166,8.87\
686 -2.45442,2.4\
94982 -9.27206,4\
.926555 -9.27206\
,4.926555 l -83.\
90353,0.430319 c\
 -46.146941,0.23\
6687 -85.804098,\
-0.372116 -88.12\
7031,-1.35287 z \
M 191.72201,-202\
.5039 c 0,-0.303\
57 -15.67978,-16\
.2101 -34.84393,\
-35.34787 l -34.\
84394,-34.79592 \
v 35.34787 35.34\
787 h 34.84394 c\
 19.16415,0 34.8\
4393,-0.24839 34\
.84393,-0.55195 \
z\x22\x0d\x0a       id=\x22p\
ath817\x22\x0d\x0a       \
inkscape:connect\
or-curvature=\x220\x22\
\x0d\x0a       sodipod\
i:nodetypes=\x22csc\
ccscccccccscscss\
cccss\x22 /><g\x0d\x0a   \
    id=\x22g2568\x22\x0d\x0a\
       transform\
=\x22matrix(0.91289\
77,0,0,0.6471611\
2,24.343284,-37.\
486011)\x22><g\x0d\x0a   \
      id=\x22g1140\x22\
\x0d\x0a         style\
=\x22fill:#ffffff;s\
troke:none\x22\x0d\x0a   \
      transform=\
\x22translate(407.3\
0746,32.477612)\x22\
><rect\x0d\x0a        \
   style=\x22opacit\
y:1;fill:#ffffff\
;stroke:none;str\
oke-width:1.1775\
2\x22\x0d\x0a           i\
d=\x22rect1011\x22\x0d\x0a  \
         width=\x22\
123.59569\x22\x0d\x0a    \
       height=\x221\
39.93283\x22\x0d\x0a     \
      x=\x22-375.97\
61\x22\x0d\x0a           \
y=\x22-226.0116\x22\x0d\x0a \
          ry=\x2211\
.583521\x22 /><rect\
\x0d\x0a           sty\
le=\x22opacity:1;fi\
ll:#ffffff;strok\
e:none\x22\x0d\x0a       \
    id=\x22rect1013\
\x22\x0d\x0a           wi\
dth=\x2248.907463\x22\x0d\
\x0a           heig\
ht=\x2238.208954\x22\x0d\x0a\
           x=\x22-3\
66.80597\x22\x0d\x0a     \
      y=\x22-220.08\
357\x22 /><rect\x0d\x0a  \
         style=\x22\
fill:#ffffff;str\
oke:none\x22\x0d\x0a     \
      id=\x22rect10\
13-4\x22\x0d\x0a         \
  width=\x2248.9074\
63\x22\x0d\x0a           \
height=\x2238.20895\
4\x22\x0d\x0a           x\
=\x22-310.72836\x22\x0d\x0a \
          y=\x22-21\
9.76704\x22 /><rect\
\x0d\x0a           sty\
le=\x22fill:#ffffff\
;stroke:none\x22\x0d\x0a \
          id=\x22re\
ct1013-6\x22\x0d\x0a     \
      width=\x2248.\
907463\x22\x0d\x0a       \
    height=\x2238.2\
08954\x22\x0d\x0a        \
   x=\x22-366.3588\x22\
\x0d\x0a           y=\x22\
-174.88535\x22 /><r\
ect\x0d\x0a           \
style=\x22fill:#fff\
fff;stroke:none\x22\
\x0d\x0a           id=\
\x22rect1013-4-6\x22\x0d\x0a\
           width\
=\x2248.907463\x22\x0d\x0a  \
         height=\
\x2238.208954\x22\x0d\x0a   \
        x=\x22-310.\
28119\x22\x0d\x0a        \
   y=\x22-174.56882\
\x22 /><rect\x0d\x0a     \
      style=\x22fil\
l:#ffffff;stroke\
:none\x22\x0d\x0a        \
   id=\x22rect1013-\
1\x22\x0d\x0a           w\
idth=\x2248.907463\x22\
\x0d\x0a           hei\
ght=\x2238.208954\x22\x0d\
\x0a           x=\x22-\
365.81845\x22\x0d\x0a    \
       y=\x22-130.4\
1977\x22 /><rect\x0d\x0a \
          style=\
\x22fill:#ffffff;st\
roke:none\x22\x0d\x0a    \
       id=\x22rect1\
013-4-5\x22\x0d\x0a      \
     width=\x2248.9\
07463\x22\x0d\x0a        \
   height=\x2238.20\
8954\x22\x0d\x0a         \
  x=\x22-309.74084\x22\
\x0d\x0a           y=\x22\
-130.41977\x22 /></\
g></g></g><path\x0d\
\x0a     inkscape:c\
onnector-curvatu\
re=\x220\x22\x0d\x0a     id=\
\x22path817-5\x22\x0d\x0a   \
  d=\x22m 127.7435,\
178.61424 v -3.9\
6301 h 28.90983 \
28.90984 v 3.963\
01 3.96302 H 156\
.65333 127.7435 \
Z m 14.45492,-26\
.08983 -14.09816\
,-13.54029 h 8.0\
8158 8.08156 v -\
11.88904 -11.889\
04 h 12.38993 12\
.38994 v 11.8890\
4 11.88904 h 8.0\
8157 8.08156 l -\
14.09814,13.5402\
9 c -7.754,7.447\
17 -14.25871,13.\
54031 -14.45493,\
13.54031 -0.1962\
1,0 -6.70092,-6.\
09314 -14.45491,\
-13.54031 z\x22\x0d\x0a  \
   style=\x22fill:#\
5500d4;stroke-wi\
dth:0.674273\x22 />\
</svg>\x0d\x0a\
\x00\x00\x09~\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   ver\
sion=\x221.1\x22\x0d\x0a   i\
d=\x22svg2\x22\x0d\x0a   wid\
th=\x22192\x22\x0d\x0a   hei\
ght=\x22192\x22\x0d\x0a   vi\
ewBox=\x220 0 192 1\
92\x22\x0d\x0a   sodipodi\
:docname=\x22stats.\
svg\x22\x0d\x0a   inkscap\
e:version=\x221.1 (\
c68e22c387, 2021\
-05-23)\x22\x0d\x0a   xml\
ns:inkscape=\x22htt\
p://www.inkscape\
.org/namespaces/\
inkscape\x22\x0d\x0a   xm\
lns:sodipodi=\x22ht\
tp://sodipodi.so\
urceforge.net/DT\
D/sodipodi-0.dtd\
\x22\x0d\x0a   xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22\x0d\x0a   xml\
ns:svg=\x22http://w\
ww.w3.org/2000/s\
vg\x22\x0d\x0a   xmlns:rd\
f=\x22http://www.w3\
.org/1999/02/22-\
rdf-syntax-ns#\x22\x0d\
\x0a   xmlns:cc=\x22ht\
tp://creativecom\
mons.org/ns#\x22\x0d\x0a \
  xmlns:dc=\x22http\
://purl.org/dc/e\
lements/1.1/\x22>\x0d\x0a\
  <metadata\x0d\x0a   \
  id=\x22metadata8\x22\
>\x0d\x0a    <rdf:RDF>\
\x0d\x0a      <cc:Work\
\x0d\x0a         rdf:a\
bout=\x22\x22>\x0d\x0a      \
  <dc:format>ima\
ge/svg+xml</dc:f\
ormat>\x0d\x0a        \
<dc:type\x0d\x0a      \
     rdf:resourc\
e=\x22http://purl.o\
rg/dc/dcmitype/S\
tillImage\x22 />\x0d\x0a \
     </cc:Work>\x0d\
\x0a    </rdf:RDF>\x0d\
\x0a  </metadata>\x0d\x0a\
  <defs\x0d\x0a     id\
=\x22defs6\x22 />\x0d\x0a  <\
sodipodi:namedvi\
ew\x0d\x0a     pagecol\
or=\x22#ffffff\x22\x0d\x0a  \
   bordercolor=\x22\
#666666\x22\x0d\x0a     b\
orderopacity=\x221\x22\
\x0d\x0a     objecttol\
erance=\x2210\x22\x0d\x0a   \
  gridtolerance=\
\x2210\x22\x0d\x0a     guide\
tolerance=\x2210\x22\x0d\x0a\
     inkscape:pa\
geopacity=\x220\x22\x0d\x0a \
    inkscape:pag\
eshadow=\x222\x22\x0d\x0a   \
  inkscape:windo\
w-width=\x221858\x22\x0d\x0a\
     inkscape:wi\
ndow-height=\x22105\
7\x22\x0d\x0a     id=\x22nam\
edview4\x22\x0d\x0a     s\
howgrid=\x22false\x22\x0d\
\x0a     inkscape:z\
oom=\x221.7383042\x22\x0d\
\x0a     inkscape:c\
x=\x22-63.567699\x22\x0d\x0a\
     inkscape:cy\
=\x2286.578631\x22\x0d\x0a  \
   inkscape:wind\
ow-x=\x2254\x22\x0d\x0a     \
inkscape:window-\
y=\x22-8\x22\x0d\x0a     ink\
scape:window-max\
imized=\x221\x22\x0d\x0a    \
 inkscape:curren\
t-layer=\x22svg2\x22\x0d\x0a\
     inkscape:pa\
gecheckerboard=\x22\
0\x22 />\x0d\x0a  <g\x0d\x0a   \
  id=\x22g828\x22\x0d\x0a   \
  transform=\x22mat\
rix(1.377566,0,0\
,1.377566,-36.39\
3109,-35.973294)\
\x22>\x0d\x0a    <rect\x0d\x0a \
      style=\x22fil\
l:#002255;stroke\
:#002255;stroke-\
width:3.8;stroke\
-linecap:round;s\
troke-linejoin:r\
ound\x22\x0d\x0a       id\
=\x22rect844\x22\x0d\x0a    \
   width=\x2216\x22\x0d\x0a \
      height=\x2256\
\x22\x0d\x0a       x=\x2257.\
150547\x22\x0d\x0a       \
y=\x2294.620117\x22\x0d\x0a \
      ry=\x225.7970\
2\x22 />\x0d\x0a    <rect\
\x0d\x0a       style=\x22\
fill:#0088aa;str\
oke:#0088aa;stro\
ke-width:3.8;str\
oke-linecap:roun\
d;stroke-linejoi\
n:round\x22\x0d\x0a      \
 id=\x22rect846\x22\x0d\x0a \
      width=\x2216\x22\
\x0d\x0a       height=\
\x2280\x22\x0d\x0a       x=\x22\
89.150543\x22\x0d\x0a    \
   y=\x2270.620117\x22\
\x0d\x0a       ry=\x225.7\
9702\x22 />\x0d\x0a    <r\
ect\x0d\x0a       styl\
e=\x22fill:#00aa88;\
stroke:#00aa88;s\
troke-width:3.8;\
stroke-linecap:r\
ound;stroke-line\
join:round\x22\x0d\x0a   \
    id=\x22rect848\x22\
\x0d\x0a       width=\x22\
16\x22\x0d\x0a       heig\
ht=\x2232\x22\x0d\x0a       \
x=\x22121.15054\x22\x0d\x0a \
      y=\x22118.620\
12\x22\x0d\x0a       ry=\x22\
5.79702\x22 />\x0d\x0a  <\
/g>\x0d\x0a</svg>\x0d\x0a\
\x00\x00\x04\xd1\
\x00\
\x00\x1e\x5cx\xda\xed\x99Ko\xe36\x10\xc7\xef\x0b\xec\
w0\x94K\x8bB\x14\x1f\x22E\xaav\x16(\x82\x05\
z\xd8K\xbbE\xcf\x8cD\xdb\xdaH\xa2!\xc9v\xb2\
\x9f\xbe#\xeb\xed$N\xddE\x8b- \x01N\xc2\x99\
\xe1\xeb7\xc3\xbf)d\xf9\xe11K\x17\x07S\x94\x89\
\xcdW\x0eA\xd8Y\x98<\xb2q\x92oV\xce\x1f\x9f\
?\xba\xd2Y\x94\x95\xcec\x9d\xda\xdc\xac\x9c\xdc:\x1f\
n\xdf\xbf[\x96\x87\xcd\xfbw\x8b\xc5\x02\xba\xe7e\x18\
G+g[U\xbb\xd0\xf3v\xfb\x22E\xb6\xd8xq\
\xe4\x99\xd4d&\xafJ\x8f \xe29\xa3\xf8h\x88\x8f\
\x0a\xa3\xab\xe4`\x22\x9be6/O]\xf3\xf2f\x1c\
]\xc4\xeb>\xfcx<\xa2#;E\x11\xa5\x94\x87\xa9\
G\xa9\x0b\x11n\xf9\x94W\xfa\xd1=\xeb\x0b\xeb|\xa9\
/\xc5\x18{\xe0\x1b\x85\xfe\xcd\xb0\xb0\x048;\xf8\xf4\
\xf1\x9d\x01\x95v_Df\x0d\x1d\x0d\xcaM\xe5\xdd}\
\xbe\xeb\x9d.Fq\x15\x8f\xc7I\xf2\x872\xd2;3\
\x99\xb736\x18tf\xca\x9d\x8eL\xe9u\xf6f\x80\
c\x12W\xdb\x95\xe3\xcb\xa6\xb95\xc9f[\x0d\xedC\
b\x8e\xbf\xd8\xc7\x95\x83\x17x\xe1\xcbEo\x1f\xd2L\
\x1aK\x12\xaf\x1c\xd8\x9ehZ\xddZ\xc3\xd8F\xf5\xdc\
+'\xd2i\xb4Oue\x0b\xd4S\xe8\x96\x12\xf6\xc3\
a\xa4(\xf2\x17?\xec\xf3\x87\xdc\x1e\xf3\x1f\x9d\xdb:\
p\x99\x99J\xc7\xba\xd2\xa7^\xcd\x5c\x9d\x89\xd0&\x06\
\xa2 u\xe1ow\x1f\xdb&\x18\xa2(\xfc\xd3\x16\x0f\
]\x1b\x9e:D\xdf\xdb=l\xd1\xb9\x1d\xec\xcb8\x0a\
\x01v\xa6\xab\xdb$\xd3\x1bS'\xea'`\xbb\xf4\x06\
\xc74\xbaz\xda\x99\xd1\xb8\xcd\xc8\x85i\xf2\xf6b\x05\
\xc7Q\x96\xd4\xbd\xbc\xdf\xab$M\x7f\xad\xa7q\x16\xde\
\xf9\xb0I\x95\x9a\x91u\xe9\xb5{\xe8\xf6\xe8\x8d7\xb9\
\xf4:\x0aM36\xebr\x84\xa8n\x12\xdcM\xb2\xec\
sR'$\xae3\xdb\xc6\xee`)\x91Mm\xb1r\
n\xd6\xa7\xc7i=\xf7\xb6\x88M\xd1\xf9\xc4\xe9\x99\xfa\
,\x14\x15l\x0b\x0a\xa1\xb3\xdb\xfb/&\xaa*\x9b\x9a\
B\xe75\x0bXB\xeb\xda\x14Pm/:\xf6Il\
^\xf4\xf4%R/\xb2\x9f\xecew\xb9\xd5\xb1=\xae\
\x1c\xfa\xcc{Lr\xf0\xb8m\xb1\x13)\xd8k!\xdd\
\x01 \x98rg\xc4\xb2g&;k\xb9\xb5\xc7zC\
+g\xad\xd3\xd2<\x1b\xf0\xab\xb5\xd9\xcaQH\xb2\xd3\
\xf3\xcc\x1f\xc1\xa9r\x15\xc2\x0a\xfb\x81\x22\xcf\xdd\xb0M\
\xca\x90\xcf})\xc5k\xab\x85!x\xf0\x9a\xb3\x1e\xe0\
Ug\xa6\x1f\x93,\xf9j\xe2Q\xe6\x86\xb9\xf7E\x01\
b\xeb\xa6\xfa\xc9\x14\xed\xb1\xee\xaah\xa7\xabm\x1b\x0f\
}?\x81.l}y\xf0\xe5\xd6\xf5\xe5\xd71\xb1:\
\xb0\xcf\xc4\x1aJ\xbeV\xfc\xbc\xaf\xf9e\x01U\xd2\xa1\
\xac\x9eR\xc8z\x9b\xde\x90\xfc\x5c\x87\x877,\x88\xa4\
\xbe?5\xdc\xc1WV\x85}0a=V\xfbw\x93\
\xd7\x10\xb4\x83\x07\x92\xc2\xa7\xb3\xa7In`Caa\
\xf7y<6~\xb1I\x1e\xde\x9b\x83I;+\x9cM\
S\xa4\x80\xa4\x0a\xfd\xce\x16k\xa8\xa8\xa2\xd0O\x93\xc9\
j\xab]\xafKS\x85\xb8\xb3\x0d\xab\xdb\xe9\x04\xc0\x9d\
\x8e\x06\xf4\x02\xe1H\xc7L\xea=K\xd2\xa7\xb3\xadG\
FQ\x10\xf8\x8c\xf4\x89\xe8U\x98\x22\x1c\xf8\x0a\xf7\x18\
!\xdf\x121\x82}6T\x0c\xa4\x99!\xca}\xca\x82\
>\xae\x00#GXJ\xc2\x88\xba\x82xs\xfa\xaf \
\xce|\xca\x09\x93\xe2{'\xee\xb23\xe6\x94#_)\
N\xfcs\xe6\x02)\xc2)gb\xc4\x9cPD\x95 \
\x98\x8d\x98\x075^\xc9%\x193\xc7p\xda\x05\x15L\
\xf1\x7f\x13:\xa1R\x09!\xe5\xf7\x0f\xdd=/u~\
\x8e\x9bO1\xfbLp1\xc6\xdcH \x0b\xe4\x14\xb3\
\xc0\xbe\xe0D\xa8\x19s\x83\xf9Y}_\x06\xad\x10\x09\
0%t\x0a\x9acZ\xcb\xc5\x0c\xfa\x12h~\x0dh\
P\x99\x004\x82\xfbg\xa0\x814\x9fA_\x06M\xaf\
\x95\x0e\x82\x09\xe1c\xd0\x0a\x05X0\xccg\xd0\x97\xa5\
\xc3U\xd7\x8a\x07\x08\xf2\xf0\x22\xd0\xa2\x86\x1b\x88/f\
\xd4\x97\xc5\xc3%\xd7\xca\x07W>\x0e\xa6\xa8%H\xb7\
\x9c\xab\xfa2\xea\xe0Z\xf9\xe0p\xc3\x9b\x5c\xaa9\x92\
\x94\x063\xe7\xb7\xd4\x03_\xab\x1e\x8aQ.\xcfH\x83\
R\xcb\xf9\x1b\xf1-\xf5PW\xaa\x87\xc4RM\xdeZ\
\x00\xb5\x22R\xd0\x19\xf5e\xd4\x02\x7f\xab|\x90\x00\xd1\
\x00\x13Ef\xd2o\xe8\x87\xf8V\xfd\x00\xd4\x8cH\xc2\
f\xd2o\xc8\x07\xfd'\xf2qV\xd4L\x88\xe1>\xf2\
\x1f\x92\x06\x1d\x93\x01Q\xff\x0f\xf5\x80\x9fo^\xf4\x08\
FP<\x9c\x93\x11s\x06BB)\xc3tz\xe1S\
\x92c1\x81N\xa0\xe2\x83\x8021Ww\xcf\x5c^\
S\xdd@\x9a1)Ep\xf6f.9\x19\xde\xd6g\
!y\x05\xf5\x95\xd7\xeb\x1a\xb6\x80\xafB1\x95\x12\x1f\
c%.j\xc9\xb2\xfeG\x1c\xfc\xfe\x0bIo*\xca\
\
\x00\x00\x09N\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22d\
elete.svg\x22\x0d\x0a   i\
nkscape:version=\
\x220.92.4 (unknown\
)\x22>\x0d\x0a  <metadata\
\x0d\x0a     id=\x22metad\
ata8\x22>\x0d\x0a    <rdf\
:RDF>\x0d\x0a      <cc\
:Work\x0d\x0a         \
rdf:about=\x22\x22>\x0d\x0a \
       <dc:forma\
t>image/svg+xml<\
/dc:format>\x0d\x0a   \
     <dc:type\x0d\x0a \
          rdf:re\
source=\x22http://p\
url.org/dc/dcmit\
ype/StillImage\x22 \
/>\x0d\x0a        <dc:\
title></dc:title\
>\x0d\x0a      </cc:Wo\
rk>\x0d\x0a    </rdf:R\
DF>\x0d\x0a  </metadat\
a>\x0d\x0a  <defs\x0d\x0a   \
  id=\x22defs6\x22 />\x0d\
\x0a  <sodipodi:nam\
edview\x0d\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0d\x0a     bordercol\
or=\x22#666666\x22\x0d\x0a  \
   borderopacity\
=\x221\x22\x0d\x0a     objec\
ttolerance=\x2210\x22\x0d\
\x0a     gridtolera\
nce=\x2210\x22\x0d\x0a     g\
uidetolerance=\x221\
0\x22\x0d\x0a     inkscap\
e:pageopacity=\x220\
\x22\x0d\x0a     inkscape\
:pageshadow=\x222\x22\x0d\
\x0a     inkscape:w\
indow-width=\x22186\
3\x22\x0d\x0a     inkscap\
e:window-height=\
\x221025\x22\x0d\x0a     id=\
\x22namedview4\x22\x0d\x0a  \
   showgrid=\x22fal\
se\x22\x0d\x0a     inksca\
pe:zoom=\x220.30729\
167\x22\x0d\x0a     inksc\
ape:cx=\x22-93.9206\
3\x22\x0d\x0a     inkscap\
e:cy=\x2249.326186\x22\
\x0d\x0a     inkscape:\
window-x=\x2257\x22\x0d\x0a \
    inkscape:win\
dow-y=\x2227\x22\x0d\x0a    \
 inkscape:window\
-maximized=\x221\x22\x0d\x0a\
     inkscape:cu\
rrent-layer=\x22g83\
1\x22 />\x0d\x0a  <g\x0d\x0a   \
  id=\x22g831\x22\x0d\x0a   \
  style=\x22stroke:\
#37c8ab;stroke-w\
idth:21;stroke-m\
iterlimit:4;stro\
ke-dasharray:non\
e\x22>\x0d\x0a    <path\x0d\x0a\
       inkscape:\
connector-curvat\
ure=\x220\x22\x0d\x0a       \
id=\x22path812\x22\x0d\x0a  \
     d=\x22M 44.745\
763,46.372881 14\
5.91476,146.4900\
3\x22\x0d\x0a       style\
=\x22fill:none;fill\
-rule:evenodd;st\
roke:#b3b3b3;str\
oke-width:21;str\
oke-linecap:roun\
d;stroke-linejoi\
n:miter;stroke-m\
iterlimit:4;stro\
ke-dasharray:non\
e;stroke-opacity\
:1\x22\x0d\x0a       sodi\
podi:nodetypes=\x22\
cc\x22 />\x0d\x0a    <pat\
h\x0d\x0a       inksca\
pe:connector-cur\
vature=\x220\x22\x0d\x0a    \
   id=\x22path812-3\
\x22\x0d\x0a       d=\x22M 1\
44.62039,46.8043\
35 46.040128,146\
.05858\x22\x0d\x0a       \
style=\x22fill:none\
;fill-rule:eveno\
dd;stroke:#b3b3b\
3;stroke-width:2\
1;stroke-linecap\
:round;stroke-li\
nejoin:miter;str\
oke-miterlimit:4\
;stroke-dasharra\
y:none;stroke-op\
acity:1\x22\x0d\x0a      \
 sodipodi:nodety\
pes=\x22cc\x22 />\x0d\x0a  <\
/g>\x0d\x0a</svg>\x0d\x0a\
\x00\x00\x07\xa3\
\x00\
\x00&\xfax\xda\xdd\x9a\xed\x8f\xa3\xb8\x19\xc0\xbf\x9ft\
\xff\x03e\xbf\xec\xaa\xc1\xf8\xf1\xbb\xd3dO\xea\xadN\
\xba\xaf\xedU\xfdX\x11 \x19\xba\x04\x22 \x93\x99\xfb\
\xeb\xfb\x18B\x02C2\xda\xdbI5i\x99\x1d\xed`\
?6\xf6\xcf\xcf\x9b\x0d\x8b\x9f\x9e\xb6\xb9\xf7\x98Vu\
V\x16K\x1f\x08\xf5\xbd\xb4\x88\xcb$+6K\xff\x1f\
\xbf\xfd\x12\x18\xdf\xab\x9b\xa8H\xa2\xbc,\xd2\xa5_\x94\
\xfeO\x9f\x7f\xfca\xf1\xa7 \xf0~\xae\xd2\xa8I\x13\
\xef\x905\x0f\xde\xaf\xc5\xd7:\x8ev\xa9\xf7\xf1\xa1i\
v\xf30<\x1c\x0e$;\x16\x92\xb2\xda\x84\x9f\xbc \
\xc0\xa6\xd8\xb8~\xdc\xfc\xf8\x83\xe7y\xf8\xec\xa2\x9e'\
\xf1\xd2?\xb6\xd9\xed\xab\xbc\x95M\xe20\xcd\xd3mZ\
4u\x08\x04B\x7f \x1f\x9f\xe5c7\x82\xec1\x8d\
\xcb\xed\xb6,\xea\xb6iQ\x7f\x18JW\xc9\xfa$\xee\
\x86t\xe0\xad\x14XkC\xcaB\xc6\x02\x94\x08\xea\xe7\
\xa2\x89\x9e\x82\x17mq\x9c\x97\xda2Ji\x88u\x03\
\xd1o\x14\x9b\xd7Hv\x87\xbf'\xf9\xbe\x80\xd4\xe5\xbe\
\x8a\xd356LI\x916\xe1\x97\xdf\xbe\x9c*\x03J\
\x92&\x19\xf6\xd3\x83\x1d=wD\xbb\x88\xb6i\xbd\x8b\
\xe2\xb4\x0e\xfb\xf2\xae\x83C\x964\x0fK_\x98\xee\xf6\
!\xcd6\x0f\xcd\xf9\xfe1K\x0f\x7f-\x9f\x96>\xf5\
\xa8'\x0c\xfe#\xd4]\xd0Ug\xc9\xd2\xc79\xb1\xa3\
\xf0Yq\xfa\xfa\xe3\xb3\xe6\xa7*J,#\xdc\xfb\xc8\
\x04\x95R\xa8\x99\xc7(\x98\x80\xf2\x00\xe0S\xd7\xa6\x9f\
\xe6<)c7\xec\xa5\x1f\x97yY\xfdkSe\x09\
q\x00?;\xb1E\x92\xae\xebV\xbe\x1b\x85\xbb\x15\xbe\
\x17v\x95\xa7>\x5c\x07\x89\x9b\xc4@t\x15\xd5\xc7\xc9\
{\xde.\xda\xa4m\xf7K\xff\xc3\xba\xbd\xfa\x9aUY\
%i\xd5\xd7\xa9\xf6\x1a\xd7\x95\xc83k\x9e;;\xe9\
\xfb\xef'\xec:>\x09\xd0+\x02\xf5C\x94\x94\x87\xa5\
\xcf&\xb5\xbf\x97\xe5\x16;f\x04\x844\x9cO\xeac\
\x5c\x12\x90\x843!5Lk\xf1\x99L\x13\x03\x9a\x82\
\x98\xd4\x22\xd7\xbd\xb3\xa5`_d\x0d\xea\xea\xeei\xda\
\xc1\xbe\xaa\x9cD\x1e=\xa78\xfd\x0d\x17\xe2\xf4\x94\xfa\
\xa1<\xb8\xb5X\xfa\xeb(?\x93\xbc\xde\xd9!+p\
\x96\xc1Q\xd3\xc0(~M\xa4\xd7>\xa0L^\x93\xc1\
\x89K}\xad\xb2\x9d\xf7\xb5\xcam\xf4\x94m\xb3\xdfS\
\x1c9\x9c4e\x9b6Q\x125\xd1@?\xfa\x22\xdd\
i\x1a\x0a\xa1O\x98\xff\xed\xcb/\xc7[,\x88\xe3\xf9\
?\xcb\xeak\x7f\x8f\x97\x13\x89V\xe5\x1eG\xef\x7f>\
\x97/\x92x\x8eV\xbc\x8d\x9a\xcf\xd9\x16W\xdcy\x80\
?\xa3\xd1.\xc2s\xc5X\xbay\xde\xa5\x83~\xbb\x9e\
\xab\xb4s\x08\x17]c\x12o3\xd7*\xfc{\x93\xe5\
\xf9\xaf\xee1\xfd\xf4\x06\xddfM\x9e\x0eJ\x17\xe1q\
\x0e\xfd\x1c\xc3\xe1$\x17a\x0f\xa1\xbb\xdd\xbcD\x9aG\
\xab4_\xfa?G\xbb\xc8\x9b\xea\xdf\xa6*\xf7\xbbm\
\x99\xe0x[\x0d\xf2\x07t\xdb\x82S\x93\xa6\x8a\x8a\xda\
qX\xfa\xed\x9f9\x86\x90\x8ft\x16\x00\xa5\x82p\xc5\
\xd8\xa7\xd3\x22lN\x13r\xdd\x8cTr\xd4\x0f\x22\xad\
\xb2\xa7\x8f\x94\x18\xa5@q\xc9g\xd4\xfd\x9co\x19Q\
Rk\xa3\xed\x0c\xb8&\xa0\x19\xef]O\xab\xde\xcds\
\x8e\xe3^#\xca\xf9\xd1%\xfc\xa5n\xaa\xf2k:\xff\
 \x12\xf7s^\xdf\xc5.j\x1e\x06\x8bu\xb6\x9f\xb2\
(\xd2\xb8)\xab\x00-\xe91j\xf6\x15vI\xfd\xa1\
(\xce\xc1\xb5\x16\xec\xac\xcd\xeer\xfa\xe7\xa1\xddkF\
\x15\xc3\x11R\xfc\x9b\x09\x90\x1e\xa0\xe7\x14\xda\x081\x0b\
8Q\x0c`\xd8\xea\xd2\xa0\xddMP\xed\xf3t\x9e>\
\xa6E\x99$\xa7i\xc4\xca\xb9\xf0\xe3mg\x97s\xd7\
\xbb\xb2\xa0\xb4\xda=\xf55y\x86\x93\x88v\xf3\xd5\xbe\
i\x86e\xff.\xb3b\x8e:\x97V}\xe9\xd1\xd3\xcd\
a\xa8x\xb7\xa1#'t\x98[KC\xadrt4\
\xb1\xa8\x09\x1e'\x94\x013|\x16\x18\xa2\x04\xb5\xdf\x0f\
g\xbd\xb6\xab)\x1c\x83\x8b\xc15\xd3w\x06\x07&p\
\x14\xa1\xd2hi%\xc2a\x9c\x80\x92\xcc\xd3\x84\xe1\x8a\
+)g\x181\xb45\xdf\x0f\x87\xd2D\x9c\xec\xe1\x08\
\x07\xfe8\x91\xf6&Gg\xdc\xccE_\x96D\x18\x0d\
\xab*z\x9e\x17\x98Z\xfe\xf7\xd9\x9d\xa3\xd0Y\xb1\x10\
\x14Hc\x19\xb2\x13\x9ah\x84\xe7a^\x82\xb6(5\
\x07tJDi\xfd\xfd\xf0\x14s\xba55;.\x05\
\x03s_\x9a\xa5\xe0\x92\xd9\xa1\xdb\xb4\xda\x99\x1d7D\
+\x81t$\x11\xca\x18ng\x8a0F\xdf\xa0Y+\
\xbd^\x0b51;t}\x96\xdd\x9dO\xb2\x17\xcc\x8e\
\xa3\x1b\x92\xd2yl\x8eP\xa4\xf5\x80\xe3\xdaZn,\
\xcc\x80X\xab\xdf\xe4\x93\xf4\xfa\x92\xc3\x96\xf8\x1c\xe0\xf7\
\x05G_\x08g\x08\x04\x942\xad\xe6PLi\x19x\
\x92\x00\x005\x1a\x15G\xa07\x7f\x8bK\x1a\x84\xe8\x13\
\x1b-85\x82\xc2\x9d\xb1\x99\x063\x81\xeb\x08RQ\
\xe8\xacJR-<\x8c\xfeV\xf2\xd6\xe3\xa0\x09\xd0\xb7\
\xd0\x89\xd5z\xcd\xcd\xc4\xac8U\x1a\xb4\xbd3\x9f3\
5+\xcc\xcf\x98\x11\xc0\x84\x0b\xf5\x82Ha-\x9a\x1a\
\xfan\xc6\xcc\xcceD\x94\xc3\xad\xe1X\xc0\xb4\xd0\xde\
\x9b\xe6L\xfd\xb1`D\x1at9.\xd0c\xd4\xd7\x5c\
x\x81%NT2\x97#r\xa9\xe0-.g\xa5\xa7\
.G[*\xf0qw\x16\xac$\xbf\xe4r\xa8\xb1\xb4\
U\x1c\x0c\xebhb^\xecQ\xc2)\xd5\x80\x194E\
NLy\xc2%F\x00\x88K\x13\x09\x98F\xbe,x\
\x8b[r\xe1~\xa2[\xcc`<\x90\xe2\xbe\xf8\x8d3\
\xc2.\xd8\x03\xba\x22.Y\x9bc[\xdc0\x19\xed\x19\
\x1c\xbeT\x1a\xf7O\xa0\xc7\xc8o\x81Fc\x8a*\x19\
\xbd\xb7h\x06\xc1T\xb98#\x06\xf3D\xe5\xf2D\x0e\
DhT%T)\x03\x0a\xf3F\xa7:\x16y\xbd\xc5\
\xf4Lr\xc1\xf48\xe5\x9c[v;>qV\xc5\xf9\
\xf0\xac\xa1rGY\xa3\x10\xe5\x0e\x92p+n\x08\x87\
\xf16\xd5\x9d?1\xe7\x90\xa55\xe6\x12:\x1c\xab\xfa\
&\x04\xa7\xb1\xbdJD\xb1\x97D\xe0\x1d@`J\x07\
\xdcN@p\x85\xce\x02=\x8b\xbc\x06\x22\xe07C\x81\
i2&\x83\xef\x8f\x02C\x0eW\xa0^\xa2\x10m\xd2\
k\xc6\xc9\xee\x08\xc5\xed\xb4\xc2\xae\x9c^\xbc?\x0a\xee\
\xfc\xa3\xe6\x13\x14\x18d\xa8\xe0\x82_E\xa1oh \
\xd3\x13\x9d\xf7@\xe1v\xcd\x98\xd4O<\x85ABV\
Kv\x15\x85\xbc\x19\x8aK\xbb\xecwA!\xdd\xa1\x11\
\xbcD\x81Y,s\xe9\xfeu\x14\x5c\xfe\xffY\x08\xee\
\xf6$\xc8\x97,0G\xb3\x0a\xf5\xc5\x5cw\x16\xec\x86\
&2Mh\xdf\xc5q2\xdc\xd2\x98\x89^\x08\xdc\xe8\
\xe1>g\x9c\xe7\x8fX\xd8\x9b\xa1\xa0\xd4\x9d\xb6\xdcA\
8eDY5\x89!\x80)\x95\xb0\xc0\xae\xab\x05\xdc\
\x0cEd\xef\xc3qb\x8e\x8d\x8bo'\x8e\x93\xe2\x86\
DJz=\xb3\x80\x1bF\x11\x87\xe2\x1e\xf4\x02M\x84\
3;q\x17\x98j\x1bj\xc48\xbc\xbc\x80Ao\x08\
\xc3$\xf7\x00\x83\xbbwA|\x0a\x03mG\x08x\xc5\
Fn\xe80\xee%\xbd\xe0\x9a\x18\xc1&F\x82\xb2\x1a\
\x98f\xaf\xb0\xe07d\x91\xde\xc5^\x84YBA^\
\xca/\x04H\xa5\xec+0\xd4\xffJ$\xb9\xd5\x0e~\
<\xe3n\x0foq\xcf\xa6\xbbw=\xdc\x10cAx\
\x81;FS\x0a\xf7\xf5\x81$\x0c\xc4k{\xf8\xd6 \
\xfe\x98\xc5\xdc|\x0f\xbf\x087\xa7/\x14\x10\xc7\xc5W\
\xd8\xed\xcb\xb4\xd1zR\xb4!+AH~\xce\x13\xdb\
k<ZN\x8c\xd4\x02\x04\x93\x93qU\xe5\xbeH\xbe\
\xfd]\x9e?zq\xefF*`x8\xd0\x7f\x82$\
\xdc\x9b\x01i\x065\xa7\xaf\x91\xa6UN\xd5\xddq\x9a\
\xa6\xc3\x94\xa9;\xaeP\x84\xd9\xe1+\xe0\xaa-&`\
\x94\x96\xe7/?Zx\x0b\xf7A\x06\xfe\xff\x1f\x91\x19\
%\xb1\
\x00\x00\x05\x0c\
\x00\
\x00\x11\x0ex\xda\xd5WKo\xdb8\x10\xbe\x17\xe8\x7f\
\x10\x94K\x8b\x8d(\x92\x22ER\xb5S`Q\x14\xd8\
\xc3^v\xbb\xd83#\xd1\xb6\x1aI4(\xd9N\xfa\
\xeb;\xb4%Yj\x9c\x22\xed\xbe\xbar\x82\x883\xc3\
y|\xf3r\x16o\xef\xeb*\xd8\x1b\xd7\x96\xb6Y\x86\
\x04\xe100Mn\x8b\xb2Y/\xc3?>\xbc\x8fd\
\x18\xb4\x9dn\x0a]\xd9\xc6,\xc3\xc6\x86oo^\xbe\
X\xb4\xfb\xf5\xcb\x17A\x10\x1c\xca\xa2\xdb,C&\xc3\
\xe3qc\xca\xf5\xa6;\x9f\xf7\xa59\xfcl\xef\x97!\
\x0ep\xc0d0\xd0\xcbb\x19\x82\x0a\xdaK\x9d\xed\x93\
\x9e\xdf\xdc\xb5\xb9\xde\x9al\xcaB4x\x855\xc6\xf9\
\x8a'\x89\xba\x0e(\xa64\xc2\xf0\xc3^\x9fn\xb5\xe0\
\xf7\x16~\xb3\xc2\xe6\x8d\xae\xc1\xddM\xd9vv\xedt\
\x8d\xc0\xdaI\x08\x02n\xdal0\x00\x22]\xb7\xcd\xe2\
\xf8p8\xa0\x81\x88\xac[\xc7^A\xbb\xd5\xb9i\xe3\
\x81>U0\xd8\x1a\x15\x0c\x04\xd4\xda\x9d\xcb\xcd\x0at\
\x18\xd4\x98.~\xf7\xe1\xdd\xc8\x8c0*\xbab\xa2g\
f\xff\x90\x1c-S\x8cq\xfc\x85\xbfp|\xae\xa8+\
V\x97D\x89R*\xc64\x06\xcc@\x22j\x1f\x9aN\
\xdfGM{5\xbd\x9b\xe7\xe3\xd5\xdc\x19\xdd\x95{\x93\
\xdb\xba\xb6M{\xc2d.]\x9c\xa5\xb7;W\x1dE\
\x8a<6\x95\xa9M\xd3\xb51\xe4,\x0eo\xfc\x85E\
m:]\xe8N\x1fo\x9f\xf2?\x90\x08=\xc9\x80\x14\
8\x96\xfd\xf6\xee}\x7f\x04B\x9eg\x7fZw7\x9c\
\xe1\xf1\x22\xfa\xd6\xee\xa0\xc8\xc2\x9b3}Q\xe4\x19@\
^\xeb\xee\xa6\xac\xf5\xdaxP~\x02/\x17\xf1\x991\
\x97\xee\x1e\xb6f\xa2\xf7\xa4\xd9\x99S\xf6.\xc6U\xe4\
u\xe9o\xc5\xbfweU\xfd\xe2\xcd\x84A|v6\
\xee\xbd\x1d\xa2\x89\xa7\xe1,\xe2!\xde\xd3\xb10\xabv\
\x02\x86?\x12<\xa8[\x8c\x95\xec\xab\xb0\xf0]\xd4\xcb\
n\xc1hn+\xeb\x96\xe1\xd5\xea\xf8\x84=\xe7\xd6\xba\
\xc2\xb8\x81\x97\x1e\x9f9\xcfB5C\x00\xd0K\x03\xdd\
\xde~4y\xd7\xd9\xca8\xdd\xf8\xa8\xc1\x85\x9e\xb5v\
\xd0\xd9\x17\x19\xbb\xb20\x179c\xd3z'Gc\x97\
\xd9\xedF\x17\xf6\xb0\x0c\xe9#\xee\xa1l\x80\x13\xf5\x83\
\x852E\x9e\x12\x19\x86\x0d\xc1d\x8c\xd4c9b&\
\x07j\xbb\xb1\x07\x1f\xd02\x5c\xe9\xaa5\x8f\x14~\xb2\
\xb6^\x86\x1c)\xc5S\x91&\x8f\xf89L\xb0(\x15\
H\x10\xceR\xf6\x98\x0da\xa6Hp&S!\x9e\xf2\
\x16T\xa4\xea)&(\xa0O\xde\xac\xf5}Y\x97\x9f\
L1\xc9\xdc\xd9\xf6\xce9h\xb6\xa8\xd2\x0f\x06\x12\xbf\
f\x84_F<\xdf\x98\xfc\xce\xb8[\xab]\xe1\xb32\
\x94\xdaVw\x9b^\x1e\xe8\xbf\xc2\xa0\xde0\xb9gr\
\x131\xf9i\xd0\xb4\x82\x82\xf7\xc3\xbf1S\xa0\xfdU\
6*ZO837:\xa8\x94\xd6\xf7 \xf4\xbc\xee\
\x5cy\xff\x8a \xc0\x8ap!\xaf1|\x08J\x19S\
\x09\x17\xd7\x11\xe5\x88Ixc\xf0*\x11\x91<Q\xe2\
\xf5\x98\xc5\xee\xa1\x82\x82k;g\xefLvE\xb4\xff\
\x8c\xb3c=6\xf3\xc4\xde\xf1\xb5\xd2\x9d\x01\x93\x18\xa7\
\x82\xca\xe4hDJA\x95\x1a5\x8fN3v&]\
676\xfc\xc4`\x7fY\xd0\xf0\x92\x0f}\xcc\x18\xc9\
D\xa9\x94av\x0czr\xe4\x88$\x18 \xf0o\xa9\
\xc4\x8a\xd3\xd7OzA\x09\x94\x98<O\xbei\xfa&\
\xe2>_\x99O\xd7\x1b\xff\x16\xb9]e2\xb37\x8d\
-\x8a7sU\xfd\xf1\xd4o\x19F\x80=\xc1#\xb5\
*\x1b\x03\x15\x949\xbbk\x8a)\xf1\xa3-\x9b\x0c\xc6\
\xa1q\x03\xf5x\xa8\xa0P\xbb\x8c\x0d\xb4BC\x9f;\
\xa7\x1fN\xbe\xf4\xd4~4d$\x9c8\xee\x17B@\
8\xa28\xe5\x90$\x92\x22,)\x94E\x00+\x13c\
\xc6\xaf\xa1\x1e$')\x11\xd3[c\x15\x12&g\xf4\
\xb1=l\x03\x11t\xd6E\xd0({\xdd\xed\x9c\x99\x8c\
\xa4`\xfa\xa5\x01\xc01~\xbc\xc3N\xce\xf3\xd9`\xff\
\xdb1&LP\xfa_b\x8c)&\xd7\x8c!\x05\x8d\
\xc0\xd2 I\x90H\x15N\xe8\xb5\x07\x9b\x93\xa7 \x8e\
\xf8?\x04\xf2\x22^\x8f\xdf\x01@\xd3\x97\xd5\x7f\x84\xfa\
\x8a@\x8fp<`;\x8dv\x00V\xc2C\xd8\xf3\x80\
\x9dQ\x9f\x01\xecV\x970f\x8f\x8b4\xab\xb5\x83Q\
\xda\x06'\xc9\xe3t\x9c\x8f\x12\x1f\x04\xb4\xd1d \xf4\
\xfb,AL\x08\xae\xa6\xa3\xe2\xbc\xc6\x90\x12\x82&\x13\
\x8cagP\x8c\x12\x96P\xa1\xceTX\x16\x09\x85\x99\
\xa1\x08O\xceT\xf70\x99\xea_\xc5Q\x8a\xbc(\xcc\
Wq\x14X\x0a\xf2\x03\xe1\x18\xa9oD\x92'\x92\xa9\
9\x92\x89\x82\x91\xc2\x92)\xbe'$\xa1\x1d\x13\xce\xbf\
\x07\xc9Y{_@\x12\xbe\x00\x83I\xfe#\x01\x89\xbf\
\x09H\x81\xb0\xa0b\xba\x15}I\xc2\xc2\x22T$\xe9\
\x0cH\x0a\x13\x9b%)\xfb\x1e\x1c\x13\xa1o\xf3\xff\x19\
\x8e\x11\xf9\xebH&\x0c1\xa5X2on\xc0W\xa5\
\x92\x0a\xf1]%\x99K\xa5\xf1\xd7\xa0\xa4\x92?w\xc1\
\xff[P\xcao\x81\x92R\xa4\x98 D\xcd\x8bR!\
!pJ\xe9\x1cJ\x8c\x08\xe7xJ\x9dAy\xda;\
\x0b\xff\xdf\x22\xfc\xfd\x0c\xef@\xd8N\
\x00\x00\x08Y\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22e\
dit.svg\x22\x0d\x0a   ink\
scape:version=\x220\
.92.2 (5c3e80d, \
2017-08-06)\x22>\x0d\x0a \
 <metadata\x0d\x0a    \
 id=\x22metadata8\x22>\
\x0d\x0a    <rdf:RDF>\x0d\
\x0a      <cc:Work\x0d\
\x0a         rdf:ab\
out=\x22\x22>\x0d\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0d\x0a        <\
dc:type\x0d\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 />\x0d\x0a  \
      <dc:title \
/>\x0d\x0a      </cc:W\
ork>\x0d\x0a    </rdf:\
RDF>\x0d\x0a  </metada\
ta>\x0d\x0a  <defs\x0d\x0a  \
   id=\x22defs6\x22 />\
\x0d\x0a  <sodipodi:na\
medview\x0d\x0a     pa\
gecolor=\x22#ffffff\
\x22\x0d\x0a     borderco\
lor=\x22#666666\x22\x0d\x0a \
    borderopacit\
y=\x221\x22\x0d\x0a     obje\
cttolerance=\x2210\x22\
\x0d\x0a     gridtoler\
ance=\x2210\x22\x0d\x0a     \
guidetolerance=\x22\
10\x22\x0d\x0a     inksca\
pe:pageopacity=\x22\
0\x22\x0d\x0a     inkscap\
e:pageshadow=\x222\x22\
\x0d\x0a     inkscape:\
window-width=\x2218\
63\x22\x0d\x0a     inksca\
pe:window-height\
=\x221025\x22\x0d\x0a     id\
=\x22namedview4\x22\x0d\x0a \
    showgrid=\x22fa\
lse\x22\x0d\x0a     inksc\
ape:zoom=\x222.4583\
333\x22\x0d\x0a     inksc\
ape:cx=\x2225.8523\x22\
\x0d\x0a     inkscape:\
cy=\x22102.01301\x22\x0d\x0a\
     inkscape:wi\
ndow-x=\x2257\x22\x0d\x0a   \
  inkscape:windo\
w-y=\x2227\x22\x0d\x0a     i\
nkscape:window-m\
aximized=\x221\x22\x0d\x0a  \
   inkscape:curr\
ent-layer=\x22svg2\x22\
 />\x0d\x0a  <path\x0d\x0a  \
   style=\x22fill:#\
999999;stroke:#9\
99999;stroke-wid\
th:1.33333337\x22\x0d\x0a\
     d=\x22M 24.406\
78,148.92473 V 1\
33.91728 L 68.75\
4672,89.5842 113\
.10257,45.251123\
 l 14.97875,15.0\
21359 14.97874,1\
5.02136 -44.3339\
88,44.319178 -44\
.334,44.31918 H \
39.399422 24.406\
78 Z m 112.28181\
,-97.356802 -15.\
0515,-15.114105 \
8.60277,-8.26081\
1 c 5.40008,-5.1\
85426 9.73241,-8\
.260809 11.63711\
,-8.260809 4.221\
02,0 26.52981,22\
.334624 26.52981\
,26.560551 0,1.9\
57621 -3.01092,6\
.158632 -8.33333\
,11.627168 l -8.\
33334,8.562112 z\
\x22\x0d\x0a     id=\x22path\
817\x22\x0d\x0a     inksc\
ape:connector-cu\
rvature=\x220\x22 />\x0d\x0a\
</svg>\x0d\x0a\
\x00\x00\x07t\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<svg\x0d\x0a   \
xmlns:dc=\x22http:/\
/purl.org/dc/ele\
ments/1.1/\x22\x0d\x0a   \
xmlns:cc=\x22http:/\
/creativecommons\
.org/ns#\x22\x0d\x0a   xm\
lns:rdf=\x22http://\
www.w3.org/1999/\
02/22-rdf-syntax\
-ns#\x22\x0d\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0d\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0d\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0d\x0a   width=\x2248\x22\x0d\
\x0a   height=\x2248\x22\x0d\
\x0a   viewBox=\x220 0\
 48 48\x22\x0d\x0a   vers\
ion=\x221.1\x22\x0d\x0a   id\
=\x22svg6\x22\x0d\x0a   sodi\
podi:docname=\x22pr\
ev.svg\x22\x0d\x0a   inks\
cape:version=\x220.\
92.3 (2405546, 2\
018-03-11)\x22>\x0d\x0a  \
<metadata\x0d\x0a     \
id=\x22metadata12\x22>\
\x0d\x0a    <rdf:RDF>\x0d\
\x0a      <cc:Work\x0d\
\x0a         rdf:ab\
out=\x22\x22>\x0d\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0d\x0a        <\
dc:type\x0d\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 />\x0d\x0a  \
      <dc:title \
/>\x0d\x0a      </cc:W\
ork>\x0d\x0a    </rdf:\
RDF>\x0d\x0a  </metada\
ta>\x0d\x0a  <defs\x0d\x0a  \
   id=\x22defs10\x22 /\
>\x0d\x0a  <sodipodi:n\
amedview\x0d\x0a     p\
agecolor=\x22#fffff\
f\x22\x0d\x0a     borderc\
olor=\x22#666666\x22\x0d\x0a\
     borderopaci\
ty=\x221\x22\x0d\x0a     obj\
ecttolerance=\x2210\
\x22\x0d\x0a     gridtole\
rance=\x2210\x22\x0d\x0a    \
 guidetolerance=\
\x2210\x22\x0d\x0a     inksc\
ape:pageopacity=\
\x220\x22\x0d\x0a     inksca\
pe:pageshadow=\x222\
\x22\x0d\x0a     inkscape\
:window-width=\x221\
863\x22\x0d\x0a     inksc\
ape:window-heigh\
t=\x221025\x22\x0d\x0a     i\
d=\x22namedview8\x22\x0d\x0a\
     showgrid=\x22f\
alse\x22\x0d\x0a     inks\
cape:zoom=\x224.916\
6667\x22\x0d\x0a     inks\
cape:cx=\x22-26.001\
716\x22\x0d\x0a     inksc\
ape:cy=\x2224\x22\x0d\x0a   \
  inkscape:windo\
w-x=\x2257\x22\x0d\x0a     i\
nkscape:window-y\
=\x2227\x22\x0d\x0a     inks\
cape:window-maxi\
mized=\x221\x22\x0d\x0a     \
inkscape:current\
-layer=\x22svg6\x22 />\
\x0d\x0a  <path\x0d\x0a     \
d=\x22M0 0h48v48h-4\
8z\x22\x0d\x0a     id=\x22pa\
th2\x22\x0d\x0a     fill=\
\x22none\x22 />\x0d\x0a  <pa\
th\x0d\x0a     style=\x22\
fill:#00d455;fil\
l-rule:evenodd;s\
troke:#00d455;st\
roke-width:2;str\
oke-linecap:butt\
;stroke-linejoin\
:round;stroke-mi\
terlimit:4;strok\
e-dasharray:none\
;stroke-opacity:\
1\x22\x0d\x0a     d=\x22m 33\
.661067,35.18644\
5 0.20339,-22.37\
2882 -19.728814,\
11.59322 z\x22\x0d\x0a   \
  id=\x22path4489\x22\x0d\
\x0a     inkscape:c\
onnector-curvatu\
re=\x220\x22 />\x0d\x0a</svg\
>\x0d\x0a\
\x00\x00\x07\x1d\
\x00\
\x00'\x01x\xda\xddZ\xdfo\xe36\x12~_`\xff\
\x07\x9d\xf6e\x17\xb5(\x0e\x7fS\xb5\xb7@\xbb(\xd0\
\xd7^\x0f}<(\x92b\xebV\x96\x0cI\x8e\x93\xfe\
\xf5\x1dJ\x96-Gv\x90\x03\x8c\x83\xcf\xce\x06Yr\
\x86\x14\xf9q\xe6\x9b\x19\xca\xf3\x9f\x9e\xd7\x85\xf7\x94\xd5\
M^\x95\x0b\x1f\x08\xf5\xbd\xacL\xaa4/\x97\x0b\xff\
_\x7f\xfc\x1a\x18\xdfk\xda\xb8L\xe3\xa2*\xb3\x85_\
V\xfeO_?~\x98\xff#\x08\xbc_\xea,n\xb3\
\xd4\xdb\xe5\xed\xca\xfb\xad\xfc\xde$\xf1&\xf3>\xaf\xda\
v\x13\x85\xe1n\xb7#\xf9\xbe\x93T\xf52\xfc\xe2\x05\
\x01\x0e\xc5\xc1\xcd\xd3\xf2\xe3\x07\xcf\xf3\xf0\xd9e\x13\xa5\
\xc9\xc2\xdf\x8f\xd9l\xeb\xa2\xd3M\x930+\xb2uV\
\xb6M\x08\x04B\x7f\xa4\x9f\x1c\xf5\x13\xb7\x82\xfc)K\
\xaa\xf5\xba*\x9bnh\xd9|\x1ak\xd7\xe9\xe3A\xdd\
-i\xc7;-\xb0\xd6\x86\x94\x85\x8c\x05\xa8\x114/\
e\x1b?\x07\xaf\xc6\xe2:\xcf\x8de\x94\xd2\x10e#\
\xd5w\xaaE\x0d\x22\xbb\xc1\xdf\x83\xfe\xd0A\x9aj[\
'\xd9#\x0e\xccH\x99\xb5\xe1\xb7?\xbe\x1d\x84\x01%\
i\x9b\x8e\xe7\x19\x80=y\xee\x09\xdae\xbc\xce\x9aM\
\x9cdM8\xf4\xf7\x13\xec\xf2\xb4]-|a\xfa\xe6\
*\xcb\x97\xab\xf6\xd8~\xca\xb3\xdd\xcf\xd5\xf3\xc2\xa7\x1e\
\xf5\x84\xc1\x7f\x84\xba\x0f\xf4\xe2<]\xf8\xb8'\xb6W\
>\x1a\xce \xdf?+:\x88(\xb1\x8c0\xef\xb3L\
xfh:\xf3\x18\x05\x1dP\x13P\xf5\xa5\x1f3l\
3J\xab\xc4-{\xe1\xc7\xdb\xb6Z\xe3\xc9&\xff.\
\xe2\x97j\xdb\x12\x07\xe3W\xa7<O\xb3\xc7\xa6\x1b\xd5\
\xaf\xc55\x85\xef\x85\xbd\xf00\x93\x9b&u[\x19\xa9\
>\xc4\xcd\x1e\x02\xcf\xdb\xc4K4\x9a\xa2\xaa\x17\xfe\xa7\
\xc7\xee3H\x1e\xaa:\xcd\xeaA\xa6\xba\xcf\xa9\xacB\
T\xf3\xf6\xa5\xf7\x96a\xfea\xdbn\xe2\x83\x02\xbd\xa0\
\xd0\xac\xe2\xb4\xda-|6\x91\xfeUUk<\x0b\xa2\
\x8d\x12\xd2\xf0\x89<\xc1\x83\x09\xf0H,\x05e\xcdT\
\x8c\x0fe@4\xe3LL\x07#\xbc[\xe7R\xc1\xb6\
\xcc[4\xd9\xcd\xf3t\x82m];\x0d\x84=\xc3\xfd\
/\xb9\x100(5\xabj\xb7\xac\x1d\x92\x8fqq\x84\
\xf2\xf2d\xbb\xbc\xc4m\x06{\x83\x03\xa3\xf8%\x95\xc1\
\x08\x812yI\x07w.\xf5%\xa1\xdb\xf7E\xe1:\
~\xce\xd7\xf9_\x19\xae\x1c\x0e\xa6\xb2\xce\xda8\x8d\xdb\
xd C\x97\xeeM\x0d\x95\x90\x1a\xa2\xdf\xbf\xfd\xba\
obG\x92D\x7fV\xf5\xf7\xa1\x8d\x1f\xa7\x12?\xa0\
\x8d.|\xff\xeb\xb1\x7f\x9e&\x11:3\x1a\xf1\xd7|\
\x8dG\xee\x88\xe0\x07\xf4\xddyx\x14\x9cj\xb7/\x9b\
l4o?s\x9d\xf5\xbcp\x96!\xd3d\x9d\xbbQ\
\xe1?\xdb\xbc(~s\x8f\x19\xb67\x9a6o\x8bl\
\xd4;\x0f\xf7{\x18\xf6\x18\x8e79\x0f\x07\x10\xfa\xe6\
\xf25\xa4E\xfc\x90\x15\x0b\xff\x97x\x13{0\x01|\
YW\xdb\xcd\xbaJq\xbd\x9d\x05\xf9#t\xbb\x8e\xc3\
\x90\xb6\x8e\xcb\xc6\xe1\xb0\xf0\xbb\xff\x16\x18I>\xd3Y\
\x00\x94\x0a\xc2\x15c_\x0e\x87\xb0<l\xc8Msb\
\x92'\xf3 \xa4u\xfe\xfc\x99\x12\xa3\x14(.\xf9\x8c\
\xba\x9fc\x93\x11%\xb56\xda\xce\x80k\x02\xe8%\xf0\
\xe58S\xd3\xbe\x14\xb8\xeeG\x842\xdas\xc2\x8fM\
[W\xdf\xb3\xe8\x93H\xdd\x8f?\xb2\x83\xbcN\x8a\xf1\
q\xd5\x8e\x0e\xa4?\xeaq\xbe\x88\xbb1\x84\xc3\xd1n\
;\x01Z2\x13D\x0ai\x8d\x19\x0b\xdc\xf66q\xbb\
\xe2\x9c\xabq\xff\xb9\x95\xb9F\xb0'\x9a\x08\xfaf\xbd\
-\xb2({\xca\xca*M\x0fK\xb7\xddg\xdf\xec}\
1\x82\xcd\xf3\xd0Q\xe4e\x86G\x17=l\xdbv\xdc\
\xf7\x9f*/#4\xaf\xac\x1ez\x0f\x0f\x1b\xdb\xd8\xfb\
\x81\x00N\x80\xdb\x09\x10x\x10\xd4PA\xd9% \x02\
~wP0\x85\x16\x0e\xea5\x14\x82\x13+,\x9a\xe7\
E(\xee\xcf*\xb8u>\xc9'PP\x22\xa8\xe0\x82\
_\x84B\xdf\x1d\x14B\x13M\xcd\x94)\x0c\x22d\xb5\
\xbc\xec \xf2\xfe\xa0\x90H\xda\x0c^C\x01\x820\xa9\
(\xbc\xc1\x15\xf7\x87\x05\x97\x04$\xc8\xd7XHB\xad\
B{1\x97\xc9\x82\xdd\x1fqb\x04Wf\xca\x16\xc4\
\xa0Q\x08\x0d\x17\xb1\xb0\xf7\x17N\x11\x0a\xab&1\x04\
\x80\x08a\x81]6\x0b\xb8?(,\xc1\xc3\xb7\x13\xe2\
\xa4\x84))\xa9\xbc\x0c\xc5\x1dF\x11t\x11\xce\xec\x84\
.8\xa0\x8f\x18q\x1a^^\x81A\xef\x8f;\x99+\
\x85\xa7`\xa0\xef`\x11\xf1\x86\x8f\xdc!a`\xa2m\
\x04\x9b8\x09\xeaj`\x9a\xbd\x81\xc5\x1d&\xe0\x96P\
\x0c\xaag\xf2\x0b\x01R)\xfb\x06\x18\xff7)\xb8[\
\xf3x\x1b\x87\x1b\x9e\xaa\xc4\x89\xdb\xaa\x0e\x92m\xfd\x14\
\xb7\xdb\x1aw@\xcf\xedX\xb0S\x88\xdc\x0d\x89\xa7\x08\
\x95FK+g\x08#\x96tJ2O#\xd1R\x8a\
\x5c;\x93\x84kk\xde\x05\xd1\xfb1\xf9\xef\x11\xe9\x1a\
E\x8e\x7f\x221\xf4\xa5q\xb3\x8a\xeb:~\x89\xca\xaa\
\xcc\xfe\x07\xd8\xf1\x09v\x80I\x9b\xb1\x94\x09\x87\x9d&\
\x16\xa4\x97x\x94pJ5\x88Y\x805\x0fc\xca\x13\
\x0eM\x006\x0b4\x91 \xc4\xa4\xe3\xba\xf0\xba\xebY\
cp-\xe2\xc6lON\xf0c\xee.\xc7`\xde\x8b\
\xf8\x01\xe2\xc7\x11\x1cN(\xc3t\x87\xcf\x02\xac\x93\x04\
\xb5\xd7\x06\x07\xeb\x10\xcb5\xd37\x06\x8e\x9e\x1a\x97\x8b\
u\x14W;\xeb\x92C\x86L\xe6\x01\x1e\xae\xd0F\xa0\
qq\x82\x05\x15\x5c\xddt\x84\xb2\xa0\xb4\xba1t\xec\
\x19\xda\xe2h-R:t\xb0\xa2\x12\xd2z\xd0]\xb7\
p4\xfd\x19\x10k\xb5\xbd>8\xee\x8a\x0f\xf8m\x81\
\xa3\xe0\x9c_I\xad\xadv~\xc5\x0d\xd1JH/@\
\x90\x941\xdc\xce\x14a\x8c\x9a\xab\xfb\x15\x1a\xa8e\xb7\
f9jJ\xdaH\xd4\x0c\xa4\xb1l\xd6_\xd1`\xc4\
\xf3\x02p\xefX\xa4\xe60\x0b\x80(\xad\xafo:\x5c\
\x0a\x06\xe6\xc6\xd0\x99\xfa\x15f\x95ZX\x0d.\x1d\xc0\
\xf4\x89S\xad=L\x028\xa3\x02\xad\x09\x08\xc7\x5c\xe1\
\xea\xe0\x00`\x96qc\xa9\x92\x9e\xba\x95`D\x1a\xe4\
\x9cYw\xe3K5\x17^`\x89S\x95\xcc\x112\x97\
\xea\xea\x84\xac-\x15\xf8\xb8\x1b3\x1c=\x8d\xe5\xc2\x9d\
\xa3\xbb\xcc\xeb9GR-<\x8c`V\xf2\xce\xa9\x90\
 \xa8\xba>\xe9p\xaa4h{c\xe8\xe8s\x99\xa2\
\x00\xa5L\xc7\xc8\x94\x00r\x01\xba\x15\x00P\xa3\x91\x90\
\x85\xb9>6Zpj\x04\xbd1\xb7:-&zB\
\xc6\x92\x0ec8\xeb\xb2@\xf7\xfa\xc0h\xcf`\x12+\
\x95\x9e1\x02Z\xf2\xabC\x83\xd5\x8dd\x94\xdf\x1a\xe3\
\x04\xd3h\xc5\x191\x18\xad\x94\x8bV\x1c\x88\xd0XP\
`aa@a\xf4r\x05\x84E\xbc\xae\x8e\x0f\xa7X\
\x1d[v{\xf8\x9c\x96\xeb=B\x16\x8b(\xdd\xc7s\
$\x1eL\xff\x90\x96\x1d=+\x85\xa8a\xda\xc3@\xdc\
:B\xf3py\xf8\x86\x02\xc2q\xf6\x15vW\xe5\x9e\
\x5cF\xa0\x19\x08\x8b\x05\xa4\xe4o\xae\x96\x13#\xb5@\
\xca\x91\x93u\xd5\xd5\xb6L\xdf_d\xfb'/\xee\xdd\
J\x05\x8c\xdfl\x0f\xdfD\x12\x8e\xe0\xd0h\x8f\x92\xc3\
\x97\x92\xa6\x22wO\xe3JVM\xc7!\xb7\x7f\xd7\x8e\
\xa9\xaa\x1d\x97\x80u\xd7M\xc0(-\x8f\xdf\xfc\xe8\xc0\
\x9b\xbb/d\xe0\xdf\xbf\x01t\xb6\x1fy\
\x00\x00\x11\xf9\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   wid\
th=\x22512\x22\x0d\x0a   hei\
ght=\x22512\x22\x0d\x0a   vi\
ewBox=\x220 0 135.4\
6666 135.46667\x22\x0d\
\x0a   version=\x221.1\
\x22\x0d\x0a   id=\x22svg5\x22\x0d\
\x0a   xml:space=\x22p\
reserve\x22\x0d\x0a   ink\
scape:version=\x221\
.2.1 (9c6d41e410\
, 2022-07-14)\x22\x0d\x0a\
   sodipodi:docn\
ame=\x22roseta.svg\x22\
\x0d\x0a   xmlns:inksc\
ape=\x22http://www.\
inkscape.org/nam\
espaces/inkscape\
\x22\x0d\x0a   xmlns:sodi\
podi=\x22http://sod\
ipodi.sourceforg\
e.net/DTD/sodipo\
di-0.dtd\x22\x0d\x0a   xm\
lns=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22><sod\
ipodi:namedview\x0d\
\x0a     id=\x22namedv\
iew7\x22\x0d\x0a     page\
color=\x22#ffffff\x22\x0d\
\x0a     bordercolo\
r=\x22#000000\x22\x0d\x0a   \
  borderopacity=\
\x220.25\x22\x0d\x0a     ink\
scape:showpagesh\
adow=\x222\x22\x0d\x0a     i\
nkscape:pageopac\
ity=\x220.0\x22\x0d\x0a     \
inkscape:pageche\
ckerboard=\x220\x22\x0d\x0a \
    inkscape:des\
kcolor=\x22#d1d1d1\x22\
\x0d\x0a     inkscape:\
document-units=\x22\
mm\x22\x0d\x0a     showgr\
id=\x22false\x22\x0d\x0a    \
 inkscape:zoom=\x22\
0.37282197\x22\x0d\x0a   \
  inkscape:cx=\x22-\
193.12167\x22\x0d\x0a    \
 inkscape:cy=\x2227\
6.27127\x22\x0d\x0a     i\
nkscape:window-w\
idth=\x222560\x22\x0d\x0a   \
  inkscape:windo\
w-height=\x221017\x22\x0d\
\x0a     inkscape:w\
indow-x=\x22-8\x22\x0d\x0a  \
   inkscape:wind\
ow-y=\x22-8\x22\x0d\x0a     \
inkscape:window-\
maximized=\x221\x22\x0d\x0a \
    inkscape:cur\
rent-layer=\x22g599\
8\x22 /><defs\x0d\x0a    \
 id=\x22defs2\x22 /><g\
\x0d\x0a     inkscape:\
label=\x22Layer 1\x22\x0d\
\x0a     inkscape:g\
roupmode=\x22layer\x22\
\x0d\x0a     id=\x22layer\
1\x22><g\x0d\x0a       id\
=\x22g5998\x22\x0d\x0a      \
 transform=\x22tran\
slate(79.009279,\
-56.968548)\x22><pa\
th\x0d\x0a         sty\
le=\x22fill:#00222b\
;fill-opacity:1;\
stroke-width:0.2\
64583\x22\x0d\x0a        \
 d=\x22m -55.19995,\
94.34173 9.78544\
8,-7.527267 1.50\
5452,-4.014541 2\
.509089,-0.25091\
 8.530899,-6.523\
63 12.294534,-5.\
519994 13.799986\
5,-4.51636 10.03\
635,-2.00727 11.\
7927205,1.003636\
 2.76,0.752727 2\
.00727,3.010905 \
4.26545,20.57452\
6 8.02908,17.061\
808 3.76364,10.2\
8726 1.25454,41.\
14905 -8.27999,1\
0.53817 -14.0509\
,10.53818 -8.279\
9905,3.76363 -6.\
77453999,0.25091\
 -4.76727001,0.7\
5272 h -3.0109 l\
 -4.0145395,1.25\
455 -5.519999,-0\
.50182 -4.265451\
,1.50545 -8.7818\
09,-1.25454 -9.7\
85448,1.25454 -6\
.27272,0.50182 -\
7.276357,-2.5090\
9 -1.505452,-1.5\
0545 -1.756363,-\
3.76363 0.501817\
,-10.53818 -0.75\
2726,-9.28362 1.\
003636,-2.00727 \
1.254543,-17.814\
53 -1.254543,-5.\
26909 1.003636,-\
3.26181 -0.50182\
,-3.76364 z\x22\x0d\x0a  \
       id=\x22path4\
12\x22 /><path\x0d\x0a   \
      style=\x22fil\
l:none;fill-opac\
ity:1;stroke:#ff\
ffff;stroke-widt\
h:4;stroke-linec\
ap:round;stroke-\
dasharray:none;s\
troke-opacity:1\x22\
\x0d\x0a         d=\x22m \
-45.163594,103.1\
2354 7.778176,-3\
.01091 6.021811,\
1.50546 12.79635\
2,-1.756367 5.51\
9995,-1.756362 c\
 0,0 13.54907771\
,2.258179 15.054\
5308,2.509089 1.\
5054531,0.25091 \
13.7999872,-2.75\
9996 13.7999872,\
-2.759996 l 3.51\
2724,-0.501819\x22\x0d\
\x0a         id=\x22pa\
th4455\x22 /><path\x0d\
\x0a         style=\
\x22fill:none;fill-\
opacity:1;stroke\
:#ffffff;stroke-\
width:4;stroke-l\
inecap:round;str\
oke-dasharray:no\
ne;stroke-opacit\
y:1\x22\x0d\x0a         d\
=\x22m -44.536321,1\
18.80534 7.77817\
5,-3.01091 6.021\
811,1.50546 12.7\
96352,-1.75636 5\
.519995,-1.75636\
 c 0,0 13.549078\
3,2.25817 15.054\
5313,2.50908 1.5\
05453,0.25091 13\
.7999867,-2.7599\
9 13.7999867,-2.\
75999 l 3.512724\
,-0.50182\x22\x0d\x0a    \
     id=\x22path445\
5-8\x22 /><path\x0d\x0a  \
       style=\x22fi\
ll:none;fill-opa\
city:1;stroke:#f\
fffff;stroke-wid\
th:4;stroke-line\
cap:round;stroke\
-dasharray:none;\
stroke-opacity:1\
\x22\x0d\x0a         d=\x22m\
 -43.030869,134.\
11079 7.778176,-\
3.01091 6.021811\
,1.50546 12.7963\
52,-1.75637 5.51\
9995,-1.75636 c \
0,0 13.5490781,2\
.25818 15.054531\
1,2.50909 1.5054\
53,0.25091 13.79\
99869,-2.76 13.7\
999869,-2.76 l 3\
.512724,-0.50182\
\x22\x0d\x0a         id=\x22\
path4455-5\x22 /><p\
ath\x0d\x0a         st\
yle=\x22fill:none;f\
ill-opacity:1;st\
roke:#ffffff;str\
oke-width:4;stro\
ke-linecap:round\
;stroke-dasharra\
y:none;stroke-op\
acity:1\x22\x0d\x0a      \
   d=\x22m -43.7835\
95,149.16532 7.7\
78176,-3.01091 6\
.021811,1.50546 \
12.796352,-1.756\
37 5.519995,-1.7\
5636 c 0,0 13.54\
90773,2.25818 15\
.0545304,2.50909\
 1.5054532,0.250\
91 13.7999876,-2\
.76 13.7999876,-\
2.76 l 3.512724,\
-0.50182\x22\x0d\x0a     \
    id=\x22path4455\
-3\x22 /><path\x0d\x0a   \
      style=\x22fil\
l:none;fill-opac\
ity:1;stroke:#ff\
ffff;stroke-widt\
h:4;stroke-linec\
ap:round;stroke-\
dasharray:none;s\
troke-opacity:1\x22\
\x0d\x0a         d=\x22m \
-44.285414,164.2\
1985 7.778176,-3\
.01091 6.021811,\
1.50546 12.79635\
2,-1.75637 5.519\
995,-1.75636 c 0\
,0 13.5490784,2.\
25818 15.0545314\
,2.50909 1.50545\
3,0.25091 13.799\
9866,-2.76 13.79\
99866,-2.76 l 3.\
512724,-0.50181\x22\
\x0d\x0a         id=\x22p\
ath4455-38\x22 /><p\
ath\x0d\x0a         st\
yle=\x22fill:none;f\
ill-opacity:1;st\
roke:#ffffff;str\
oke-width:4;stro\
ke-linecap:round\
;stroke-dasharra\
y:none;stroke-op\
acity:1\x22\x0d\x0a      \
   d=\x22m -32.7436\
06,85.685379 c 3\
.592875,-0.71370\
6 -1.589798,-0.3\
32789 6.52363,-0\
.501814 l 3.7636\
33,-0.501826 5.5\
19995,-1.75636 c\
 0,0 13.5490781,\
2.25818 15.05453\
11,2.50909 1.505\
45298,0.25091 13\
.7999869,-2.76 1\
3.7999869,-2.76 \
l 3.512724,-0.50\
182\x22\x0d\x0a         i\
d=\x22path4455-4\x22\x0d\x0a\
         sodipod\
i:nodetypes=\x22ccc\
cscc\x22 /></g></g>\
</svg>\x0d\x0a\
\x00\x00\x09~\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<svg\x0d\x0a   \
xmlns:dc=\x22http:/\
/purl.org/dc/ele\
ments/1.1/\x22\x0d\x0a   \
xmlns:cc=\x22http:/\
/creativecommons\
.org/ns#\x22\x0d\x0a   xm\
lns:rdf=\x22http://\
www.w3.org/1999/\
02/22-rdf-syntax\
-ns#\x22\x0d\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0d\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0d\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0d\x0a   width=\x2248\x22\x0d\
\x0a   height=\x2248\x22\x0d\
\x0a   viewBox=\x220 0\
 48 48\x22\x0d\x0a   vers\
ion=\x221.1\x22\x0d\x0a   id\
=\x22svg4\x22\x0d\x0a   sodi\
podi:docname=\x22Ca\
talogue.svg\x22\x0d\x0a  \
 inkscape:versio\
n=\x220.92.3 (24055\
46, 2018-03-11)\x22\
>\x0d\x0a  <metadata\x0d\x0a\
     id=\x22metadat\
a10\x22>\x0d\x0a    <rdf:\
RDF>\x0d\x0a      <cc:\
Work\x0d\x0a         r\
df:about=\x22\x22>\x0d\x0a  \
      <dc:format\
>image/svg+xml</\
dc:format>\x0d\x0a    \
    <dc:type\x0d\x0a  \
         rdf:res\
ource=\x22http://pu\
rl.org/dc/dcmity\
pe/StillImage\x22 /\
>\x0d\x0a      </cc:Wo\
rk>\x0d\x0a    </rdf:R\
DF>\x0d\x0a  </metadat\
a>\x0d\x0a  <defs\x0d\x0a   \
  id=\x22defs8\x22 />\x0d\
\x0a  <sodipodi:nam\
edview\x0d\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0d\x0a     bordercol\
or=\x22#666666\x22\x0d\x0a  \
   borderopacity\
=\x221\x22\x0d\x0a     objec\
ttolerance=\x2210\x22\x0d\
\x0a     gridtolera\
nce=\x2210\x22\x0d\x0a     g\
uidetolerance=\x221\
0\x22\x0d\x0a     inkscap\
e:pageopacity=\x220\
\x22\x0d\x0a     inkscape\
:pageshadow=\x222\x22\x0d\
\x0a     inkscape:w\
indow-width=\x22185\
1\x22\x0d\x0a     inkscap\
e:window-height=\
\x221025\x22\x0d\x0a     id=\
\x22namedview6\x22\x0d\x0a  \
   showgrid=\x22fal\
se\x22\x0d\x0a     inksca\
pe:zoom=\x222.45833\
33\x22\x0d\x0a     inksca\
pe:cx=\x22-87.82962\
7\x22\x0d\x0a     inkscap\
e:cy=\x2265.809318\x22\
\x0d\x0a     inkscape:\
window-x=\x2269\x22\x0d\x0a \
    inkscape:win\
dow-y=\x2227\x22\x0d\x0a    \
 inkscape:window\
-maximized=\x221\x22\x0d\x0a\
     inkscape:cu\
rrent-layer=\x22svg\
4\x22 />\x0d\x0a  <path\x0d\x0a\
     style=\x22fill\
:none;fill-rule:\
evenodd;stroke:#\
999999;stroke-wi\
dth:2.35818648;s\
troke-linecap:ro\
und;stroke-linej\
oin:bevel;stroke\
-miterlimit:4;st\
roke-dasharray:n\
one;stroke-opaci\
ty:1\x22\x0d\x0a     d=\x22M\
 44.660175,10.45\
7984 C 38.726902\
,8.637125 32.892\
432,9.4085 24.48\
0787,12.898461 l\
 -0.23736,25.435\
98 c 9.22158,-3.\
350699 14.846721\
,-3.943904 20.55\
241,-2.372345 z\x22\
\x0d\x0a     id=\x22path8\
16-3-7\x22\x0d\x0a     in\
kscape:connector\
-curvature=\x220\x22\x0d\x0a\
     sodipodi:no\
detypes=\x22ccccc\x22 \
/>\x0d\x0a  <path\x0d\x0a   \
  style=\x22fill:no\
ne;fill-rule:eve\
nodd;stroke:#999\
999;stroke-width\
:2.35818648;stro\
ke-linecap:round\
;stroke-linejoin\
:bevel;stroke-mi\
terlimit:4;strok\
e-dasharray:none\
;stroke-opacity:\
1\x22\x0d\x0a     d=\x22M 3.\
8266767,10.45798\
4 C 9.7599467,8.\
637125 15.594417\
,9.4085 24.00606\
7,12.898461 l 0.\
23736,25.43598 C\
 15.021847,34.98\
3742 9.3967067,3\
4.390537 3.69100\
67,35.962096 Z\x22\x0d\
\x0a     id=\x22path81\
6-3-7-5\x22\x0d\x0a     i\
nkscape:connecto\
r-curvature=\x220\x22\x0d\
\x0a     sodipodi:n\
odetypes=\x22ccccc\x22\
 />\x0d\x0a</svg>\x0d\x0a\
\x00\x00\x0ep\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22d\
elete2.svg\x22\x0d\x0a   \
inkscape:version\
=\x220.92.4 (unknow\
n)\x22>\x0d\x0a  <metadat\
a\x0d\x0a     id=\x22meta\
data8\x22>\x0d\x0a    <rd\
f:RDF>\x0d\x0a      <c\
c:Work\x0d\x0a        \
 rdf:about=\x22\x22>\x0d\x0a\
        <dc:form\
at>image/svg+xml\
</dc:format>\x0d\x0a  \
      <dc:type\x0d\x0a\
           rdf:r\
esource=\x22http://\
purl.org/dc/dcmi\
type/StillImage\x22\
 />\x0d\x0a        <dc\
:title />\x0d\x0a     \
 </cc:Work>\x0d\x0a   \
 </rdf:RDF>\x0d\x0a  <\
/metadata>\x0d\x0a  <d\
efs\x0d\x0a     id=\x22de\
fs6\x22 />\x0d\x0a  <sodi\
podi:namedview\x0d\x0a\
     pagecolor=\x22\
#ffffff\x22\x0d\x0a     b\
ordercolor=\x22#666\
666\x22\x0d\x0a     borde\
ropacity=\x221\x22\x0d\x0a  \
   objecttoleran\
ce=\x2210\x22\x0d\x0a     gr\
idtolerance=\x2210\x22\
\x0d\x0a     guidetole\
rance=\x2210\x22\x0d\x0a    \
 inkscape:pageop\
acity=\x220\x22\x0d\x0a     \
inkscape:pagesha\
dow=\x222\x22\x0d\x0a     in\
kscape:window-wi\
dth=\x221863\x22\x0d\x0a    \
 inkscape:window\
-height=\x221025\x22\x0d\x0a\
     id=\x22namedvi\
ew4\x22\x0d\x0a     showg\
rid=\x22false\x22\x0d\x0a   \
  inkscape:zoom=\
\x220.61458333\x22\x0d\x0a  \
   inkscape:cx=\x22\
404.84924\x22\x0d\x0a    \
 inkscape:cy=\x22-1\
20.74709\x22\x0d\x0a     \
inkscape:window-\
x=\x2257\x22\x0d\x0a     ink\
scape:window-y=\x22\
27\x22\x0d\x0a     inksca\
pe:window-maximi\
zed=\x221\x22\x0d\x0a     in\
kscape:current-l\
ayer=\x22g831\x22 />\x0d\x0a\
  <g\x0d\x0a     id=\x22g\
831\x22\x0d\x0a     style\
=\x22stroke:#37c8ab\
;stroke-width:21\
;stroke-miterlim\
it:4;stroke-dash\
array:none\x22>\x0d\x0a  \
  <g\x0d\x0a       id=\
\x22g1454\x22\x0d\x0a       \
transform=\x22matri\
x(0.88034148,0,0\
,0.88034148,4.08\
50408,-3.8557222\
)\x22>\x0d\x0a      <path\
\x0d\x0a         sodip\
odi:nodetypes=\x22c\
c\x22\x0d\x0a         sty\
le=\x22fill:none;fi\
ll-rule:evenodd;\
stroke:#37c8ab;s\
troke-width:21;s\
troke-linecap:ro\
und;stroke-linej\
oin:miter;stroke\
-miterlimit:4;st\
roke-dasharray:n\
one;stroke-opaci\
ty:1\x22\x0d\x0a         \
d=\x22M 44.745763,4\
6.372881 145.914\
76,146.49003\x22\x0d\x0a \
        id=\x22path\
812\x22\x0d\x0a         i\
nkscape:connecto\
r-curvature=\x220\x22 \
/>\x0d\x0a      <path\x0d\
\x0a         sodipo\
di:nodetypes=\x22cc\
\x22\x0d\x0a         styl\
e=\x22fill:none;fil\
l-rule:evenodd;s\
troke:#37c8ab;st\
roke-width:21;st\
roke-linecap:rou\
nd;stroke-linejo\
in:miter;stroke-\
miterlimit:4;str\
oke-dasharray:no\
ne;stroke-opacit\
y:1\x22\x0d\x0a         d\
=\x22M 144.62039,46\
.804335 46.04012\
8,146.05858\x22\x0d\x0a  \
       id=\x22path8\
12-3\x22\x0d\x0a         \
inkscape:connect\
or-curvature=\x220\x22\
 />\x0d\x0a    </g>\x0d\x0a \
   <g\x0d\x0a       id\
=\x22g1450\x22\x0d\x0a      \
 transform=\x22matr\
ix(0.43891751,2.\
6767091,-2.67670\
91,0.43891751,14\
99.9421,-969.760\
44)\x22>\x0d\x0a      <ci\
rcle\x0d\x0a         r\
=\x2214.588048\x22\x0d\x0a  \
       cy=\x22556.8\
5822\x22\x0d\x0a         \
cx=\x22311.52576\x22\x0d\x0a\
         id=\x22pat\
h1093\x22\x0d\x0a        \
 style=\x22opacity:\
1;fill:#999999;f\
ill-opacity:1;st\
roke:none;stroke\
-width:17.224290\
85;stroke-lineca\
p:round;stroke-l\
inejoin:bevel;st\
roke-miterlimit:\
4;stroke-dasharr\
ay:none;stroke-d\
ashoffset:0;stro\
ke-opacity:1;pai\
nt-order:normal\x22\
 />\x0d\x0a      <path\
\x0d\x0a         sodip\
odi:nodetypes=\x22c\
c\x22\x0d\x0a         ink\
scape:connector-\
curvature=\x220\x22\x0d\x0a \
        id=\x22path\
1095\x22\x0d\x0a         \
d=\x22m 316.74974,5\
62.79153 16.9966\
3,17.62227\x22\x0d\x0a   \
      style=\x22fil\
l:#b3b3b3;fill-r\
ule:evenodd;stro\
ke:#999999;strok\
e-width:7;stroke\
-linecap:round;s\
troke-linejoin:m\
iter;stroke-mite\
rlimit:4;stroke-\
dasharray:none;s\
troke-opacity:1\x22\
 />\x0d\x0a      <circ\
le\x0d\x0a         r=\x22\
12.973715\x22\x0d\x0a    \
     cy=\x22556.826\
78\x22\x0d\x0a         cx\
=\x22311.44446\x22\x0d\x0a  \
       id=\x22path1\
093-3\x22\x0d\x0a        \
 style=\x22opacity:\
1;fill:#e6e6e6;f\
ill-opacity:1;st\
roke:none;stroke\
-width:15.318227\
77;stroke-lineca\
p:round;stroke-l\
inejoin:bevel;st\
roke-miterlimit:\
4;stroke-dasharr\
ay:none;stroke-d\
ashoffset:0;stro\
ke-opacity:1;pai\
nt-order:normal\x22\
 />\x0d\x0a    </g>\x0d\x0a \
 </g>\x0d\x0a</svg>\x0d\x0a\
\x00\x00\x18\x92\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   ver\
sion=\x221.1\x22\x0d\x0a   i\
d=\x22svg2\x22\x0d\x0a   wid\
th=\x22192\x22\x0d\x0a   hei\
ght=\x22192\x22\x0d\x0a   vi\
ewBox=\x220 0 192 1\
92\x22\x0d\x0a   sodipodi\
:docname=\x22import\
_models.svg\x22\x0d\x0a  \
 inkscape:versio\
n=\x221.2.1 (9c6d41\
e410, 2022-07-14\
)\x22\x0d\x0a   xml:space\
=\x22preserve\x22\x0d\x0a   \
xmlns:inkscape=\x22\
http://www.inksc\
ape.org/namespac\
es/inkscape\x22\x0d\x0a  \
 xmlns:sodipodi=\
\x22http://sodipodi\
.sourceforge.net\
/DTD/sodipodi-0.\
dtd\x22\x0d\x0a   xmlns=\x22\
http://www.w3.or\
g/2000/svg\x22\x0d\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:cc=\
\x22http://creative\
commons.org/ns#\x22\
\x0d\x0a   xmlns:dc=\x22h\
ttp://purl.org/d\
c/elements/1.1/\x22\
><metadata\x0d\x0a    \
 id=\x22metadata8\x22>\
<rdf:RDF><cc:Wor\
k\x0d\x0a         rdf:\
about=\x22\x22><dc:for\
mat>image/svg+xm\
l</dc:format><dc\
:type\x0d\x0a         \
  rdf:resource=\x22\
http://purl.org/\
dc/dcmitype/Stil\
lImage\x22 /><dc:ti\
tle /></cc:Work>\
</rdf:RDF></meta\
data><defs\x0d\x0a    \
 id=\x22defs6\x22 /><s\
odipodi:namedvie\
w\x0d\x0a     pagecolo\
r=\x22#ffffff\x22\x0d\x0a   \
  bordercolor=\x22#\
666666\x22\x0d\x0a     bo\
rderopacity=\x221\x22\x0d\
\x0a     objecttole\
rance=\x2210\x22\x0d\x0a    \
 gridtolerance=\x22\
10\x22\x0d\x0a     guidet\
olerance=\x2210\x22\x0d\x0a \
    inkscape:pag\
eopacity=\x220\x22\x0d\x0a  \
   inkscape:page\
shadow=\x222\x22\x0d\x0a    \
 inkscape:window\
-width=\x222560\x22\x0d\x0a \
    inkscape:win\
dow-height=\x221017\
\x22\x0d\x0a     id=\x22name\
dview4\x22\x0d\x0a     sh\
owgrid=\x22false\x22\x0d\x0a\
     inkscape:zo\
om=\x220.65429688\x22\x0d\
\x0a     inkscape:c\
x=\x22-588.41791\x22\x0d\x0a\
     inkscape:cy\
=\x22-207.85672\x22\x0d\x0a \
    inkscape:win\
dow-x=\x22-8\x22\x0d\x0a    \
 inkscape:window\
-y=\x22-8\x22\x0d\x0a     in\
kscape:window-ma\
ximized=\x221\x22\x0d\x0a   \
  inkscape:curre\
nt-layer=\x22svg2\x22\x0d\
\x0a     inkscape:s\
howpageshadow=\x222\
\x22\x0d\x0a     inkscape\
:pagecheckerboar\
d=\x220\x22\x0d\x0a     inks\
cape:deskcolor=\x22\
#d1d1d1\x22 /><g\x0d\x0a \
    id=\x22g2678\x22\x0d\x0a\
     transform=\x22\
matrix(0.5532004\
2,0,0,0.59846942\
,8.6310018,192.6\
7497)\x22><path\x0d\x0a  \
     style=\x22opac\
ity:1;fill:#1fa7\
66;fill-opacity:\
1;stroke-width:2\
.11176;paint-ord\
er:stroke fill m\
arkers\x22\x0d\x0a       \
d=\x22m 23.837619,-\
39.213637 c -2.3\
22935,-0.980768 \
-6.204202,-1.179\
152 -9.107857,-4\
.3034 -1.759793,\
-1.893485 -5.674\
4111,-8.840713 -\
5.6744111,-8.840\
713 V -164.06992\
 -275.7821 c 0,0\
 0.134385,-6.590\
47 4.9745161,-10\
.70601 3.683865,\
-3.13236 8.82608\
7,-3.10161 8.826\
087,-3.10161 l 5\
5.396413,-0.5988\
1 55.396423,-0.5\
988 38.61332,38.\
70512 38.61333,3\
8.70513 -0.60177\
,80.64128 -0.601\
77,80.641299 c 0\
,0 -2.20181,6.50\
8531 -4.53166,8.\
87686 -2.45442,2\
.494982 -9.27206\
,4.926555 -9.272\
06,4.926555 l -8\
3.90353,0.430319\
 c -46.146941,0.\
236687 -85.80409\
8,-0.372116 -88.\
127031,-1.35287 \
z M 191.72201,-2\
02.5039 c 0,-0.3\
0357 -15.67978,-\
16.2101 -34.8439\
3,-35.34787 l -3\
4.84394,-34.7959\
2 v 35.34787 35.\
34787 h 34.84394\
 c 19.16415,0 34\
.84393,-0.24839 \
34.84393,-0.5519\
5 z\x22\x0d\x0a       id=\
\x22path817\x22\x0d\x0a     \
  inkscape:conne\
ctor-curvature=\x22\
0\x22\x0d\x0a       sodip\
odi:nodetypes=\x22c\
scccscccccccscsc\
sscccss\x22 /><g\x0d\x0a \
      id=\x22g2568\x22\
\x0d\x0a       transfo\
rm=\x22matrix(0.912\
8977,0,0,0.64716\
112,24.343284,-3\
7.486011)\x22><g\x0d\x0a \
        id=\x22g114\
0\x22\x0d\x0a         sty\
le=\x22fill:#ffffff\
;stroke:none\x22\x0d\x0a \
        transfor\
m=\x22translate(407\
.30746,32.477612\
)\x22><rect\x0d\x0a      \
     style=\x22opac\
ity:1;fill:#ffff\
ff;stroke:none;s\
troke-width:1.17\
752\x22\x0d\x0a          \
 id=\x22rect1011\x22\x0d\x0a\
           width\
=\x22123.59569\x22\x0d\x0a  \
         height=\
\x22139.93283\x22\x0d\x0a   \
        x=\x22-375.\
9761\x22\x0d\x0a         \
  y=\x22-226.0116\x22\x0d\
\x0a           ry=\x22\
11.583521\x22 /><re\
ct\x0d\x0a           s\
tyle=\x22opacity:1;\
fill:#ffffff;str\
oke:none\x22\x0d\x0a     \
      id=\x22rect10\
13\x22\x0d\x0a           \
width=\x2248.907463\
\x22\x0d\x0a           he\
ight=\x2238.208954\x22\
\x0d\x0a           x=\x22\
-366.80597\x22\x0d\x0a   \
        y=\x22-220.\
08357\x22 /><rect\x0d\x0a\
           style\
=\x22fill:#ffffff;s\
troke:none\x22\x0d\x0a   \
        id=\x22rect\
1013-4\x22\x0d\x0a       \
    width=\x2248.90\
7463\x22\x0d\x0a         \
  height=\x2238.208\
954\x22\x0d\x0a          \
 x=\x22-310.72836\x22\x0d\
\x0a           y=\x22-\
219.76704\x22 /><re\
ct\x0d\x0a           s\
tyle=\x22fill:#ffff\
ff;stroke:none\x22\x0d\
\x0a           id=\x22\
rect1013-6\x22\x0d\x0a   \
        width=\x224\
8.907463\x22\x0d\x0a     \
      height=\x2238\
.208954\x22\x0d\x0a      \
     x=\x22-366.358\
8\x22\x0d\x0a           y\
=\x22-174.88535\x22 />\
<rect\x0d\x0a         \
  style=\x22fill:#f\
fffff;stroke:non\
e\x22\x0d\x0a           i\
d=\x22rect1013-4-6\x22\
\x0d\x0a           wid\
th=\x2248.907463\x22\x0d\x0a\
           heigh\
t=\x2238.208954\x22\x0d\x0a \
          x=\x22-31\
0.28119\x22\x0d\x0a      \
     y=\x22-174.568\
82\x22 /><rect\x0d\x0a   \
        style=\x22f\
ill:#ffffff;stro\
ke:none\x22\x0d\x0a      \
     id=\x22rect101\
3-1\x22\x0d\x0a          \
 width=\x2248.90746\
3\x22\x0d\x0a           h\
eight=\x2238.208954\
\x22\x0d\x0a           x=\
\x22-365.81845\x22\x0d\x0a  \
         y=\x22-130\
.41977\x22 /><rect\x0d\
\x0a           styl\
e=\x22fill:#ffffff;\
stroke:none\x22\x0d\x0a  \
         id=\x22rec\
t1013-4-5\x22\x0d\x0a    \
       width=\x2248\
.907463\x22\x0d\x0a      \
     height=\x2238.\
208954\x22\x0d\x0a       \
    x=\x22-309.7408\
4\x22\x0d\x0a           y\
=\x22-130.41977\x22 />\
</g><path\x0d\x0a     \
    style=\x22opaci\
ty:1;fill:#20a86\
7;fill-opacity:1\
;stroke:none;str\
oke-width:0.2701\
78\x22\x0d\x0a         d=\
\x22m 40.675762,-16\
8.53491 v -19.04\
755 h 24.31603 2\
4.31603 v 19.047\
55 19.04756 h -2\
4.31603 -24.3160\
3 z\x22\x0d\x0a         i\
d=\x22path1775\x22 /><\
path\x0d\x0a         s\
tyle=\x22opacity:1;\
fill:#20a867;fil\
l-opacity:1;stro\
ke:none;stroke-w\
idth:0.270178\x22\x0d\x0a\
         d=\x22m 96\
.602632,-168.129\
64 v -18.91247 h\
 24.316028 24.31\
603 v 18.91247 1\
8.91247 H 120.91\
866 96.602632 Z\x22\
\x0d\x0a         id=\x22p\
ath1777\x22 /><path\
\x0d\x0a         style\
=\x22opacity:1;fill\
:#20a867;fill-op\
acity:1;stroke:n\
one;stroke-width\
:0.270178\x22\x0d\x0a    \
     d=\x22m 97.142\
992,-123.00989 v\
 -18.91247 h 24.\
316028 24.31603 \
v 18.91247 18.91\
246 H 121.45902 \
97.142992 Z\x22\x0d\x0a  \
       id=\x22path1\
779\x22 /><path\x0d\x0a  \
       style=\x22op\
acity:1;fill:#20\
a867;fill-opacit\
y:1;stroke:none;\
stroke-width:0.2\
70178\x22\x0d\x0a        \
 d=\x22m 41.216122,\
-123.28007 v -18\
.91247 h 24.3160\
3 24.31603 v 18.\
91247 18.91247 h\
 -24.31603 -24.3\
1603 z\x22\x0d\x0a       \
  id=\x22path1781\x22 \
/><path\x0d\x0a       \
  style=\x22opacity\
:1;fill:#20a867;\
fill-opacity:1;s\
troke:none;strok\
e-width:0.270178\
\x22\x0d\x0a         d=\x22m\
 41.756472,-78.8\
35768 v -19.0475\
6 h 24.31603 24.\
31603 v 19.04756\
 19.047554 h -24\
.31603 -24.31603\
 z\x22\x0d\x0a         id\
=\x22path1783\x22 /><p\
ath\x0d\x0a         st\
yle=\x22opacity:1;f\
ill:#20a867;fill\
-opacity:1;strok\
e:none;stroke-wi\
dth:0.270178\x22\x0d\x0a \
        d=\x22m 97.\
683342,-78.83576\
8 v -19.04756 h \
24.316028 24.316\
03 v 19.04756 19\
.047554 H 121.99\
937 97.683342 Z\x22\
\x0d\x0a         id=\x22p\
ath1785\x22 /></g><\
/g><path\x0d\x0a     i\
nkscape:connecto\
r-curvature=\x220\x22\x0d\
\x0a     id=\x22path81\
7-5\x22\x0d\x0a     d=\x22m \
127.7435,178.614\
24 v -3.96301 h \
28.90983 28.9098\
4 v 3.96301 3.96\
302 H 156.65333 \
127.7435 Z m 14.\
45492,-26.08983 \
-14.09816,-13.54\
029 h 8.08158 8.\
08156 v -11.8890\
4 -11.88904 h 12\
.38993 12.38994 \
v 11.88904 11.88\
904 h 8.08157 8.\
08156 l -14.0981\
4,13.54029 c -7.\
754,7.44717 -14.\
25871,13.54031 -\
14.45493,13.5403\
1 -0.19621,0 -6.\
70092,-6.09314 -\
14.45491,-13.540\
31 z\x22\x0d\x0a     styl\
e=\x22fill:#5500d4;\
stroke-width:0.6\
74273\x22 /></svg>\x0d\
\x0a\
\x00\x00\x0be\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22c\
opy2right.svg\x22\x0d\x0a\
   inkscape:vers\
ion=\x220.92.3 (240\
5546, 2018-03-11\
)\x22>\x0d\x0a  <metadata\
\x0d\x0a     id=\x22metad\
ata8\x22>\x0d\x0a    <rdf\
:RDF>\x0d\x0a      <cc\
:Work\x0d\x0a         \
rdf:about=\x22\x22>\x0d\x0a \
       <dc:forma\
t>image/svg+xml<\
/dc:format>\x0d\x0a   \
     <dc:type\x0d\x0a \
          rdf:re\
source=\x22http://p\
url.org/dc/dcmit\
ype/StillImage\x22 \
/>\x0d\x0a        <dc:\
title></dc:title\
>\x0d\x0a      </cc:Wo\
rk>\x0d\x0a    </rdf:R\
DF>\x0d\x0a  </metadat\
a>\x0d\x0a  <defs\x0d\x0a   \
  id=\x22defs6\x22 />\x0d\
\x0a  <sodipodi:nam\
edview\x0d\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0d\x0a     bordercol\
or=\x22#666666\x22\x0d\x0a  \
   borderopacity\
=\x221\x22\x0d\x0a     objec\
ttolerance=\x2210\x22\x0d\
\x0a     gridtolera\
nce=\x2210\x22\x0d\x0a     g\
uidetolerance=\x221\
0\x22\x0d\x0a     inkscap\
e:pageopacity=\x220\
\x22\x0d\x0a     inkscape\
:pageshadow=\x222\x22\x0d\
\x0a     inkscape:w\
indow-width=\x22185\
1\x22\x0d\x0a     inkscap\
e:window-height=\
\x221025\x22\x0d\x0a     id=\
\x22namedview4\x22\x0d\x0a  \
   showgrid=\x22fal\
se\x22\x0d\x0a     inksca\
pe:zoom=\x221.22916\
67\x22\x0d\x0a     inksca\
pe:cx=\x22-123.4529\
7\x22\x0d\x0a     inkscap\
e:cy=\x2296.000006\x22\
\x0d\x0a     inkscape:\
window-x=\x2269\x22\x0d\x0a \
    inkscape:win\
dow-y=\x2227\x22\x0d\x0a    \
 inkscape:window\
-maximized=\x221\x22\x0d\x0a\
     inkscape:cu\
rrent-layer=\x22g82\
0\x22 />\x0d\x0a  <path\x0d\x0a\
     style=\x22fill\
:#999999;stroke-\
width:1.33333337\
\x22\x0d\x0a     d=\x22m 53.\
118644,179.49816\
 c -1.46666,-0.6\
2009 -4.16666,-2\
.7414 -6,-4.7140\
1 l -3.33333,-3.\
58656 V 108.6639\
8 46.130379 l 4.\
35897,-4.358975 \
4.35898,-4.35897\
4 h 50.615376 50\
.61539 l 4.35897\
,4.358974 4.3589\
7,4.358975 v 62.\
615381 62.61539 \
l -4.35758,4.358\
97 -4.3576,4.358\
97 -48.97574,0.2\
7327 c -26.93665\
6,0.15029 -50.17\
5736,-0.23409 -5\
1.642406,-0.8542\
 z m 93.999996,-\
70.7524 V 52.745\
763 h -44 -43.99\
9996 v 55.999997\
 56 h 43.999996 \
44 z M 11.412064\
,73.437035 l 0.3\
7325,-59.308728 \
4.35767,-4.35793\
95 4.35768,-4.35\
79381 51.30899,-\
0.3786652 51.308\
986,-0.3786654 v\
 8.0453322 8.045\
332 h -47.999996\
 -48 v 56 55.999\
997 h -8.03992 -\
8.03991 z\x22\x0d\x0a    \
 id=\x22path817\x22\x0d\x0a \
    inkscape:con\
nector-curvature\
=\x220\x22 />\x0d\x0a  <g\x0d\x0a \
    id=\x22g820\x22\x0d\x0a \
    transform=\x22m\
atrix(-4,0,0,-4,\
-202.16948,208.6\
7797)\x22>\x0d\x0a    <pa\
th\x0d\x0a       id=\x22p\
ath2\x22\x0d\x0a       d=\
\x22M 0,0 H 48 V 48\
 H 0 Z\x22\x0d\x0a       \
inkscape:connect\
or-curvature=\x220\x22\
\x0d\x0a       style=\x22\
fill:none\x22 />\x0d\x0a \
   <path\x0d\x0a      \
 inkscape:connec\
tor-curvature=\x220\
\x22\x0d\x0a       id=\x22pa\
th4489\x22\x0d\x0a       \
d=\x22m -70.565674,\
30.518916 0.1185\
25,-13.037829 -1\
1.496992,6.75596\
6 z\x22\x0d\x0a       sty\
le=\x22fill:#37c8ab\
;fill-rule:eveno\
dd;stroke:#37c8a\
b;stroke-width:1\
.16550279;stroke\
-linecap:butt;st\
roke-linejoin:ro\
und;stroke-miter\
limit:4;stroke-d\
asharray:none;st\
roke-opacity:1\x22 \
/>\x0d\x0a  </g>\x0d\x0a</sv\
g>\x0d\x0a\
\x00\x00\x0a\x12\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<svg\x0d\x0a   \
xmlns:dc=\x22http:/\
/purl.org/dc/ele\
ments/1.1/\x22\x0d\x0a   \
xmlns:cc=\x22http:/\
/creativecommons\
.org/ns#\x22\x0d\x0a   xm\
lns:rdf=\x22http://\
www.w3.org/1999/\
02/22-rdf-syntax\
-ns#\x22\x0d\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0d\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0d\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0d\x0a   width=\x2248\x22\x0d\
\x0a   height=\x2248\x22\x0d\
\x0a   viewBox=\x220 0\
 48 48\x22\x0d\x0a   vers\
ion=\x221.1\x22\x0d\x0a   id\
=\x22svg6\x22\x0d\x0a   sodi\
podi:docname=\x22ma\
gnifying_glass.s\
vg\x22\x0d\x0a   inkscape\
:version=\x220.92.4\
 (unknown)\x22>\x0d\x0a  \
<metadata\x0d\x0a     \
id=\x22metadata12\x22>\
\x0d\x0a    <rdf:RDF>\x0d\
\x0a      <cc:Work\x0d\
\x0a         rdf:ab\
out=\x22\x22>\x0d\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0d\x0a        <\
dc:type\x0d\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 />\x0d\x0a  \
      <dc:title \
/>\x0d\x0a      </cc:W\
ork>\x0d\x0a    </rdf:\
RDF>\x0d\x0a  </metada\
ta>\x0d\x0a  <defs\x0d\x0a  \
   id=\x22defs10\x22 /\
>\x0d\x0a  <sodipodi:n\
amedview\x0d\x0a     p\
agecolor=\x22#fffff\
f\x22\x0d\x0a     borderc\
olor=\x22#666666\x22\x0d\x0a\
     borderopaci\
ty=\x221\x22\x0d\x0a     obj\
ecttolerance=\x2210\
\x22\x0d\x0a     gridtole\
rance=\x2210\x22\x0d\x0a    \
 guidetolerance=\
\x2210\x22\x0d\x0a     inksc\
ape:pageopacity=\
\x220\x22\x0d\x0a     inksca\
pe:pageshadow=\x222\
\x22\x0d\x0a     inkscape\
:window-width=\x221\
863\x22\x0d\x0a     inksc\
ape:window-heigh\
t=\x221025\x22\x0d\x0a     i\
d=\x22namedview8\x22\x0d\x0a\
     showgrid=\x22f\
alse\x22\x0d\x0a     inks\
cape:zoom=\x222.397\
5339\x22\x0d\x0a     inks\
cape:cx=\x22-165.85\
427\x22\x0d\x0a     inksc\
ape:cy=\x22105.8861\
9\x22\x0d\x0a     inkscap\
e:window-x=\x2257\x22\x0d\
\x0a     inkscape:w\
indow-y=\x2227\x22\x0d\x0a  \
   inkscape:wind\
ow-maximized=\x221\x22\
\x0d\x0a     inkscape:\
current-layer=\x22s\
vg6\x22 />\x0d\x0a  <path\
\x0d\x0a     d=\x22M0 0h4\
8v48h-48z\x22\x0d\x0a    \
 id=\x22path2\x22\x0d\x0a   \
  fill=\x22none\x22 />\
\x0d\x0a  <circle\x0d\x0a   \
  style=\x22opacity\
:1;fill:#999999;\
fill-opacity:1;s\
troke:none;strok\
e-width:17.22429\
085;stroke-linec\
ap:round;stroke-\
linejoin:bevel;s\
troke-miterlimit\
:4;stroke-dashar\
ray:none;stroke-\
dashoffset:0;str\
oke-opacity:1;pa\
int-order:normal\
\x22\x0d\x0a     id=\x22path\
1093\x22\x0d\x0a     cx=\x22\
18.237631\x22\x0d\x0a    \
 cy=\x2217.875154\x22\x0d\
\x0a     r=\x2214.5880\
48\x22 />\x0d\x0a  <path\x0d\
\x0a     style=\x22fil\
l:#b3b3b3;fill-r\
ule:evenodd;stro\
ke:#999999;strok\
e-width:7;stroke\
-linecap:round;s\
troke-linejoin:m\
iter;stroke-mite\
rlimit:4;stroke-\
dasharray:none;s\
troke-opacity:1\x22\
\x0d\x0a     d=\x22M 23.4\
61607,23.808476 \
40.458238,41.430\
75\x22\x0d\x0a     id=\x22pa\
th1095\x22\x0d\x0a     in\
kscape:connector\
-curvature=\x220\x22\x0d\x0a\
     sodipodi:no\
detypes=\x22cc\x22 />\x0d\
\x0a  <circle\x0d\x0a    \
 style=\x22opacity:\
1;fill:#e6e6e6;f\
ill-opacity:1;st\
roke:none;stroke\
-width:15.318227\
77;stroke-lineca\
p:round;stroke-l\
inejoin:bevel;st\
roke-miterlimit:\
4;stroke-dasharr\
ay:none;stroke-d\
ashoffset:0;stro\
ke-opacity:1;pai\
nt-order:normal\x22\
\x0d\x0a     id=\x22path1\
093-3\x22\x0d\x0a     cx=\
\x2218.156338\x22\x0d\x0a   \
  cy=\x2217.843712\x22\
\x0d\x0a     r=\x2212.973\
715\x22 />\x0d\x0a</svg>\x0d\
\x0a\
\x00\x00\x0a\x1a\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<svg\x0d\x0a   \
xmlns:dc=\x22http:/\
/purl.org/dc/ele\
ments/1.1/\x22\x0d\x0a   \
xmlns:cc=\x22http:/\
/creativecommons\
.org/ns#\x22\x0d\x0a   xm\
lns:rdf=\x22http://\
www.w3.org/1999/\
02/22-rdf-syntax\
-ns#\x22\x0d\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0d\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0d\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0d\x0a   width=\x2248\x22\x0d\
\x0a   height=\x2248\x22\x0d\
\x0a   viewBox=\x220 0\
 48 48\x22\x0d\x0a   vers\
ion=\x221.1\x22\x0d\x0a   id\
=\x22svg6\x22\x0d\x0a   sodi\
podi:docname=\x22ma\
gnifying_glass2.\
svg\x22\x0d\x0a   inkscap\
e:version=\x220.92.\
4 (unknown)\x22>\x0d\x0a \
 <metadata\x0d\x0a    \
 id=\x22metadata12\x22\
>\x0d\x0a    <rdf:RDF>\
\x0d\x0a      <cc:Work\
\x0d\x0a         rdf:a\
bout=\x22\x22>\x0d\x0a      \
  <dc:format>ima\
ge/svg+xml</dc:f\
ormat>\x0d\x0a        \
<dc:type\x0d\x0a      \
     rdf:resourc\
e=\x22http://purl.o\
rg/dc/dcmitype/S\
tillImage\x22 />\x0d\x0a \
       <dc:title\
></dc:title>\x0d\x0a  \
    </cc:Work>\x0d\x0a\
    </rdf:RDF>\x0d\x0a\
  </metadata>\x0d\x0a \
 <defs\x0d\x0a     id=\
\x22defs10\x22 />\x0d\x0a  <\
sodipodi:namedvi\
ew\x0d\x0a     pagecol\
or=\x22#ffffff\x22\x0d\x0a  \
   bordercolor=\x22\
#666666\x22\x0d\x0a     b\
orderopacity=\x221\x22\
\x0d\x0a     objecttol\
erance=\x2210\x22\x0d\x0a   \
  gridtolerance=\
\x2210\x22\x0d\x0a     guide\
tolerance=\x2210\x22\x0d\x0a\
     inkscape:pa\
geopacity=\x220\x22\x0d\x0a \
    inkscape:pag\
eshadow=\x222\x22\x0d\x0a   \
  inkscape:windo\
w-width=\x221863\x22\x0d\x0a\
     inkscape:wi\
ndow-height=\x22102\
5\x22\x0d\x0a     id=\x22nam\
edview8\x22\x0d\x0a     s\
howgrid=\x22false\x22\x0d\
\x0a     inkscape:z\
oom=\x2213.260417\x22\x0d\
\x0a     inkscape:c\
x=\x2215.581624\x22\x0d\x0a \
    inkscape:cy=\
\x2222.07805\x22\x0d\x0a    \
 inkscape:window\
-x=\x2257\x22\x0d\x0a     in\
kscape:window-y=\
\x2227\x22\x0d\x0a     inksc\
ape:window-maxim\
ized=\x221\x22\x0d\x0a     i\
nkscape:current-\
layer=\x22svg6\x22 />\x0d\
\x0a  <path\x0d\x0a     d\
=\x22M0 0h48v48h-48\
z\x22\x0d\x0a     id=\x22pat\
h2\x22\x0d\x0a     fill=\x22\
none\x22 />\x0d\x0a  <cir\
cle\x0d\x0a     style=\
\x22opacity:1;fill:\
#00d4aa;fill-opa\
city:1;stroke:no\
ne;stroke-width:\
17.22429085;stro\
ke-linecap:round\
;stroke-linejoin\
:bevel;stroke-mi\
terlimit:4;strok\
e-dasharray:none\
;stroke-dashoffs\
et:0;stroke-opac\
ity:1;paint-orde\
r:normal\x22\x0d\x0a     \
id=\x22path1093\x22\x0d\x0a \
    cx=\x2218.23763\
1\x22\x0d\x0a     cy=\x2217.\
875154\x22\x0d\x0a     r=\
\x2214.588048\x22 />\x0d\x0a\
  <path\x0d\x0a     st\
yle=\x22fill:#00d4a\
a;fill-rule:even\
odd;stroke:#00d4\
aa;stroke-width:\
7;stroke-linecap\
:round;stroke-li\
nejoin:miter;str\
oke-miterlimit:4\
;stroke-dasharra\
y:none;stroke-op\
acity:1\x22\x0d\x0a     d\
=\x22M 23.461607,23\
.808476 40.45823\
8,41.43075\x22\x0d\x0a   \
  id=\x22path1095\x22\x0d\
\x0a     inkscape:c\
onnector-curvatu\
re=\x220\x22\x0d\x0a     sod\
ipodi:nodetypes=\
\x22cc\x22 />\x0d\x0a  <circ\
le\x0d\x0a     style=\x22\
opacity:1;fill:#\
e6e6e6;fill-opac\
ity:1;stroke:non\
e;stroke-width:1\
5.31822777;strok\
e-linecap:round;\
stroke-linejoin:\
bevel;stroke-mit\
erlimit:4;stroke\
-dasharray:none;\
stroke-dashoffse\
t:0;stroke-opaci\
ty:1;paint-order\
:normal\x22\x0d\x0a     i\
d=\x22path1093-3\x22\x0d\x0a\
     cx=\x2218.1563\
38\x22\x0d\x0a     cy=\x2217\
.843712\x22\x0d\x0a     r\
=\x2212.973715\x22 />\x0d\
\x0a</svg>\x0d\x0a\
\x00\x00\x0a\x8e\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22e\
xport_pickle.svg\
\x22\x0d\x0a   inkscape:v\
ersion=\x220.92.3 (\
2405546, 2018-03\
-11)\x22>\x0d\x0a  <metad\
ata\x0d\x0a     id=\x22me\
tadata8\x22>\x0d\x0a    <\
rdf:RDF>\x0d\x0a      \
<cc:Work\x0d\x0a      \
   rdf:about=\x22\x22>\
\x0d\x0a        <dc:fo\
rmat>image/svg+x\
ml</dc:format>\x0d\x0a\
        <dc:type\
\x0d\x0a           rdf\
:resource=\x22http:\
//purl.org/dc/dc\
mitype/StillImag\
e\x22 />\x0d\x0a        <\
dc:title />\x0d\x0a   \
   </cc:Work>\x0d\x0a \
   </rdf:RDF>\x0d\x0a \
 </metadata>\x0d\x0a  \
<defs\x0d\x0a     id=\x22\
defs6\x22 />\x0d\x0a  <so\
dipodi:namedview\
\x0d\x0a     pagecolor\
=\x22#ffffff\x22\x0d\x0a    \
 bordercolor=\x22#6\
66666\x22\x0d\x0a     bor\
deropacity=\x221\x22\x0d\x0a\
     objecttoler\
ance=\x2210\x22\x0d\x0a     \
gridtolerance=\x221\
0\x22\x0d\x0a     guideto\
lerance=\x2210\x22\x0d\x0a  \
   inkscape:page\
opacity=\x220\x22\x0d\x0a   \
  inkscape:pages\
hadow=\x222\x22\x0d\x0a     \
inkscape:window-\
width=\x221863\x22\x0d\x0a  \
   inkscape:wind\
ow-height=\x221025\x22\
\x0d\x0a     id=\x22named\
view4\x22\x0d\x0a     sho\
wgrid=\x22false\x22\x0d\x0a \
    inkscape:zoo\
m=\x220.86915209\x22\x0d\x0a\
     inkscape:cx\
=\x22163.84604\x22\x0d\x0a  \
   inkscape:cy=\x22\
212.80747\x22\x0d\x0a    \
 inkscape:window\
-x=\x2257\x22\x0d\x0a     in\
kscape:window-y=\
\x2227\x22\x0d\x0a     inksc\
ape:window-maxim\
ized=\x221\x22\x0d\x0a     i\
nkscape:current-\
layer=\x22svg2\x22 />\x0d\
\x0a  <path\x0d\x0a     s\
tyle=\x22fill:#9999\
99;stroke-width:\
1.33333337\x22\x0d\x0a   \
  d=\x22m 11.559322\
,153.62712 v -8 \
h 56 55.999998 v\
 8 8 h -55.99999\
8 -56 z m 28,-52\
.66667 -27.30894\
,-27.333331 h 15\
.654471 15.65446\
9 v -24 -24 h 24\
 23.999998 v 24 \
24 h 15.65447 15\
.65446 L 95.5593\
2,100.96045 c -1\
5.01992,15.03334\
 -27.619918,27.3\
3334 -27.999998,\
27.33334 -0.3800\
8,0 -12.98008,-1\
2.3 -28,-27.3333\
4 z\x22\x0d\x0a     id=\x22p\
ath817\x22\x0d\x0a     in\
kscape:connector\
-curvature=\x220\x22 /\
>\x0d\x0a  <path\x0d\x0a    \
 style=\x22fill:#20\
b2aa;fill-opacit\
y:1;fill-rule:ev\
enodd;stroke:non\
e;stroke-width:0\
.73913848px;stro\
ke-linecap:butt;\
stroke-linejoin:\
bevel;stroke-opa\
city:1\x22\x0d\x0a     d=\
\x22m 105.63227,107\
.57797 v 73.9639\
7 l 72.15997,0.3\
0066 V 88.335317\
 l -56.5253,-0.6\
01334 z\x22\x0d\x0a     i\
d=\x22path812\x22\x0d\x0a   \
  inkscape:conne\
ctor-curvature=\x22\
0\x22\x0d\x0a     sodipod\
i:nodetypes=\x22ccc\
ccc\x22 />\x0d\x0a  <path\
\x0d\x0a     style=\x22fi\
ll:#f5f5f5;fill-\
rule:evenodd;str\
oke:none;stroke-\
width:0.73913848\
px;stroke-lineca\
p:round;stroke-l\
inejoin:bevel;st\
roke-opacity:1\x22\x0d\
\x0a     d=\x22m 105.6\
3227,107.57797 1\
5.93533,0.15034 \
-0.30066,-19.994\
327 z\x22\x0d\x0a     id=\
\x22path814\x22\x0d\x0a     \
inkscape:connect\
or-curvature=\x220\x22\
\x0d\x0a     sodipodi:\
nodetypes=\x22cccc\x22\
 />\x0d\x0a</svg>\x0d\x0a\
\x00\x00\x04c\
\x00\
\x00\x0fWx\xda\xe5W\xc1\x8e\xdb6\x10\xbd\x07\xc8?\
\xb0\xca\xa5E-\x8a\xa4(\x8aR\xec\x0d\xd0.\x82\xe6\
\x90K\x9b\xb6g\xadD\xdb\xcaJ\xa2A\xd1\xf6:_\
\x9f\xa1m\xca\xda]m\x9a Er\x88\x0c\xc3\xe2\xcc\
#9\xf3\xe6q\xb8;\x7fu\xd76h\xa7L_\xeb\
n\x11PL\x02\xa4\xbaRWu\xb7Z\x04\x7f\xbf{\
\x1d\xca\x00\xf5\xb6\xe8\xaa\xa2\xd1\x9dZ\x04\x9d\x0e^]\
=\x7f6\xff)\x0c\xd1\xefF\x15VUh_\xdb5\
z\xd3\xdd\xf6e\xb1Q\xe8\xe7\xb5\xb5\x9b<\x8a\xf6\xfb\
=\xae\xcfF\xac\xcd*\xfa\x05\x85!L\x85\xc9\xfdn\
\xf5\xfc\x19B\x08\xf6\xee\xfa\xbc*\x17\xc1y\xcefk\
\x9a#\xb6*#\xd5\xa8Vu\xb6\x8f(\xa6Q0\xc2\
\x97\x17|\xe9\x22\xa8w\xaa\xd4m\xab\xbb\xfe8\xb5\xeb\
_\x8c\xd1\xa6Z\x0ep\x17\xd2>>\xa2h\x96e\x11\
a\x11c! \xc2\xfe\xd0\xd9\xe2.|0\x17\xe2\x9c\
\x9a\xcb\x08!\x11\xf8F\xd0\xcf\x84\xe5=0\xbb\x81\xef\
\x80\xf7\x06\xdc\xeb\xad)\xd5\x12&*\xdc)\x1b]\xbf\
\xbb\x1e\x9c!\xc1\x95\xad\xc6\xebxb\xef\xed{\x8f\xed\
\xaehU\xbf)J\xd5G\xde~Z`Tlz\xb2\
\xd4\xd5\x22\x808\xd9i\xb4\xaf+\xbb\x06ov\x1e\xaf\
U\xbdZ\xdb\x91aW\xab\xfdo\xfan\x11\x10D\x10\
X\xd1\xe0\xf1\xf1\xe6\x95.\xdd\xfe\x8b\xa0lty\x8b\
\x07\x12|$\xf9\x10\x04\xc1\x19\xc3\x14\x19\x9a\xc4)\x0d\
\xae\x1cj\xde*[T\x85-\x8eSN\xe1y\x93<\
A\x00\x04U\xcb\xff\xbc~}\x1e\x82\xa1,\xf3\x7f\xb5\
\xb9\xf5cx\x1c\xa4\xb8\xd1[\x08>\xb8\xba\xd8\xe7U\
\x99\x03\xcfma\xaf\xea\xb6X)W\xa3_\x81\xd6y\
tq\xdcG\xdb\xc3F\x8d\xd6=\xadl\xd4\xa9d\x93\
\xe2\xad\xca\xb6v\xb3\xa2\xbfl\xdd4o\xdc6\x01\x8a\
\x1e.[\xdbF\x8d\xac\xf3\xe8\x9c\x83\xcf1\x1a'9\
\x8f<\x09\xa7a\xa5\x96\xfd\x88!7\x14~\x8f\xf9P\
\x09W\x86\xcaU\xec\x0c\xdd@$\xa5n\xb4Y\x04/\
\x96\xc7'8{n\xb4\xa9\x94\xf1>q|\xee\xfb4\
\xc8\x09\xb2\x02)x\xbb\xbey\xafJku\xa3L\xd1\
9*(\xf1\xae\x95\x01\x1dM:\xb6u\xa5&=\x83\
:\x5c\x90\xc3f\xd3\xee~]Tz\xbf\x08\xd8#\xef\
\xbe\xee\xc0\x13z\x193I\x9e\x82xeg\xe9e\x15\
`r\xa0\x8c{k\xbf\xd6{\x97\xcf\x22X\x16M\xaf\
\x1e\xad\xf7A\xeb\xd6\x9d\xa74\x961\xe1\x8fC*\xe1\
\xb00\xc21K\x99\xe4\x8f\xbd\x90dH\x05f<f\
\xa9|*XX\x22|\xd2y\xf8\x94\xb3-\xee\xea\xb6\
\xfe\xa0\xaaQ\xe1.\x9bo\x8d\x81.\x1b6\xc5A\x99\
s\x1b\xf0\x22\xda\x14v\xed\x19\xb0\x87\x06ju.J\
NpBcho\x84\xbe\x5c\x82\xbe\xf3\x0e\xee\x86\x97\
\xbd5\xfaV\xe5 +\xe79\x0fOu\xc8\x13?l\
\xeaN\xc1\xc6\xb9\xd1\xdb\xae\x1a\x1b\xdf\xeb\xba\xcb\xe1\xd0\
(\xe3\xad\xc7A\x03\xa1\xdb\x9c{[U@\xe1\x8d)\
\x0e\xe3-C\x1f\xd6\x90\x9e\xeb\x18(K\xb1\xe0T\x12\
6\xa3\x84b\x99\xd28Aa\xcc\xb0\x144M\xe8,\
\xa1\x98\x09&\xc7\x95w\x09s\x9eM\x14Pw\x10\xb6\
\xd5&\x04\xbev\x85\xdd\x1a\xe5\x84\xe9\x89RMSo\
z5\xcd\xd5\x98\x22\xf7v\x89v`,\x93\xees\x9f\
1F0g\x19\x93\x09I\xfe\x07B.\xd9\xc9!;\
\xa7\xcaL\xe0d\x18\x83\x8a\xb2\x04s\xb8\x19/\x14\x18\
\x00I\x8eS\x99\xc4\xc9\x804\x87\xc1(>%\x97\xc7\
\xda\x98\xca\x94\xc2\x05\x10\x0b\x99JB\xbf\xb9J\xde:\
\x95\xc4\x22\x06\x96O*\x91P\x7f\x94\x00+<\x15\x8c\
\xce\x84\xc0Y*d2E$\xffR\x99|\x0dA\x22\
\x86\xaa$\xe2;\x10Dy\x8a9\xa14\x9d\x89\x18'\
2\x85\xd7\xa9\xa35EP\x98|.E\x0fa\x16.\
\x87\xde\xdd\xc5a\x09\xddI\x19\xd7\xfe\xa0\x7f\xc6<\xce\
\xb8\xfco4\xe8\x93K\x1c\xb38\x13\xf4\xab\xe9\x978\
ai\x96\xc6T~\x0fyf\x98e\x82;u\xc2y\
cT\x08\xf4\x0fb\x90[\x12g\x8cO4\xafo\xa6\
\xca\xefH\x0b\xf4v\x01G5\x93 J*\xe0\xef\xd8\
\x14::\xda!\x9a\xe2\x04^\xc5\x14-!\xfb\x01\x88\
y\x8b\xe0~\xa3\x5c\xb0\x84\xcd\xe0\x8cJI\xa0i\xa0\
?\xe0\x0c\x031<!l\x92\x19\xfeC0\x03\xed\x0a\
'B\xa4b\x06gJ\x10!i\xec\x98\x11\x0c\x03G\
O1\x13\xc6_\xc4\xcd\xdc\xfd/\x01\xbf\x1f\x01\x8e?\
\x9b\x11\
\x00\x00\x07\x83\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<svg\x0d\x0a   \
xmlns:dc=\x22http:/\
/purl.org/dc/ele\
ments/1.1/\x22\x0d\x0a   \
xmlns:cc=\x22http:/\
/creativecommons\
.org/ns#\x22\x0d\x0a   xm\
lns:rdf=\x22http://\
www.w3.org/1999/\
02/22-rdf-syntax\
-ns#\x22\x0d\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0d\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0d\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0d\x0a   width=\x2248\x22\x0d\
\x0a   height=\x2248\x22\x0d\
\x0a   viewBox=\x220 0\
 48 48\x22\x0d\x0a   vers\
ion=\x221.1\x22\x0d\x0a   id\
=\x22svg6\x22\x0d\x0a   sodi\
podi:docname=\x22ne\
xt.svg\x22\x0d\x0a   inks\
cape:version=\x220.\
92.3 (2405546, 2\
018-03-11)\x22>\x0d\x0a  \
<metadata\x0d\x0a     \
id=\x22metadata12\x22>\
\x0d\x0a    <rdf:RDF>\x0d\
\x0a      <cc:Work\x0d\
\x0a         rdf:ab\
out=\x22\x22>\x0d\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0d\x0a        <\
dc:type\x0d\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 />\x0d\x0a  \
      <dc:title \
/>\x0d\x0a      </cc:W\
ork>\x0d\x0a    </rdf:\
RDF>\x0d\x0a  </metada\
ta>\x0d\x0a  <defs\x0d\x0a  \
   id=\x22defs10\x22 /\
>\x0d\x0a  <sodipodi:n\
amedview\x0d\x0a     p\
agecolor=\x22#fffff\
f\x22\x0d\x0a     borderc\
olor=\x22#666666\x22\x0d\x0a\
     borderopaci\
ty=\x221\x22\x0d\x0a     obj\
ecttolerance=\x2210\
\x22\x0d\x0a     gridtole\
rance=\x2210\x22\x0d\x0a    \
 guidetolerance=\
\x2210\x22\x0d\x0a     inksc\
ape:pageopacity=\
\x220\x22\x0d\x0a     inksca\
pe:pageshadow=\x222\
\x22\x0d\x0a     inkscape\
:window-width=\x221\
863\x22\x0d\x0a     inksc\
ape:window-heigh\
t=\x221025\x22\x0d\x0a     i\
d=\x22namedview8\x22\x0d\x0a\
     showgrid=\x22f\
alse\x22\x0d\x0a     inks\
cape:zoom=\x224.916\
6667\x22\x0d\x0a     inks\
cape:cx=\x22-99.152\
543\x22\x0d\x0a     inksc\
ape:cy=\x2224\x22\x0d\x0a   \
  inkscape:windo\
w-x=\x2257\x22\x0d\x0a     i\
nkscape:window-y\
=\x2227\x22\x0d\x0a     inks\
cape:window-maxi\
mized=\x221\x22\x0d\x0a     \
inkscape:current\
-layer=\x22svg6\x22 />\
\x0d\x0a  <path\x0d\x0a     \
d=\x22M0 0h48v48h-4\
8z\x22\x0d\x0a     id=\x22pa\
th2\x22\x0d\x0a     fill=\
\x22none\x22 />\x0d\x0a  <pa\
th\x0d\x0a     style=\x22\
fill:#00d455;fil\
l-rule:evenodd;s\
troke:#00d455;st\
roke-width:2;str\
oke-linecap:butt\
;stroke-linejoin\
:round;stroke-mi\
terlimit:4;strok\
e-dasharray:none\
;stroke-opacity:\
1;fill-opacity:1\
\x22\x0d\x0a     d=\x22m 14.\
339033,12.813563\
 -0.20339,22.372\
882 19.728814,-1\
1.59322 z\x22\x0d\x0a    \
 id=\x22path4489\x22\x0d\x0a\
     inkscape:co\
nnector-curvatur\
e=\x220\x22 />\x0d\x0a</svg>\
\x0d\x0a\
\x00\x00\x08\xb0\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22n\
ew2.svg\x22\x0d\x0a   ink\
scape:version=\x220\
.92.2 (5c3e80d, \
2017-08-06)\x22>\x0d\x0a \
 <metadata\x0d\x0a    \
 id=\x22metadata8\x22>\
\x0d\x0a    <rdf:RDF>\x0d\
\x0a      <cc:Work\x0d\
\x0a         rdf:ab\
out=\x22\x22>\x0d\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0d\x0a        <\
dc:type\x0d\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 />\x0d\x0a  \
      <dc:title \
/>\x0d\x0a      </cc:W\
ork>\x0d\x0a    </rdf:\
RDF>\x0d\x0a  </metada\
ta>\x0d\x0a  <defs\x0d\x0a  \
   id=\x22defs6\x22 />\
\x0d\x0a  <sodipodi:na\
medview\x0d\x0a     pa\
gecolor=\x22#ffffff\
\x22\x0d\x0a     borderco\
lor=\x22#666666\x22\x0d\x0a \
    borderopacit\
y=\x221\x22\x0d\x0a     obje\
cttolerance=\x2210\x22\
\x0d\x0a     gridtoler\
ance=\x2210\x22\x0d\x0a     \
guidetolerance=\x22\
10\x22\x0d\x0a     inksca\
pe:pageopacity=\x22\
0\x22\x0d\x0a     inkscap\
e:pageshadow=\x222\x22\
\x0d\x0a     inkscape:\
window-width=\x2278\
4\x22\x0d\x0a     inkscap\
e:window-height=\
\x22480\x22\x0d\x0a     id=\x22\
namedview4\x22\x0d\x0a   \
  showgrid=\x22fals\
e\x22\x0d\x0a     inkscap\
e:zoom=\x221.229166\
7\x22\x0d\x0a     inkscap\
e:cx=\x22-47.999997\
\x22\x0d\x0a     inkscape\
:cy=\x2296.000003\x22\x0d\
\x0a     inkscape:w\
indow-x=\x2257\x22\x0d\x0a  \
   inkscape:wind\
ow-y=\x2227\x22\x0d\x0a     \
inkscape:window-\
maximized=\x220\x22\x0d\x0a \
    inkscape:cur\
rent-layer=\x22svg2\
\x22 />\x0d\x0a  <path\x0d\x0a \
    style=\x22fill:\
#999999;stroke-w\
idth:1.33333337\x22\
\x0d\x0a     d=\x22m 42,1\
72.31016 c -1.46\
6667,-0.61924 -4\
.166667,-2.73984\
 -6,-4.71245 l -\
3.333333,-3.5865\
6 V 93.477545 22\
.943938 l 4.3567\
6,-4.358975 4.35\
6761,-4.358974 3\
4.976572,-0.3780\
76 34.97657,-0.3\
78076 24.37995,2\
4.437904 24.3799\
5,24.437905 -0.3\
7995,50.915854 -\
0.37995,50.91586\
 -4.35774,4.3576\
4 -4.35775,4.357\
65 -52.975588,0.\
2717 C 68.50568,\
173.31379 43.466\
667,172.9294 42,\
172.31016 Z M 14\
8,69.210834 c 0,\
-0.191669 -9.9,-\
10.234849 -22,-2\
2.318179 l -22,-\
21.96969 v 22.31\
8178 22.318179 h\
 22 c 12.1,0 22,\
-0.15682 22,-0.3\
48488 z\x22\x0d\x0a     i\
d=\x22path817\x22\x0d\x0a   \
  inkscape:conne\
ctor-curvature=\x22\
0\x22 />\x0d\x0a</svg>\x0d\x0a\
\x00\x00\x08T\
\x00\
\x00\x1epx\xda\xed\x19io\xe3\xc6\xf5{\x80\xfc\x07\
\x82\xfe\xb2FEj\xeeC\x96\x1c\xb4X\x04)\x90\x22\
@\xb2\xdb\xebKA\x93#\x991E\x0a$%\xd9\xfb\
\xeb\xfb\x86\xe2M\xca\xebE\xb6\x01\x8aV\x86m\xce{\
\xc37\xef>F\xeb\xef\x9e\xf7\x89s2y\x11g\xe9\
\xc6\xc5>r\x1d\x93\x86Y\x14\xa7\xbb\x8d\xfb\xf1\xc3\xf7\
\x9er\x9d\xa2\x0c\xd2(H\xb2\xd4l\xdc4s\xbf\xbb\
\xff\xf6\x9buq\xda}\xfb\x8d\xe38\xe78*\x1f7\
.Sn\xb5|4\xf1\xee\xb1\xec\xd6\xa7\xd8\x9c\xff\x94\
=o\x5c\xe4 \x87)\xa7\x81\xc7\xd1\xc6\x05\x12\xa4\xde\
\xd5\x9d\x8fk|\xfaT\x84\xc1\xc1\xac\xfa(\xe7](\
\x94!$\xa4J.\x1c\x82\x08\xf6\x10\xf7\x08\xbd\xbd\xbc\
S\x00\xd7\x07\xf8]EY\x98\x06{`6N\x0f\xc7\
\xb2\xf8W\x90\x06\xc9K\x11\x17\x0e\xf1\xe1\xcc\xcbf\x10\
;-V\xcd1\x1b\xf7\xb1,\x0f\xab\xe5\xf2|>\xfb\
\x0d\xd0\xcf\xf2\xdd\xd2\x12*\x0eAh\x8ae\x03\xef\x13\
h\xcel\x094\x00\xbf\xc8\x8eyh\xb6@\xc3\xf8\xa9\
)\x97\xef?\xbco\x91\x1e\xf2\xa32\xea\xd1\x19\x9c\x7f\
\xa6\xd5\xc9\x04!\xb4\x1c\xf1\x0b\xcb\xb7n\xcd\xa3\xed\xdc\
V\xac\xb5^\x22\xb2$\xc4\x83\x1d^\xf1\x92\x96\xc1\xb3\
\x97\x167\xfdw\xc3\xb0}5\xccMP\xc6'\x13f\
\xfb}\x96\x16\x17\x9d\x0cwG\xdd\xee\xc31O\xaa-\
Q\xb84\x89\xd9\x9b\xb4,\x96`\xb9\xa5{o_X\
\xefM\x19DA\x19To_\xbc\xa0\x01ar\xd9\x03\
\xbb\x80\xb1\xd5\xcf\xef\xbf\xaf\x97\x00\x08\xc3\xd5\xdf\xb2\xfc\
\xa9Y\xc3\xc7n\x09\x1e\xb2#\xb8\x9a{\xdf\xc1\xd7Q\
\xb8\x02\x95\xef\x83\xf2>\xde\x07;c\x95\xf2\x07\xe0r\
\xbd\xec\x10\xc3\xdd\xe5\xcb\xc1\xf4\xe8^(\xe7\xe6b\xbd\
Y\xb9\xa2p\x1f\xdb\xb7\x96\xbf\x94q\x92\xfc\xd9\x1e\xe3\
:\xcb\x8e\xd9e\xcdm#\xcd\xb2/\xcez\xd9\xc8{\
YFf[\xf4\x94a\x97\x18\xb5\x8a\xd8\x07\xf9\x93\xc9\
[\xf6\xda\xa0(\xca,|\xb2\xfb\xff\x98\xe7\xd9\x19\xff\
\x08\x01\x9a\x97n\xbb/\xcbcP\xfc\xc6\x0d\x8ee\xd6\
As\xb3\xfd\x07\xc4!Dx\x1f\xf4\xf7\x11\xe8:\xd5\
\xa2|I@#\x19D\xe46\xc9\xce\xabS\x5c\xc4\x0f\
\x89q\xa7\xec\xc5E\xc5\xe0\xc6-\xf3\xa3\xe9\xcc\xb3>\
\x04\xe5cO\xd7\xf6(\x0bb\x5c+\xb7\x07\x07\xf0_\
\x1c`j\x01\xbf\xce\x8f\x0e\x87'\x8fW\x8f\x1e&>\
\xef\x81/\xd0f\xeb'\xa7O\xa5fw\x0b6\xf2\xf2\
cbV\xe6d\xd2,\x8a\xee\x8a2\xcf\x9e\xcc\xea\x06\
U\x9fz\xe9Uyl\x05\xf9\xefP\xf6\xa9\x94y\x90\
\x16\xd6q ]\x85Ab\xde!_\xdd^\xa0IP\
\x9aw\x17\x86n;\x07\x00\x03WFk\x96 `i\
\xf2\xb4%Y\xaf?\xa6q\x09Q\x7f,L\xfe\x8b\xcd\
.?\xa5\x1f\x8b\x9e*\xeb\xacJ}\x8a\x18\x91Dt\
\x986\xc1\xfa\x9ak\x81Q\x0fU\x93\xfe\xd0\xb1\xdc\xf1\
)}!\xb8\xd6\x92/\xb4\xcf\xa8\x04\xb2\xeavh\xf4\
\xfam\xbb\xa9g\xb2\xd2<\x97=u@(\xad\xaal\
\x08\xfb!HL~2s:\xcf\xd2\xd2\xab\x9eW\xa9\
\x8d\xb9\xe4\xae\x82\x9c+\xd6\x07\xa0\x22\xfedV\xc2\xe7\
\x5cRrx\xbeK\xe2\xd4x\x17\x09\xc1\x14\x84_6\
m\x83}\x9c\xbc\xac\x0a\x90\xc5\x83#\xe3\xed\x9d5\xea\
\xea\xe6\x81\xda\x9fj\xe1e\xc0\x14D\xe5\x0a7\xe6M\
\xa1Z\x0dm\x8b|,\xa8\xa6\xb4\xcf0\x14&\xc8\xc5\
\x8c\x12\xc2\x98\x16}\xcc\x8bU\xb1\x12Br\xa9\xdd\x91\
\xd3Z\xa5`.\x85{\xbf.A\x1b\xe9 \x7f\xb4U\
(\xcf\xac.\xacH\xee`CE\xc1\xbe\x06$\xd8\x10\
\xd5\xf3\xd9\xd7\xc5{E\xa4\xd7\x84\x1a\x89u\x8f\xd6\xcb\
\x8a\x93{\xf8\x0f2\xb5.\x5c\xfbB\x9d\xb1lR\xba\
<\xb6\xb2\xd9\xaa\x18\xd9\xda^\x13?@\x12\x0c\xb3$\
\xcb7\xee\xcd\xb6\xfa4\xc7>dyd\xf2\x06'\xaa\
\xcf\x10W\xcb\x06\x15\xbe\x81g\x0f\xbf\x9a\xb0,A\x7f\
\xe0\xbf\xd6\xd7p\x9b\xa0v9\x08>\x8b8\xc6\x91\x99\
\xc5\xb4i\xc92\xd9\x1e6\x8f.\x1e\x83(;o\x5c\
2\xc1\x9e\xe3\x140^\x1d\x98XqumK\x13\xa1\
\x18q\xe9\xf6r{\xab\xb3\xf6\xcd\xe21;[\x81\xc0\
\xe2A\xd2\x85\x7fK\xf0S\x96A\x10c\xeas\x82T\
g\xe5\x16\x1f\x82\xa5\xa9\x86\x1c\xa1%\x9a\xb2\x13\x82\x94\
\x14\xfbBcE\xd95f\x81\x02\xbf\x8a\x04\x02\xdeU\
1\xf7\xc1s\xbc\x87\xf0\x8dz\x86\xeb\xce>\xe69\x94\
 /\x09^\x0c\xd8}\x87\x09\x9fWx\xf8hB\xc8\
\x96\x0fY\x90G\xd6(u\x1e]\xefz\x8a\xdb1\xcc\
\xbb\x9a\xb8\x1bd\xad\x1d\xe3\x8c\xbd\xa5\xc4P4-1\
\x0b\xe4\xfc`\x9b\xd2\xbf\xda??@\x83\xfa\xcfA\xa4\
\xb7\xc2di\x0a\xfe\x98\xe5\x1e\x88u\x0a\xcacnz\
\xfe3\x8e[\x9bx\x06\xfd\xc0n\xc4\xcfN#|\xa5\
\xc4@{\x92\xc7\xcf\xef\xa0\x0aI\xaa\x89f\x0b`q\
\xd1\xad\x84\xf6\xa1{\xe3\x98/\x88\xf4\xb1\x22\x9a\xe2\xdb\
A\xf7\x93\x03\x9bW\x13J/#\xaent\xf5\x19f\
\x13\xf03\xaa\x18\x92\x827p\x9b\xbc@\x05\x90\xca\x8e\
i\xd4\x07\xfe\x9a\xc5\xe9\x10\x0a=\x91\xc9\x13\xf0\x88r\
\xc5\x1aX\x14@<\xe5y\xf02\xc8\xc6m.\x9b\xa6\
E\xcb\xbff\xa3\x94\xd5\xd4B\xe1\x0bJ\x85\x1e\xa5\xcc\
&\xda(\xf71Ut\x9cQm.\x14\xc8\x97\x12i\
\xca'\xa9\xd0\xc3\xda\x87\xe0\x80\xf7\x86\xa8\x1cp\xdc\xa7\
Zj.X\xdf\x98#s\xd6\x06\x95L\xcb!\x81r\
\xae\x06#\x9f+\x88U\x84\xf5\xc0j\x13\x9a5\xd5~\
\xcc\x5c\xf7\x15\xea#\x84\x11\xe4\xfa\xcaW\xa0\x1b\xe1\x1a\
\x11\xc4\x17\x18\x83B\xa4\xc2\xca\xfa\x8a@\x9a\x102:\
u\x1a-CC\x08\x84\xb0;\xc1^\xf1\xa8\xb6 )\
\xa9\xb4\xa6\xd3\xf7l\xa7\xefx\x5cZ\x06\xa9\x12\x0b\x0f\
K\x9f`\x8c\x98v\x1ea.\xd3\x881J\x9d\x93\xc3\
|\xca\xc1\x05\x04@\xbd\x16\xfcih\x83\xd7y\x87\x9e\
JB\x87\xf3\xdf\xcb:\xffO\xb2\x8e|!\xa1z\xe1\
Y\xd6)\xff\x8d\xbc\xab\xaf\xcf;\xf6)C\x0c\xcbY\
\xde\xd9\x15\xde\xd9,\xef\xbb\xc9\x19A\x1e\x07P\xa4\x1e\
L\xd2\xabb\xce\xb4\xd9\x93J\xbc\x12\x0b\xbdN\x96R\
\xce\xe8l'[\xf5t\x08E,\x08&M\x1c\xe4\x05\
%\xa6\xf4\xa7\xd1\x0e\x99\x8cr\x0ay\xf0R\x1azK\
;\x1a\x09\xa2\x95\xa4\x90\x04\xa4\x14\x90e\xe8$\xe0\xaf\
\xd9\xafU6\x851\x81\x10\x0a\xd4\x98/\xa1\xb5\xc4\x0a\
\x94\x0a\x05\x08\xfa\x0f&@\xd7\x9e\xedE(\x13\xccI\
`\x18\xf3!\x088\x17\xc0\x06d\x17i\xfd\x08\xfaN\
\x0e\x0d\x87\xd6\x80\x074b\x90\xb0\x17^\x83\x7f\x84Q\
M\x10\xa6\x14\xa9\xcc\x06II\x08\xda\x1d\xc0\x01\x0a\xef\
\x13\xae\xf4\xc5\x94B \xd0\x0b\x98r\x86\xe1\xb6\xb2S\
L\xd4\x8c\xad\x97\xbb1d4\xca\xbci\xa0\xf9-c\
\x8d\xf5K\xa1\xe8\x17\x8f5ui\xfe\x82\xb1\x06)M\
\xa6\x5c\xdb\xd2\xc7\x05\x84\x17\x16LN\xd1\xb6\xfc\x09_\
\x0b\x81\x99\xd0\xd7]\x1f\xf2\x00\x9d\x1ft\xde8\xee\x8c\
\x86\x1eK\x8f\xcd\xed\x18\xcc>\xaf\xe9\xe0sr\x7fV\
\xf2\xb1\xecW\xc6\xa0\xffu\xc7\x91\xa0\x1b<\xef7\x90\
k\x14\xf4\x89\x88\xbd\xea7\x0c}e\xbfQ\xbf\x8f\xdf\
\x5c\x11|,\xfa\xff\xddfF{\xd8g\xb6\x03\x15W\
\xfd\x06\xda_&\xd5g\xfc\xc6\xfb\xda\x19Gy\xbfK\
\xce\xb9.\xfdX\xfeW\x9dg\x5c\xbc\xae\xcd\x07\x82}\
~>\xa8*.&P\x8a\xeb\x8e\xa1]z\xdc^\x1f\
q\x8c\x17\x9e\xf2\xb1\x96\x8ap\xf6\xc6\x11\xe1-\xe3\xf3\
\xb0L\xcf\xe8\xcc*\xda~\x9f4\x1c\x97\x9b\x1b\xff8\
\x0f\x13s-2:\xf3t]\xe5\xbc\xff\xcev\x5c\x10\
)\x92b\xfa\xb6)\xf7\xc1\x9cL\xf2\xe5S\xae\x85f\
\xdbma\xca\x15\x9aL\xbew\x87 \x86\x88\xac\xae\xbf\
\xea@\xbe\xae:\x8c\xe6\xbac{\xf7\x03\xd3+\xd5\x82\
\xf0\x19\xdf\xb6\x97?X\xf9\x12\x11\xc9ft\x9f\x03\x96\
Af\xa0\xd0w\xbd\xb5\xc9\x1f\x04K\xad\xd6\xd7n\xd7\
\xa7z\x97>\xd4[\xc1\xde\xa6\xf7J\xd5_\xedv\xa1\
\xedq\x09\xe8\x8c\x11hL\x17\x14F\x0f\xa2a0v\
@O\xd0EKm\xef\xc61BL\xbdj\x8c\x99\x11\
\xe7\x0b\xae\x8aF9\x0ctf\xec\x97I\xc5\xc6\x0d\xc3\
\xb1%\x86y\xa0\xbf\xea\x9e{O]\x96\x98\xbd~\x80\
.\x1b\x09I\x14t\xf7\x84\xfbJI\x10~\xf4\x1d\xc0\
\x8ea\xd6\xbb\xef\x98\xdc\xb5\x09\xdc\x13\xfe\xda\x1d\x07&\
L\x13\xdd~%rapm\xbf\x89\x83\xff\xff\x06\x09\
\xcd\xbf;\
\x00\x00\x06\xd1\
\x00\
\x00%\xc4x\xda\xddZ\xdbn\xe36\x10}/\xd0\x7f\
P\xb5/\xbb\xa8Eqx\xa7jo\x81vQ\xa0\xaf\
\xbd\xa0\xcf\x8a\xa4\xd8\xea\xca\x92!\xc9q\xb2_\xdf\xa1\
d9rd\x07ia\x14^\xcb\x09\x12r\x86\x14y\
8sf\x86\xc9\xfc\xc7\xc7u\xe1=du\x93W\xe5\
\xc2\x07B}/+\x93*\xcd\xcb\xe5\xc2\xff\xf3\x8f_\
\x02\xe3{M\x1b\x97i\x5cTe\xb6\xf0\xcb\xca\xff\xf1\
\xe3\xb7\xdf\xcc\xbf\x0b\x02\xef\xe7:\x8b\xdb,\xf5vy\
\xbb\xf2~-?7I\xbc\xc9\xbc\xf7\xab\xb6\xddDa\
\xb8\xdb\xedH\xbe\xef$U\xbd\x0c?xA\x80Cq\
p\xf3\xb0\xfc\xf6\x1b\xcf\xf3\xf0\xdde\x13\xa5\xc9\xc2\xdf\
\x8f\xd9l\xeb\xa2\xd3M\x930+\xb2uV\xb6M\x08\
\x04B\x7f\xa4\x9f<\xeb'n\x05\xf9C\x96T\xebu\
U6\xdd\xd0\xb2y7\xd6\xae\xd3\xfb\x83\xba[\xd2\x8e\
wZ`\xad\x0d)\x0b\x19\x0bP#h\x9e\xca6~\
\x0c^\x8c\xc5u\x9e\x1a\xcb(\xa5!\xcaF\xaaoT\
\x8b\x1aDv\x83\xdf\x07\xfd\xa1\x834\xd5\xb6N\xb2{\
\x1c\x98\x912k\xc3O\x7f|:\x08\x03J\xd26\x1d\
\xcf3\x00{\xf4\xde#\xb4\xcbx\x9d5\x9b8\xc9\x9a\
p\xe8\xef'\xd8\xe5i\xbbZ\xf8\xc2\xf4\xcdU\x96/\
W\xeds\xfb!\xcfv?U\x8f\x0b\x9fz\xd4\x13\x06\
\xbf\x08u\x0f\xf4\xe2<]\xf8\xb8'\xb6W~6\x9c\
A\xbe\x7fWt\x10Qb\x19\xe1\xde{&\xa8\x94B\
\xcd<F\xc1\x04\x94\x07\x00\x1f\xfa1\xc36\xa3\xb4J\
\xdc\xb2\xf1\x0d\xc9*[\xe3\xc9&\xc4\xe1\xf7\xd1i\xcd\
\xd3\xec\xbe\xe9\xd4\xfbE\xb8\xa6\xf0\xbd\xb0\x17\x1e\xa6p\
\xe3S\xb7\x87\x91\xea]\xdc\xec\xf7\xeey\x9bx\x89\xd6\
RT\xf5\xc2\x7fw\xdf=\x83\xe4\xae\xaa\xd3\xac\x1ed\
\xaa{\x8ee\x15\xc2\x99\xb7O\xbd\x9b\x0c\xf3\x0f\xfbu\
\x13\x1f\x14\xe8\x19\x85f\x15\xa7\xd5n\xe1\xb3\x89\xf4K\
U\xad\xf1\x10\x886JH\xc3'\xf2\x04OD\x00\x91\
\xdaZ\xaa\xa7R\xb7(I8\xb7\x00r\x22EX\xb7\
\xce\x95\x82m\x99\xb7h\xaa\x9b\xc7\xe9\x04\xdb\xbav\x1a\
E\xfc\x94\xe1\xf6\x97\x5c\x08\x18\x94\x9aU\xb5[\xd6\x0e\
\xc8\xfb\xb8xF\xf2\xfcd\xbb\xbc\xc4]\x06{C\x03\
#\xe1\x9c\xca`|@\x99<\xa7\x83\x1bW\xf6\x9c\x10\
\xf7\xcd\xf49\xe1:~\xcc\xd7\xf9\x97\x0cW\x0e\x07K\
Ygm\x9c\xc6m<\xb2\x8f\xa1K\xf7\x96\x86JH\
\x09\xd1o\x9f~\xd97\xb1#I\xa2\xbf\xaa\xfa\xf3\xd0\
\xc6\xc7\xa9\xc4w\xd5\x16W\xef\x7f|\xee\x9f\xa7I\x84\
N\x8c\xc6\xfb1_\xe3\x89;\x02\xf8\x1e}v\x1e>\
\x0b\x8e\xb5\xdb\xa7M6\x9a\xb7\x9f\xb9\xcez>8\xc9\
\x8ci\xb2\xce\xdd\xa8\xf0\xf76/\x8a_\xddk\x86\xed\
\x8d\xa6\xcd\xdb\x22\x1b\xf5\xce\xc3\xfd\x1e\x86=\x86\xe3M\
\xce\xc3\x01\x84\xbe\xb9|\x09i\x11\xdfe\xc5\xc2\xff9\
\xde\xc4\xde\xf48\x97u\xb5\xdd\xac\xab\x14\xd7\xdbY\x90\
?B\xb7\xeb8\x0ci\xeb\xb8l\x1c\x0e\x0b\xbf\xfb\xb5\
\xc0\x08\xf2\x9e\xce\x02\xa0T\x10\xae\x18\xfbp8\x84\xe5\
aCn\x9a#\x93<\x9a\x07!\xad\xf3\xc7\xf7\x94\x18\
\xa5@q\xc9g\xd4}\x9e\x9b\x8c(\xa9\xb5\xd1v\x06\
\x5c\x13\xd0\x8c\x0f\xcc\xd3\x99w\xfbT\xe0\xba\xef\x11\xca\
hO\x09?4m]}\xce\xa2w\x22u\x1f\x7fd\
\x07y\x9d\x14\xe3\xe3\xaa\x1d\x1bH\x7f\xd4\xd3\xf9\x22\xa5\
\x86p\x90\xfaH\x80\x96\xcc\x04\x91BZc\xc6\x02\xb7\
\xbdM\xdc\xae8\xe7j\xdc\x7fje\xae\x11\xecy&\
\x82\xbeYo\x8b,\xca\x1e\xb2\xb2J\xd3\xc3\xd2m\xf7\
\xec\x9b\xbd/F\xb0y\x1c:\x8a\xbc\xcc\xf0\xe8\xa2\xbb\
m\xdb\x8e\xfb\xfe\xae\xf22B\xf3\xca\xea\xa1\xf7\xf0\xb2\
\xb1\x8d\xbd\x1d\x08\xe0\x04\xb8\x9d\x00\x81\x07A\x0d\x15\x94\
\x9d\x03\x22\xe07\x07\x05Sh\xe1\xa0^B!8\xb1\
\xc2\xa2y\x9e\x85\xe2\xf6\xac\x82[\xe7\x93|\x02\x05%\
\x82\x0a.\xf8Y(\xf4\xcdA!4\xd1\xd4L\x99\xc2\
 BV\xcb\xf3\x0e\x22o\x0f\x0a\x89\xa4\xcd\xe0%\x14\
 \x08\x93\x8a\xc2+\x5cq{XpI@\x82|\x89\
\x85$\xd4*\xb4\x17s\x9e,\xd8\xed\x11'Fpe\
\xa6lA\x0c\x1a\x85\xd0p\x16\x0b{{\xe1\x14\xa1\xb0\
j\x12C\x00\x88\x10\x16\xd8y\xb3\x80[\xb4\x0a\xce\xec\
\xc4C8\xa0Y\x18q\xcc\xa8\xc7P\x04\xf4\xf6\xe8\x82\
\x11\xcck\xa7`\xa0\xb9`\xde\xfc\x8aY\xdc\xa0\x8f`\
ni\x04\x9b\x04TW=\x03\xd3\xec\x15,\xbe\x9a\x9c\
\xd3\xady\xbc\x8dC\x1d_\x958q[\xd5\x01V\xf4\
\x0fq\xbb\xadq\x07\xf4\xd4\x8e\x05\x93G\x94\xe0\xea`\
O\x11*\x8d\x96V\xce\xd0\xbd0qW\x92y\x9a0\
E\xa9\x92r&\x09\xd7\xd6\xbc\x09\xa2\xb7c\xf2\xef\x11\
\xe9\x1a\x05V\xf6m$\x86\xbe4nVq]\xc7O\
QY\x95\xd9\xff\x80\x9d\x9c`\xc7\x5c\xc5i0:#\
v\xa0\x89\xc5z\xd5\xe3\x842$e>\x0b0\x9b\x13\
\xd4^\x16;\xf7Bf\xb9f\xfa\xca\x0cKO\xc0\x01\
GO\x14W;\xebB\x18\x13 =\xa0X\xf7h#\
\xc4,\xe0\x04\xd3>\xb84:V(\x0bJ\xab+C\
\xc7\x9ep;\x8e\xd6\x22\xa5C\x07\xf3>!\xad\x07]\
Q\xc8\x8d\x85\x19\x10k\xb5\xbd<8\xee\x22\x02\xf8u\
\x81\xa3\xe0\x94_I\xad\xadv~\xc5\x0d\xd1JH/\
@\x90\x941\xdc\xce\x14a\x8c\x9a\x8b\xfb\x15\x1a\xa8e\
\xd7f9\x8aO\xc1Av\x06i,\x9b\xf5\x85$2\
\xb6\x17`2\xa8\xd1\x099\xcc\x02 J\xeb\xcb\x9b\x0e\
\x97\x82\x81\xb92t\xa6~\x85\x89\x80\x16V\x83\x0bg\
XDr\xaa\xb5\xe7n\xc9\x19\x15hM@8\xc6\xba\
\x8b\x83\x03\x80Q\xf2\xcaB\xbd\x9e\xba\x95`D\x1a\xe4\
\x9cYw/E5\x17^`\x89S\x95\xcc\x112\x97\
\xea\xe2\x84\xac-\x15\xf8\xba+3\x1c=\x8d\xe5\xc2\x9d\
\xa3\xbbr\xe89GR-<\x8c`V\xf2\xce\xa9\x90\
 \xa8\xba<\xe9p\xaa4h{e\xe8\x9c\x08\xe6\xc8\
\xbe\x80\x05y\xc7\xc8\x94\x00r\x01\xba\x15\x00P\xa3\x91\
\x90\x85\xb9<6Zp\xac\xe9\xe8\x95\xb9\xd5q2\xdc\
\x132V\x19\x18\xc3Y\x97\x05\xbaKN\xa3=C,\
\x93J\xcf\x18\x01-\xf9\xc5\xa1\xc1\xec\x5c2\xca\xaf\x8d\
q\x82i\xb4\xc2j\xd4`\xb4R.Za\x99.4\
S^\x80\x86\x0f\x0a\xa3\xd7,\xc0\xa4\x19\xf1\xba8>\
\x9cbug\xd9\xf5\xe1s|\xaf\xdf#d\x89\x04\xdd\
\xc7s$\x1eL\xff\x90\x96\x1d=+\x85\xa8a\xda\xc3\
@|\x05\x08\xbd\xfd:\xcbb-p\x9c\xdcv\xb5:\
\xc5\xa2SJ*_\xa9\xd5/\xf7\x97\x00JS\x11\xc7\
Wp\xa1e\x09\x05y\xea\xfa\x1b\xcb%\xa5\xec+`\
\xa8\xaf\x05\x8c\x8bTP\xfcTH\xa2\xc6R&\x5c:\
\xa3]\xf0\xf6\x12\x8fb\xc6G5 \xb3PLl\x90\
k\x84\xbb\xca\x00`\x8ej$`}\xfe\xb2\xe3\xbf{\
\xd6)\xd8\xdc\x7f\xbe\x18ta).\x84\xdf<\x5c\xee\
\xffZ\xef~\xce\xdd\xff\x16\xe0\xcf\x7f\x00\x93\x13\xca\xa6\
\
\x00\x00\x0aR\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<svg\x0d\x0a   \
inkscape:version\
=\x221.1 (c68e22c38\
7, 2021-05-23)\x22\x0d\
\x0a   sodipodi:doc\
name=\x22fusion.svg\
\x22\x0d\x0a   id=\x22svg6\x22\x0d\
\x0a   version=\x221.1\
\x22\x0d\x0a   viewBox=\x220\
 0 48 48\x22\x0d\x0a   he\
ight=\x2248\x22\x0d\x0a   wi\
dth=\x2248\x22\x0d\x0a   xml\
ns:inkscape=\x22htt\
p://www.inkscape\
.org/namespaces/\
inkscape\x22\x0d\x0a   xm\
lns:sodipodi=\x22ht\
tp://sodipodi.so\
urceforge.net/DT\
D/sodipodi-0.dtd\
\x22\x0d\x0a   xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22\x0d\x0a   xml\
ns:svg=\x22http://w\
ww.w3.org/2000/s\
vg\x22\x0d\x0a   xmlns:rd\
f=\x22http://www.w3\
.org/1999/02/22-\
rdf-syntax-ns#\x22\x0d\
\x0a   xmlns:cc=\x22ht\
tp://creativecom\
mons.org/ns#\x22\x0d\x0a \
  xmlns:dc=\x22http\
://purl.org/dc/e\
lements/1.1/\x22>\x0d\x0a\
  <metadata\x0d\x0a   \
  id=\x22metadata12\
\x22>\x0d\x0a    <rdf:RDF\
>\x0d\x0a      <cc:Wor\
k\x0d\x0a         rdf:\
about=\x22\x22>\x0d\x0a     \
   <dc:format>im\
age/svg+xml</dc:\
format>\x0d\x0a       \
 <dc:type\x0d\x0a     \
      rdf:resour\
ce=\x22http://purl.\
org/dc/dcmitype/\
StillImage\x22 />\x0d\x0a\
      </cc:Work>\
\x0d\x0a    </rdf:RDF>\
\x0d\x0a  </metadata>\x0d\
\x0a  <defs\x0d\x0a     i\
d=\x22defs10\x22 />\x0d\x0a \
 <sodipodi:named\
view\x0d\x0a     inksc\
ape:document-rot\
ation=\x220\x22\x0d\x0a     \
inkscape:current\
-layer=\x22svg6\x22\x0d\x0a \
    inkscape:win\
dow-maximized=\x221\
\x22\x0d\x0a     inkscape\
:window-y=\x22-8\x22\x0d\x0a\
     inkscape:wi\
ndow-x=\x2254\x22\x0d\x0a   \
  inkscape:cy=\x22-\
91.728813\x22\x0d\x0a    \
 inkscape:cx=\x22-3\
1.525423\x22\x0d\x0a     \
inkscape:zoom=\x222\
.4583334\x22\x0d\x0a     \
showgrid=\x22false\x22\
\x0d\x0a     id=\x22named\
view8\x22\x0d\x0a     ink\
scape:window-hei\
ght=\x221057\x22\x0d\x0a    \
 inkscape:window\
-width=\x221858\x22\x0d\x0a \
    inkscape:pag\
eshadow=\x222\x22\x0d\x0a   \
  inkscape:pageo\
pacity=\x220\x22\x0d\x0a    \
 guidetolerance=\
\x2210\x22\x0d\x0a     gridt\
olerance=\x2210\x22\x0d\x0a \
    objecttolera\
nce=\x2210\x22\x0d\x0a     b\
orderopacity=\x221\x22\
\x0d\x0a     bordercol\
or=\x22#666666\x22\x0d\x0a  \
   pagecolor=\x22#f\
fffff\x22\x0d\x0a     ink\
scape:pagechecke\
rboard=\x220\x22 />\x0d\x0a \
 <path\x0d\x0a     fil\
l=\x22none\x22\x0d\x0a     i\
d=\x22path2\x22\x0d\x0a     \
d=\x22M0 0h48v48h-4\
8z\x22 />\x0d\x0a  <g\x0d\x0a  \
   id=\x22g21885\x22\x0d\x0a\
     transform=\x22\
matrix(1.5947499\
,0,0,1.5947499,1\
98.17822,40.6171\
72)\x22>\x0d\x0a    <elli\
pse\x0d\x0a       styl\
e=\x22fill:#aeaeae;\
fill-opacity:1;s\
troke:#ffffff;st\
roke-width:0.377\
953;stroke-linec\
ap:round;stroke-\
linejoin:round\x22\x0d\
\x0a       id=\x22path\
848\x22\x0d\x0a       cx=\
\x22-116.94915\x22\x0d\x0a  \
     cy=\x22-11.186\
44\x22\x0d\x0a       rx=\x22\
6.1016951\x22\x0d\x0a    \
   ry=\x226.3050847\
\x22 />\x0d\x0a    <ellip\
se\x0d\x0a       style\
=\x22fill:#aeaeae;f\
ill-opacity:1;st\
roke:#ffffff;str\
oke-width:0.3779\
53;stroke-lineca\
p:round;stroke-l\
inejoin:round\x22\x0d\x0a\
       id=\x22path8\
48-6\x22\x0d\x0a       cx\
=\x22-100.77966\x22\x0d\x0a \
      cy=\x22-7.830\
5092\x22\x0d\x0a       rx\
=\x226.1016951\x22\x0d\x0a  \
     ry=\x226.30508\
47\x22 />\x0d\x0a    <pat\
h\x0d\x0a       style=\
\x22fill:#aeaeae;fi\
ll-opacity:1;str\
oke:none;stroke-\
width:1px;stroke\
-linecap:butt;st\
roke-linejoin:mi\
ter;stroke-opaci\
ty:1\x22\x0d\x0a       d=\
\x22m -113.89831,-1\
6.423729 c 5.288\
13,3.758339 6.58\
476,4.781723 11.\
87289,2.593221 l\
 -3.3305,9.81355\
89 c -2.07314,-1\
.9708122 -5.1456\
7,-2.7984553 -10\
.75425,-1.194915\
3 z\x22\x0d\x0a       id=\
\x22path990\x22\x0d\x0a     \
  sodipodi:nodet\
ypes=\x22ccccc\x22 />\x0d\
\x0a  </g>\x0d\x0a</svg>\x0d\
\x0a\
\x00\x00\x09\x22\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22c\
opy.svg\x22\x0d\x0a   ink\
scape:version=\x220\
.92.2 (5c3e80d, \
2017-08-06)\x22>\x0d\x0a \
 <metadata\x0d\x0a    \
 id=\x22metadata8\x22>\
\x0d\x0a    <rdf:RDF>\x0d\
\x0a      <cc:Work\x0d\
\x0a         rdf:ab\
out=\x22\x22>\x0d\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0d\x0a        <\
dc:type\x0d\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 />\x0d\x0a  \
      <dc:title \
/>\x0d\x0a      </cc:W\
ork>\x0d\x0a    </rdf:\
RDF>\x0d\x0a  </metada\
ta>\x0d\x0a  <defs\x0d\x0a  \
   id=\x22defs6\x22 />\
\x0d\x0a  <sodipodi:na\
medview\x0d\x0a     pa\
gecolor=\x22#ffffff\
\x22\x0d\x0a     borderco\
lor=\x22#666666\x22\x0d\x0a \
    borderopacit\
y=\x221\x22\x0d\x0a     obje\
cttolerance=\x2210\x22\
\x0d\x0a     gridtoler\
ance=\x2210\x22\x0d\x0a     \
guidetolerance=\x22\
10\x22\x0d\x0a     inksca\
pe:pageopacity=\x22\
0\x22\x0d\x0a     inkscap\
e:pageshadow=\x222\x22\
\x0d\x0a     inkscape:\
window-width=\x2218\
63\x22\x0d\x0a     inksca\
pe:window-height\
=\x221025\x22\x0d\x0a     id\
=\x22namedview4\x22\x0d\x0a \
    showgrid=\x22fa\
lse\x22\x0d\x0a     inksc\
ape:zoom=\x221.2291\
667\x22\x0d\x0a     inksc\
ape:cx=\x22-47.9999\
97\x22\x0d\x0a     inksca\
pe:cy=\x2296.000003\
\x22\x0d\x0a     inkscape\
:window-x=\x2257\x22\x0d\x0a\
     inkscape:wi\
ndow-y=\x2227\x22\x0d\x0a   \
  inkscape:windo\
w-maximized=\x221\x22\x0d\
\x0a     inkscape:c\
urrent-layer=\x22sv\
g2\x22 />\x0d\x0a  <path\x0d\
\x0a     style=\x22fil\
l:#999999;stroke\
-width:1.3333333\
7\x22\x0d\x0a     d=\x22m 59\
.627116,180.3117\
2 c -1.46666,-0.\
62009 -4.16666,-\
2.7414 -6,-4.714\
01 l -3.33333,-3\
.58656 V 109.477\
54 46.943938 l 4\
.35897,-4.358975\
 4.35898,-4.3589\
74 h 50.615384 5\
0.61539 l 4.3589\
7,4.358974 4.358\
97,4.358975 v 62\
.615382 62.61539\
 l -4.35758,4.35\
897 -4.3576,4.35\
897 -48.97574,0.\
27327 c -26.9366\
64,0.15029 -50.1\
75744,-0.23409 -\
51.642414,-0.854\
2 z m 94.000004,\
-70.7524 V 53.55\
9322 h -44 -44.0\
00004 v 55.99999\
8 56 h 44.000004\
 44 z M 17.92053\
6,74.250594 l 0.\
37325,-59.308728\
 4.35767,-4.3579\
39 4.35768,-4.35\
79383 51.30899,-\
0.3786652 51.308\
994,-0.3786654 v\
 8.0453319 8.045\
332 h -48.000004\
 -48 v 56 55.999\
998 h -8.03992 -\
8.03991 z\x22\x0d\x0a    \
 id=\x22path817\x22\x0d\x0a \
    inkscape:con\
nector-curvature\
=\x220\x22 />\x0d\x0a</svg>\x0d\
\x0a\
\x00\x00\x07y\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<svg\x0d\x0a   \
xmlns:dc=\x22http:/\
/purl.org/dc/ele\
ments/1.1/\x22\x0d\x0a   \
xmlns:cc=\x22http:/\
/creativecommons\
.org/ns#\x22\x0d\x0a   xm\
lns:rdf=\x22http://\
www.w3.org/1999/\
02/22-rdf-syntax\
-ns#\x22\x0d\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0d\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0d\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0d\x0a   width=\x2248\x22\x0d\
\x0a   height=\x2248\x22\x0d\
\x0a   viewBox=\x220 0\
 48 48\x22\x0d\x0a   vers\
ion=\x221.1\x22\x0d\x0a   id\
=\x22svg6\x22\x0d\x0a   sodi\
podi:docname=\x22ru\
n_cascade_step.s\
vg\x22\x0d\x0a   inkscape\
:version=\x220.92.2\
 (5c3e80d, 2017-\
08-06)\x22>\x0d\x0a  <met\
adata\x0d\x0a     id=\x22\
metadata12\x22>\x0d\x0a  \
  <rdf:RDF>\x0d\x0a   \
   <cc:Work\x0d\x0a   \
      rdf:about=\
\x22\x22>\x0d\x0a        <dc\
:format>image/sv\
g+xml</dc:format\
>\x0d\x0a        <dc:t\
ype\x0d\x0a           \
rdf:resource=\x22ht\
tp://purl.org/dc\
/dcmitype/StillI\
mage\x22 />\x0d\x0a      \
  <dc:title />\x0d\x0a\
      </cc:Work>\
\x0d\x0a    </rdf:RDF>\
\x0d\x0a  </metadata>\x0d\
\x0a  <defs\x0d\x0a     i\
d=\x22defs10\x22 />\x0d\x0a \
 <sodipodi:named\
view\x0d\x0a     pagec\
olor=\x22#ffffff\x22\x0d\x0a\
     bordercolor\
=\x22#666666\x22\x0d\x0a    \
 borderopacity=\x22\
1\x22\x0d\x0a     objectt\
olerance=\x2210\x22\x0d\x0a \
    gridtoleranc\
e=\x2210\x22\x0d\x0a     gui\
detolerance=\x2210\x22\
\x0d\x0a     inkscape:\
pageopacity=\x220\x22\x0d\
\x0a     inkscape:p\
ageshadow=\x222\x22\x0d\x0a \
    inkscape:win\
dow-width=\x221863\x22\
\x0d\x0a     inkscape:\
window-height=\x221\
025\x22\x0d\x0a     id=\x22n\
amedview8\x22\x0d\x0a    \
 showgrid=\x22false\
\x22\x0d\x0a     inkscape\
:zoom=\x224.9166667\
\x22\x0d\x0a     inkscape\
:cx=\x22-48\x22\x0d\x0a     \
inkscape:cy=\x2224\x22\
\x0d\x0a     inkscape:\
window-x=\x2257\x22\x0d\x0a \
    inkscape:win\
dow-y=\x2227\x22\x0d\x0a    \
 inkscape:window\
-maximized=\x221\x22\x0d\x0a\
     inkscape:cu\
rrent-layer=\x22svg\
6\x22 />\x0d\x0a  <path\x0d\x0a\
     d=\x22M0 0h48v\
48h-48z\x22\x0d\x0a     i\
d=\x22path2\x22\x0d\x0a     \
fill=\x22none\x22 />\x0d\x0a\
  <path\x0d\x0a     st\
yle=\x22fill:#99999\
9;fill-rule:even\
odd;stroke:#9999\
99;stroke-width:\
2;stroke-linecap\
:butt;stroke-lin\
ejoin:round;stro\
ke-miterlimit:4;\
stroke-dasharray\
:none;stroke-opa\
city:1\x22\x0d\x0a     d=\
\x22m 14.339033,12.\
813563 -0.20339,\
22.372882 19.728\
814,-11.59322 z\x22\
\x0d\x0a     id=\x22path4\
489\x22\x0d\x0a     inksc\
ape:connector-cu\
rvature=\x220\x22 />\x0d\x0a\
</svg>\x0d\x0a\
\x00\x00\x07\x05\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<svg\x0d\x0a   \
xmlns:dc=\x22http:/\
/purl.org/dc/ele\
ments/1.1/\x22\x0d\x0a   \
xmlns:cc=\x22http:/\
/creativecommons\
.org/ns#\x22\x0d\x0a   xm\
lns:rdf=\x22http://\
www.w3.org/1999/\
02/22-rdf-syntax\
-ns#\x22\x0d\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0d\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0d\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0d\x0a   width=\x2248\x22\x0d\
\x0a   height=\x2248\x22\x0d\
\x0a   viewBox=\x220 0\
 48 48\x22\x0d\x0a   vers\
ion=\x221.1\x22\x0d\x0a   id\
=\x22svg4\x22\x0d\x0a   sodi\
podi:docname=\x22ic\
_content_paste_4\
8px.svg\x22\x0d\x0a   ink\
scape:version=\x220\
.92.3 (2405546, \
2018-03-11)\x22>\x0d\x0a \
 <metadata\x0d\x0a    \
 id=\x22metadata10\x22\
>\x0d\x0a    <rdf:RDF>\
\x0d\x0a      <cc:Work\
\x0d\x0a         rdf:a\
bout=\x22\x22>\x0d\x0a      \
  <dc:format>ima\
ge/svg+xml</dc:f\
ormat>\x0d\x0a        \
<dc:type\x0d\x0a      \
     rdf:resourc\
e=\x22http://purl.o\
rg/dc/dcmitype/S\
tillImage\x22 />\x0d\x0a \
     </cc:Work>\x0d\
\x0a    </rdf:RDF>\x0d\
\x0a  </metadata>\x0d\x0a\
  <defs\x0d\x0a     id\
=\x22defs8\x22 />\x0d\x0a  <\
sodipodi:namedvi\
ew\x0d\x0a     pagecol\
or=\x22#ffffff\x22\x0d\x0a  \
   bordercolor=\x22\
#666666\x22\x0d\x0a     b\
orderopacity=\x221\x22\
\x0d\x0a     objecttol\
erance=\x2210\x22\x0d\x0a   \
  gridtolerance=\
\x2210\x22\x0d\x0a     guide\
tolerance=\x2210\x22\x0d\x0a\
     inkscape:pa\
geopacity=\x220\x22\x0d\x0a \
    inkscape:pag\
eshadow=\x222\x22\x0d\x0a   \
  inkscape:windo\
w-width=\x221851\x22\x0d\x0a\
     inkscape:wi\
ndow-height=\x22102\
5\x22\x0d\x0a     id=\x22nam\
edview6\x22\x0d\x0a     s\
howgrid=\x22false\x22\x0d\
\x0a     inkscape:z\
oom=\x224.9166667\x22\x0d\
\x0a     inkscape:c\
x=\x2224\x22\x0d\x0a     ink\
scape:cy=\x2224\x22\x0d\x0a \
    inkscape:win\
dow-x=\x2269\x22\x0d\x0a    \
 inkscape:window\
-y=\x2227\x22\x0d\x0a     in\
kscape:window-ma\
ximized=\x221\x22\x0d\x0a   \
  inkscape:curre\
nt-layer=\x22svg4\x22 \
/>\x0d\x0a  <path\x0d\x0a   \
  d=\x22M38 4h-8.37\
c-.82-2.32-3.02-\
4-5.63-4s-4.81 1\
.68-5.63 4H10C7.\
79 4 6 5.79 6 8v\
32c0 2.21 1.79 4\
 4 4h28c2.21 0 4\
-1.79 4-4V8c0-2.\
21-1.79-4-4-4zM2\
4 4c1.1 0 2 .89 \
2 2s-.9 2-2 2-2-\
.89-2-2 .9-2 2-2\
zm14 36H10V8h4v6\
h20V8h4v32z\x22\x0d\x0a  \
   id=\x22path2\x22\x0d\x0a \
    style=\x22fill:\
#999999;fill-opa\
city:1\x22 />\x0d\x0a</sv\
g>\x0d\x0a\
\x00\x00\x07\xdd\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22s\
quares.svg\x22\x0d\x0a   \
inkscape:version\
=\x220.92.2 (5c3e80\
d, 2017-08-06)\x22>\
\x0d\x0a  <metadata\x0d\x0a \
    id=\x22metadata\
8\x22>\x0d\x0a    <rdf:RD\
F>\x0d\x0a      <cc:Wo\
rk\x0d\x0a         rdf\
:about=\x22\x22>\x0d\x0a    \
    <dc:format>i\
mage/svg+xml</dc\
:format>\x0d\x0a      \
  <dc:type\x0d\x0a    \
       rdf:resou\
rce=\x22http://purl\
.org/dc/dcmitype\
/StillImage\x22 />\x0d\
\x0a        <dc:tit\
le />\x0d\x0a      </c\
c:Work>\x0d\x0a    </r\
df:RDF>\x0d\x0a  </met\
adata>\x0d\x0a  <defs\x0d\
\x0a     id=\x22defs6\x22\
 />\x0d\x0a  <sodipodi\
:namedview\x0d\x0a    \
 pagecolor=\x22#fff\
fff\x22\x0d\x0a     borde\
rcolor=\x22#666666\x22\
\x0d\x0a     borderopa\
city=\x221\x22\x0d\x0a     o\
bjecttolerance=\x22\
10\x22\x0d\x0a     gridto\
lerance=\x2210\x22\x0d\x0a  \
   guidetoleranc\
e=\x2210\x22\x0d\x0a     ink\
scape:pageopacit\
y=\x220\x22\x0d\x0a     inks\
cape:pageshadow=\
\x222\x22\x0d\x0a     inksca\
pe:window-width=\
\x221863\x22\x0d\x0a     ink\
scape:window-hei\
ght=\x221025\x22\x0d\x0a    \
 id=\x22namedview4\x22\
\x0d\x0a     showgrid=\
\x22false\x22\x0d\x0a     in\
kscape:zoom=\x221.2\
291667\x22\x0d\x0a     in\
kscape:cx=\x22-47.9\
99997\x22\x0d\x0a     ink\
scape:cy=\x2296.000\
003\x22\x0d\x0a     inksc\
ape:window-x=\x2257\
\x22\x0d\x0a     inkscape\
:window-y=\x2227\x22\x0d\x0a\
     inkscape:wi\
ndow-maximized=\x22\
1\x22\x0d\x0a     inkscap\
e:current-layer=\
\x22svg2\x22 />\x0d\x0a  <pa\
th\x0d\x0a     style=\x22\
fill:#999999;str\
oke-width:1.3333\
3337\x22\x0d\x0a     d=\x22M\
 26.440678,96 V \
24 h 72.000004 7\
1.999998 v 72 72\
 H 98.440682 26.\
440678 Z m 64.00\
0004,32 v -24 h \
-24.000004 -24 v\
 24 24 h 24 24.0\
00004 z m 63.999\
998,0 v -24 h -2\
4 -24 v 24 24 h \
24 24 z M 90.440\
682,64 V 40 h -2\
4.000004 -24 v 2\
4 24 h 24 24.000\
004 z m 63.99999\
8,0 V 40 h -24 -\
24 v 24 24 h 24 \
24 z\x22\x0d\x0a     id=\x22\
path817\x22\x0d\x0a     i\
nkscape:connecto\
r-curvature=\x220\x22 \
/>\x0d\x0a</svg>\x0d\x0a\
\x00\x00\x0bM\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22c\
opy2up.svg\x22\x0d\x0a   \
inkscape:version\
=\x220.92.4 (unknow\
n)\x22>\x0d\x0a  <metadat\
a\x0d\x0a     id=\x22meta\
data8\x22>\x0d\x0a    <rd\
f:RDF>\x0d\x0a      <c\
c:Work\x0d\x0a        \
 rdf:about=\x22\x22>\x0d\x0a\
        <dc:form\
at>image/svg+xml\
</dc:format>\x0d\x0a  \
      <dc:type\x0d\x0a\
           rdf:r\
esource=\x22http://\
purl.org/dc/dcmi\
type/StillImage\x22\
 />\x0d\x0a        <dc\
:title />\x0d\x0a     \
 </cc:Work>\x0d\x0a   \
 </rdf:RDF>\x0d\x0a  <\
/metadata>\x0d\x0a  <d\
efs\x0d\x0a     id=\x22de\
fs6\x22 />\x0d\x0a  <sodi\
podi:namedview\x0d\x0a\
     pagecolor=\x22\
#ffffff\x22\x0d\x0a     b\
ordercolor=\x22#666\
666\x22\x0d\x0a     borde\
ropacity=\x221\x22\x0d\x0a  \
   objecttoleran\
ce=\x2210\x22\x0d\x0a     gr\
idtolerance=\x2210\x22\
\x0d\x0a     guidetole\
rance=\x2210\x22\x0d\x0a    \
 inkscape:pageop\
acity=\x220\x22\x0d\x0a     \
inkscape:pagesha\
dow=\x222\x22\x0d\x0a     in\
kscape:window-wi\
dth=\x221863\x22\x0d\x0a    \
 inkscape:window\
-height=\x221025\x22\x0d\x0a\
     id=\x22namedvi\
ew4\x22\x0d\x0a     showg\
rid=\x22false\x22\x0d\x0a   \
  inkscape:zoom=\
\x221.2291667\x22\x0d\x0a   \
  inkscape:cx=\x22-\
400.27119\x22\x0d\x0a    \
 inkscape:cy=\x2296\
.000012\x22\x0d\x0a     i\
nkscape:window-x\
=\x2257\x22\x0d\x0a     inks\
cape:window-y=\x222\
7\x22\x0d\x0a     inkscap\
e:window-maximiz\
ed=\x221\x22\x0d\x0a     ink\
scape:current-la\
yer=\x22g820\x22 />\x0d\x0a \
 <path\x0d\x0a     sty\
le=\x22fill:#999999\
;stroke-width:1.\
33333337\x22\x0d\x0a     \
d=\x22m 53.118644,1\
79.49816 c -1.46\
666,-0.62009 -4.\
16666,-2.7414 -6\
,-4.71401 l -3.3\
3333,-3.58656 V \
108.66398 46.130\
379 l 4.35897,-4\
.358975 4.35898,\
-4.358974 h 50.6\
15376 50.61539 l\
 4.35897,4.35897\
4 4.35897,4.3589\
75 v 62.615381 6\
2.61539 l -4.357\
58,4.35897 -4.35\
76,4.35897 -48.9\
7574,0.27327 c -\
26.936656,0.1502\
9 -50.175736,-0.\
23409 -51.642406\
,-0.8542 z m 93.\
999996,-70.7524 \
V 52.745763 h -4\
4 -43.999996 v 5\
5.999997 56 h 43\
.999996 44 z M 1\
1.412064,73.4370\
35 l 0.37325,-59\
.308728 4.35767,\
-4.3579395 4.357\
68,-4.3579381 51\
.30899,-0.378665\
2 51.308986,-0.3\
786654 v 8.04533\
22 8.045332 h -4\
7.999996 -48 v 5\
6 55.999997 h -8\
.03992 -8.03991 \
z\x22\x0d\x0a     id=\x22pat\
h817\x22\x0d\x0a     inks\
cape:connector-c\
urvature=\x220\x22 />\x0d\
\x0a  <g\x0d\x0a     id=\x22\
g820\x22\x0d\x0a     tran\
sform=\x22matrix(-4\
,0,0,-4,-202.169\
48,208.67797)\x22>\x0d\
\x0a    <path\x0d\x0a    \
   id=\x22path2\x22\x0d\x0a \
      d=\x22M 0,0 H\
 48 V 48 H 0 Z\x22\x0d\
\x0a       inkscape\
:connector-curva\
ture=\x220\x22\x0d\x0a      \
 style=\x22fill:non\
e\x22 />\x0d\x0a    <path\
\x0d\x0a       inkscap\
e:connector-curv\
ature=\x220\x22\x0d\x0a     \
  id=\x22path4489\x22\x0d\
\x0a       d=\x22m -82\
.714559,18.37008\
9 13.037829,-0.1\
18525 -6.755966,\
11.496992 z\x22\x0d\x0a  \
     style=\x22fill\
:#37c8ab;fill-ru\
le:evenodd;strok\
e:#37c8ab;stroke\
-width:1.1655027\
9;stroke-linecap\
:butt;stroke-lin\
ejoin:round;stro\
ke-miterlimit:4;\
stroke-dasharray\
:none;stroke-opa\
city:1\x22 />\x0d\x0a  </\
g>\x0d\x0a</svg>\x0d\x0a\
\x00\x00\x04V\
\x00\
\x00+\xa6x\xda\xedZ\xdbn\xe36\x10}_`\xff\
AU^\x12tE\x91\xd4\xc5\x92je\x816X`\
_\xdb-\xfa\xcc\x88\xb4\xad\x8d$\x1a\x14\x1d\xc7\xfb\xf5\
;\x94us\xe2\x14i\x03\x08\x01\x22\x01A\xcc3C\
rxf\xc8c\x0a^~~(\x0b\xeb^\xa8:\x97\
Uj\x13\x84mKT\x99\xe4y\xb5N\xed\xbf\xbf}\
q\x22\xdb\xaa5\xab8+d%R\xbb\x92\xf6\xe7\xeb\
\x8f\x1f\x96\xbf8\x8e\xf5\x87\x12L\x0bn\xeds\xbd\xb1\
\xbeVwu\xc6\xb6\xc2\xba\xdch\xbdM\x5cw\xbf\xdf\
\xa3\xbc\x05\x91Tk\xf7\xcar\x1c\xe8\x0a\x9d\xeb\xfb\xf5\
\xc7\x0f\x96e\xc1\xdcU\x9d\xf0,\xb5\xdb>\xdb\x9d*\
\x1a_\x9e\xb9\xa2\x10\xa5\xa8t\xed\x12D\x5c{\xe4\x9f\
\x0d\xfe\x99\x89 \xbf\x17\x99,KY\xd5M\xd7\xaa\xbe\
\x18{+\xbe\xea\xddMH{\xaf\xf1\x22q\x1c\xbb\x98\
\xba\x94:\xe0\xe1\xd4\x87J\xb3\x07\xe7Q_\x88\xf3\x5c\
_\x8a1v\xc16r}\xa1[R\x03\xb3[\xf8\xeb\
\xfd;\x00\xd5r\xa72\xb1\x82\x8e\x02UB\xbb7\xdf\
nz\xa3\x83\x11\xd7|<NG\xec\xc9\xbc'lW\
\xac\x14\xf5\x96e\xa2v;\xfc8\xc0(\xd9\xe4\x88\xe4\
<\xb5!Nzl\xeds\xae7`\x8d\xdb\xf6F\xe4\
\xeb\x8d\x1e\x01\xf7\xb9\xd8\xff.\x1fR\x1b[\xd8\x02\xd4\
\xea-]\xbc\x09\x97\x99\x99?\xb5\x99R\xec\x80z\x12\
\xbaH\x92>\x08\x8cb\x8a\x02\xeb\x92\xe2\x10\x8b\x8c\xac\
\xe2\xd5'\x8bb\x8a\x1d\xec;8\xba\xb2\xafM\xbfe\
)4\xe3L\xb3f\x90c\xc0\x1d\x14\x1d]\xc0\x09\xf2\
\x98\xfcy\xf3\xa5m\x02\x90e\xc9?R\xddumx\
\x8c\x0b\xbb\x95;X\x8e}=\xe0K\x9e%\xc0|\xc9\
\xf4u^\xb2\xb50Y\xfb\x15\x88^\xba\x83\xe1\xd4[\
\x1f\xb6b4\xeeqd%\x8eI<[\xce<+s\
\xd3\xcb\xfdK\xe7E\xf1\xd5Lc[\xee\xe3as]\
\x88\x11\xbat\xdb5tkt\xc7\x8b\x5c\xba\x1d\x09\xc7\
&\x17\xabz\xc4\x90i\x86\xdd\x1c\xcb>7&1\xdc\
\xe4\xb0u\xddB$\x99,\xa4J\xed\x8bU\xf3\xd8\xad\
\xe5V*.Tg\x0b\x9b\xe7\xd4&\xa1\xc0`UP\
\x1c\x1d.o\xbf\x8bLkY\x08\xc5*C\x05\xc1\x9d\
i\xad\xa0\xb2\xce\x1av9\x17g-}\xbd\x98 \xfb\
\xc9\xce\x9b\xeb\x0d\xe3r\x9f\xda\xf4\x89u\x9fW`q\
\xba\xc2\x8e\xfc\xe89\x97\xbe\xd61\x19|\x80\xca\x9e3\
\xbfC\xeb\x8d\xdc\x9b\x05\xa5\xf6\x8a\x15\xb5x2\xe0\x0f\
)K\x88\x05\xf9A\xe4\xc1\xf3\xc4\x9e\xc1\xfeq\x08E\
q\xec\x07\x1eyj\x86e\xc6!\xa2a\xe4\xf9\xe4\xb9\
ha\x88\xc5\xb3\xab\x85\x01h\xf0\x9c\xb1d\x0fy\x99\
\xff\x10|\x94\xb9a\xee\x9dRp\xf0:\x05;\x08\xd5\
\x9e\x0c]\x15\xadG\xa4\xacc\xaf\xcf\x84\x86\xd4\xd5f\
\xa7\xa4v\xf3\xb1\x00a\xb8$(&\x01\x0dH\xb7\x8d\
\xcd\x1e\x85\xe2\xe8K^\x1d\x9aC(\xc6a\xcf\x8fe\
\x19,Fa\xec\xc7\xc4\x1f\xd0\x87\x06%$\x0a\xfd\x91\
o\x97.\x8a\x07\xac\xcd\xf2\x182\xc1\x9a\x89#B\x07\
\xb0\xd6\x87\x02j\xad-\xaa\x84\xfc\xb6\x82m\x99\x5c\xc4\
\xcd\xd34\x9c\xc1Vk%\xefDR\x81\x04\xb6\x9f\x8f\
\xd5\x94xh\xb1\x88\x03\xba\x08\xc3\x0e/\xf2J\x00\x8d\
\x89\x92\xbb\x8a\x8f\xc1\xef2\xafNQ8\x10\x84* \
\x11:\xf1;\x8c3\xa8csh\x9eL6D\xb2e\
9\xa4\xa6\xd9|I\xc9\xd4\x1d\x9c\xa3\xd6\xd1\xc921\
\x0fG\xcak\xa8\x0e(\xa2\x86\xeb\xe85T;\xdeL\
\xf6K\xc8\x8e\x02\xe4\xe1\x00G\xfe\xeb\xc8v\xc2\x99\xee\
\x17\x1d#$B^\x1c\x0dg\xee\xff\xa4{1\xd3\xfd\
\x22\xba\x03\x82\x00\x0c\xbcW\xd2\x1d\xbc\x17\xba\x97\xee\xfa\
Tj\xff]Z?y\x1e\xf2\x82 \xf6\xbc+\xfb\x91\
6;\xf1\x9b\x91]g\x16\xde)\x85w\xa6{b\xe9\
u\xa2\x99\xf0I\xc5\x17\xce\xb6\x99\xf0)\xe5\xf7\xfd|\
\xdf\xf9\xaf\x02\x1c\x86h\xd1(\xe4S\x01\xf6\xde\x8e\x00\
\xcf\xb7\x83I\x05\x98\xcctO+\xc0\xf37\x9e\xa9\x05\
x~\xbd3\xb1\x02\x93Y\x81\xcf+0\xc1\x18\xe1p\
\x11\x9d\xb9\x01\xfboG\x81\xe7\x17F\x93*\xf0|#\
\x9bX\x81\xfd\x99\xf0i\x158\x98\x09\x9fV\x80\xf1,\
\xc0\xcf\x08\xb0\xe7!\x9fz\x8b3\xef\xa0\xbd\xf0\xed(\
\xf0|)\x9bT\x81\xf1L\xf7\xb4\x0a<\xbf\xe3\x99X\
\x81\xe7+\xf0\xc4\x0aL\xdf\x97\x02/\xcd\x0f\x11\xe1\xff\
O\x84\x93\xbf\xc0\
\x00\x00\x0bd\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22c\
opy2left.svg\x22\x0d\x0a \
  inkscape:versi\
on=\x220.92.3 (2405\
546, 2018-03-11)\
\x22>\x0d\x0a  <metadata\x0d\
\x0a     id=\x22metada\
ta8\x22>\x0d\x0a    <rdf:\
RDF>\x0d\x0a      <cc:\
Work\x0d\x0a         r\
df:about=\x22\x22>\x0d\x0a  \
      <dc:format\
>image/svg+xml</\
dc:format>\x0d\x0a    \
    <dc:type\x0d\x0a  \
         rdf:res\
ource=\x22http://pu\
rl.org/dc/dcmity\
pe/StillImage\x22 /\
>\x0d\x0a        <dc:t\
itle></dc:title>\
\x0d\x0a      </cc:Wor\
k>\x0d\x0a    </rdf:RD\
F>\x0d\x0a  </metadata\
>\x0d\x0a  <defs\x0d\x0a    \
 id=\x22defs6\x22 />\x0d\x0a\
  <sodipodi:name\
dview\x0d\x0a     page\
color=\x22#ffffff\x22\x0d\
\x0a     bordercolo\
r=\x22#666666\x22\x0d\x0a   \
  borderopacity=\
\x221\x22\x0d\x0a     object\
tolerance=\x2210\x22\x0d\x0a\
     gridtoleran\
ce=\x2210\x22\x0d\x0a     gu\
idetolerance=\x2210\
\x22\x0d\x0a     inkscape\
:pageopacity=\x220\x22\
\x0d\x0a     inkscape:\
pageshadow=\x222\x22\x0d\x0a\
     inkscape:wi\
ndow-width=\x221851\
\x22\x0d\x0a     inkscape\
:window-height=\x22\
1025\x22\x0d\x0a     id=\x22\
namedview4\x22\x0d\x0a   \
  showgrid=\x22fals\
e\x22\x0d\x0a     inkscap\
e:zoom=\x221.229166\
7\x22\x0d\x0a     inkscap\
e:cx=\x22-123.45297\
\x22\x0d\x0a     inkscape\
:cy=\x2296.000006\x22\x0d\
\x0a     inkscape:w\
indow-x=\x2269\x22\x0d\x0a  \
   inkscape:wind\
ow-y=\x2227\x22\x0d\x0a     \
inkscape:window-\
maximized=\x221\x22\x0d\x0a \
    inkscape:cur\
rent-layer=\x22g820\
\x22 />\x0d\x0a  <path\x0d\x0a \
    style=\x22fill:\
#999999;stroke-w\
idth:1.33333337\x22\
\x0d\x0a     d=\x22m 53.1\
18644,179.49816 \
c -1.46666,-0.62\
009 -4.16666,-2.\
7414 -6,-4.71401\
 l -3.33333,-3.5\
8656 V 108.66398\
 46.130379 l 4.3\
5897,-4.358975 4\
.35898,-4.358974\
 h 50.615376 50.\
61539 l 4.35897,\
4.358974 4.35897\
,4.358975 v 62.6\
15381 62.61539 l\
 -4.35758,4.3589\
7 -4.3576,4.3589\
7 -48.97574,0.27\
327 c -26.936656\
,0.15029 -50.175\
736,-0.23409 -51\
.642406,-0.8542 \
z m 93.999996,-7\
0.7524 V 52.7457\
63 h -44 -43.999\
996 v 55.999997 \
56 h 43.999996 4\
4 z M 11.412064,\
73.437035 l 0.37\
325,-59.308728 4\
.35767,-4.357939\
5 4.35768,-4.357\
9381 51.30899,-0\
.3786652 51.3089\
86,-0.3786654 v \
8.0453322 8.0453\
32 h -47.999996 \
-48 v 56 55.9999\
97 h -8.03992 -8\
.03991 z\x22\x0d\x0a     \
id=\x22path817\x22\x0d\x0a  \
   inkscape:conn\
ector-curvature=\
\x220\x22 />\x0d\x0a  <g\x0d\x0a  \
   id=\x22g820\x22\x0d\x0a  \
   transform=\x22ma\
trix(-4,0,0,-4,-\
202.16948,208.67\
797)\x22>\x0d\x0a    <pat\
h\x0d\x0a       id=\x22pa\
th2\x22\x0d\x0a       d=\x22\
M 0,0 H 48 V 48 \
H 0 Z\x22\x0d\x0a       i\
nkscape:connecto\
r-curvature=\x220\x22\x0d\
\x0a       style=\x22f\
ill:none\x22 />\x0d\x0a  \
  <path\x0d\x0a       \
inkscape:connect\
or-curvature=\x220\x22\
\x0d\x0a       id=\x22pat\
h4489\x22\x0d\x0a       d\
=\x22m -80.825616,1\
7.481088 -0.1185\
25,13.037828 11.\
496993,-6.755965\
 z\x22\x0d\x0a       styl\
e=\x22fill:#37c8ab;\
fill-rule:evenod\
d;stroke:#37c8ab\
;stroke-width:1.\
16550279;stroke-\
linecap:butt;str\
oke-linejoin:rou\
nd;stroke-miterl\
imit:4;stroke-da\
sharray:none;str\
oke-opacity:1\x22 /\
>\x0d\x0a  </g>\x0d\x0a</svg\
>\x0d\x0a\
\x00\x00\x08\x17\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22s\
avec.svg\x22\x0d\x0a   in\
kscape:version=\x22\
0.92.4 (unknown)\
\x22>\x0d\x0a  <metadata\x0d\
\x0a     id=\x22metada\
ta8\x22>\x0d\x0a    <rdf:\
RDF>\x0d\x0a      <cc:\
Work\x0d\x0a         r\
df:about=\x22\x22>\x0d\x0a  \
      <dc:format\
>image/svg+xml</\
dc:format>\x0d\x0a    \
    <dc:type\x0d\x0a  \
         rdf:res\
ource=\x22http://pu\
rl.org/dc/dcmity\
pe/StillImage\x22 /\
>\x0d\x0a        <dc:t\
itle />\x0d\x0a      <\
/cc:Work>\x0d\x0a    <\
/rdf:RDF>\x0d\x0a  </m\
etadata>\x0d\x0a  <def\
s\x0d\x0a     id=\x22defs\
6\x22 />\x0d\x0a  <sodipo\
di:namedview\x0d\x0a  \
   pagecolor=\x22#f\
fffff\x22\x0d\x0a     bor\
dercolor=\x22#66666\
6\x22\x0d\x0a     bordero\
pacity=\x221\x22\x0d\x0a    \
 objecttolerance\
=\x2210\x22\x0d\x0a     grid\
tolerance=\x2210\x22\x0d\x0a\
     guidetolera\
nce=\x2210\x22\x0d\x0a     i\
nkscape:pageopac\
ity=\x220\x22\x0d\x0a     in\
kscape:pageshado\
w=\x222\x22\x0d\x0a     inks\
cape:window-widt\
h=\x221863\x22\x0d\x0a     i\
nkscape:window-h\
eight=\x221025\x22\x0d\x0a  \
   id=\x22namedview\
4\x22\x0d\x0a     showgri\
d=\x22false\x22\x0d\x0a     \
inkscape:zoom=\x221\
.1020922\x22\x0d\x0a     \
inkscape:cx=\x22-11\
2.84034\x22\x0d\x0a     i\
nkscape:cy=\x22120.\
23219\x22\x0d\x0a     ink\
scape:window-x=\x22\
57\x22\x0d\x0a     inksca\
pe:window-y=\x2227\x22\
\x0d\x0a     inkscape:\
window-maximized\
=\x221\x22\x0d\x0a     inksc\
ape:current-laye\
r=\x22svg2\x22 />\x0d\x0a  <\
path\x0d\x0a     style\
=\x22fill:#5555ff;s\
troke-width:4;st\
roke:none;stroke\
-opacity:1;strok\
e-miterlimit:4;s\
troke-dasharray:\
none\x22\x0d\x0a     d=\x22m\
 37.559322,153.6\
2712 v -8 h 56 5\
5.999998 v 8 8 h\
 -55.999998 -56 \
z m 28,-52.66667\
 -27.30894,-27.3\
33331 h 15.65447\
1 15.654469 v -2\
4 -24 h 24 23.99\
9998 v 24 24 h 1\
5.65447 15.65446\
 l -27.30893,27.\
333331 c -15.019\
92,15.03334 -27.\
619918,27.33334 \
-27.999998,27.33\
334 -0.38008,0 -\
12.98008,-12.3 -\
28,-27.33334 z\x22\x0d\
\x0a     id=\x22path81\
7\x22\x0d\x0a     inkscap\
e:connector-curv\
ature=\x220\x22 />\x0d\x0a</\
svg>\x0d\x0a\
\x00\x00\x07\xd4\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22m\
inus (gray).svg\x22\
\x0d\x0a   inkscape:ve\
rsion=\x220.92.4 (u\
nknown)\x22>\x0d\x0a  <me\
tadata\x0d\x0a     id=\
\x22metadata8\x22>\x0d\x0a  \
  <rdf:RDF>\x0d\x0a   \
   <cc:Work\x0d\x0a   \
      rdf:about=\
\x22\x22>\x0d\x0a        <dc\
:format>image/sv\
g+xml</dc:format\
>\x0d\x0a        <dc:t\
ype\x0d\x0a           \
rdf:resource=\x22ht\
tp://purl.org/dc\
/dcmitype/StillI\
mage\x22 />\x0d\x0a      \
  <dc:title />\x0d\x0a\
      </cc:Work>\
\x0d\x0a    </rdf:RDF>\
\x0d\x0a  </metadata>\x0d\
\x0a  <defs\x0d\x0a     i\
d=\x22defs6\x22 />\x0d\x0a  \
<sodipodi:namedv\
iew\x0d\x0a     pageco\
lor=\x22#ffffff\x22\x0d\x0a \
    bordercolor=\
\x22#666666\x22\x0d\x0a     \
borderopacity=\x221\
\x22\x0d\x0a     objectto\
lerance=\x2210\x22\x0d\x0a  \
   gridtolerance\
=\x2210\x22\x0d\x0a     guid\
etolerance=\x2210\x22\x0d\
\x0a     inkscape:p\
ageopacity=\x220\x22\x0d\x0a\
     inkscape:pa\
geshadow=\x222\x22\x0d\x0a  \
   inkscape:wind\
ow-width=\x221863\x22\x0d\
\x0a     inkscape:w\
indow-height=\x2210\
25\x22\x0d\x0a     id=\x22na\
medview4\x22\x0d\x0a     \
showgrid=\x22false\x22\
\x0d\x0a     inkscape:\
zoom=\x221.7383042\x22\
\x0d\x0a     inkscape:\
cx=\x22-319.39807\x22\x0d\
\x0a     inkscape:c\
y=\x22209.44504\x22\x0d\x0a \
    inkscape:win\
dow-x=\x2257\x22\x0d\x0a    \
 inkscape:window\
-y=\x2227\x22\x0d\x0a     in\
kscape:window-ma\
ximized=\x221\x22\x0d\x0a   \
  inkscape:curre\
nt-layer=\x22g831\x22 \
/>\x0d\x0a  <g\x0d\x0a     i\
d=\x22g831\x22\x0d\x0a     s\
tyle=\x22stroke:#b3\
b3b3;stroke-line\
cap:round\x22>\x0d\x0a   \
 <path\x0d\x0a       s\
odipodi:nodetype\
s=\x22cc\x22\x0d\x0a       i\
nkscape:connecto\
r-curvature=\x220\x22\x0d\
\x0a       id=\x22path\
812-3\x22\x0d\x0a       d\
=\x22m 134.96147,95\
.594487 -79.7951\
08,0.0945\x22\x0d\x0a    \
   style=\x22fill:#\
37c8ab;fill-rule\
:evenodd;stroke:\
#aeaeae;stroke-w\
idth:16;stroke-l\
inecap:round;str\
oke-linejoin:mit\
er;stroke-miterl\
imit:4;stroke-da\
sharray:none;str\
oke-opacity:1\x22 /\
>\x0d\x0a  </g>\x0d\x0a</svg\
>\x0d\x0a\
\x00\x00\x07\xb9\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22l\
oad.svg\x22\x0d\x0a   ink\
scape:version=\x220\
.92.2 (5c3e80d, \
2017-08-06)\x22>\x0d\x0a \
 <metadata\x0d\x0a    \
 id=\x22metadata8\x22>\
\x0d\x0a    <rdf:RDF>\x0d\
\x0a      <cc:Work\x0d\
\x0a         rdf:ab\
out=\x22\x22>\x0d\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0d\x0a        <\
dc:type\x0d\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 />\x0d\x0a  \
      <dc:title \
/>\x0d\x0a      </cc:W\
ork>\x0d\x0a    </rdf:\
RDF>\x0d\x0a  </metada\
ta>\x0d\x0a  <defs\x0d\x0a  \
   id=\x22defs6\x22 />\
\x0d\x0a  <sodipodi:na\
medview\x0d\x0a     pa\
gecolor=\x22#ffffff\
\x22\x0d\x0a     borderco\
lor=\x22#666666\x22\x0d\x0a \
    borderopacit\
y=\x221\x22\x0d\x0a     obje\
cttolerance=\x2210\x22\
\x0d\x0a     gridtoler\
ance=\x2210\x22\x0d\x0a     \
guidetolerance=\x22\
10\x22\x0d\x0a     inksca\
pe:pageopacity=\x22\
0\x22\x0d\x0a     inkscap\
e:pageshadow=\x222\x22\
\x0d\x0a     inkscape:\
window-width=\x2278\
4\x22\x0d\x0a     inkscap\
e:window-height=\
\x22480\x22\x0d\x0a     id=\x22\
namedview4\x22\x0d\x0a   \
  showgrid=\x22fals\
e\x22\x0d\x0a     inkscap\
e:zoom=\x221.229166\
7\x22\x0d\x0a     inkscap\
e:cx=\x22-47.999997\
\x22\x0d\x0a     inkscape\
:cy=\x2296.000003\x22\x0d\
\x0a     inkscape:w\
indow-x=\x2257\x22\x0d\x0a  \
   inkscape:wind\
ow-y=\x2227\x22\x0d\x0a     \
inkscape:window-\
maximized=\x220\x22\x0d\x0a \
    inkscape:cur\
rent-layer=\x22svg2\
\x22 />\x0d\x0a  <path\x0d\x0a \
    style=\x22fill:\
#999999;stroke-w\
idth:1.33333337\x22\
\x0d\x0a     d=\x22m 37.5\
59322,154.44068 \
v -8 h 56.000004\
 56.000004 v 8 8\
 H 93.559326 37.\
559322 Z m 32,-4\
8 V 82.440678 H \
53.896671 38.234\
021 l 27.66265,-\
27.662651 27.662\
655,-27.66265 27\
.662654,27.66265\
 27.66266,27.662\
651 h -15.66266 \
-15.66265 v 24.0\
00002 24 H 93.55\
9326 69.559322 Z\
\x22\x0d\x0a     id=\x22path\
817\x22\x0d\x0a     inksc\
ape:connector-cu\
rvature=\x220\x22 />\x0d\x0a\
</svg>\x0d\x0a\
\x00\x00\x06s\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<svg\x0d\x0a   \
xmlns:dc=\x22http:/\
/purl.org/dc/ele\
ments/1.1/\x22\x0d\x0a   \
xmlns:cc=\x22http:/\
/creativecommons\
.org/ns#\x22\x0d\x0a   xm\
lns:rdf=\x22http://\
www.w3.org/1999/\
02/22-rdf-syntax\
-ns#\x22\x0d\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0d\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0d\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0d\x0a   width=\x2248\x22\x0d\
\x0a   height=\x2248\x22\x0d\
\x0a   viewBox=\x220 0\
 48 48\x22\x0d\x0a   vers\
ion=\x221.1\x22\x0d\x0a   id\
=\x22svg4\x22\x0d\x0a   sodi\
podi:docname=\x22ic\
_view_headline_4\
8px.svg\x22\x0d\x0a   ink\
scape:version=\x220\
.92.3 (2405546, \
2018-03-11)\x22>\x0d\x0a \
 <metadata\x0d\x0a    \
 id=\x22metadata10\x22\
>\x0d\x0a    <rdf:RDF>\
\x0d\x0a      <cc:Work\
\x0d\x0a         rdf:a\
bout=\x22\x22>\x0d\x0a      \
  <dc:format>ima\
ge/svg+xml</dc:f\
ormat>\x0d\x0a        \
<dc:type\x0d\x0a      \
     rdf:resourc\
e=\x22http://purl.o\
rg/dc/dcmitype/S\
tillImage\x22 />\x0d\x0a \
     </cc:Work>\x0d\
\x0a    </rdf:RDF>\x0d\
\x0a  </metadata>\x0d\x0a\
  <defs\x0d\x0a     id\
=\x22defs8\x22 />\x0d\x0a  <\
sodipodi:namedvi\
ew\x0d\x0a     pagecol\
or=\x22#ffffff\x22\x0d\x0a  \
   bordercolor=\x22\
#666666\x22\x0d\x0a     b\
orderopacity=\x221\x22\
\x0d\x0a     objecttol\
erance=\x2210\x22\x0d\x0a   \
  gridtolerance=\
\x2210\x22\x0d\x0a     guide\
tolerance=\x2210\x22\x0d\x0a\
     inkscape:pa\
geopacity=\x220\x22\x0d\x0a \
    inkscape:pag\
eshadow=\x222\x22\x0d\x0a   \
  inkscape:windo\
w-width=\x22826\x22\x0d\x0a \
    inkscape:win\
dow-height=\x22480\x22\
\x0d\x0a     id=\x22named\
view6\x22\x0d\x0a     sho\
wgrid=\x22false\x22\x0d\x0a \
    inkscape:zoo\
m=\x224.9166667\x22\x0d\x0a \
    inkscape:cx=\
\x222.6440678\x22\x0d\x0a   \
  inkscape:cy=\x222\
4\x22\x0d\x0a     inkscap\
e:window-x=\x2269\x22\x0d\
\x0a     inkscape:w\
indow-y=\x2227\x22\x0d\x0a  \
   inkscape:wind\
ow-maximized=\x220\x22\
\x0d\x0a     inkscape:\
current-layer=\x22s\
vg4\x22 />\x0d\x0a  <path\
\x0d\x0a     d=\x22M8 30h\
34v-4H8v4zm0 8h3\
4v-4H8v4zm0-16h3\
4v-4H8v4zm0-12v4\
h34v-4H8z\x22\x0d\x0a    \
 id=\x22path2\x22\x0d\x0a   \
  style=\x22fill:#9\
99999;fill-opaci\
ty:1\x22 />\x0d\x0a</svg>\
\x0d\x0a\
\x00\x00\x07\xcd\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22m\
inus.svg\x22\x0d\x0a   in\
kscape:version=\x22\
0.92.4 (unknown)\
\x22>\x0d\x0a  <metadata\x0d\
\x0a     id=\x22metada\
ta8\x22>\x0d\x0a    <rdf:\
RDF>\x0d\x0a      <cc:\
Work\x0d\x0a         r\
df:about=\x22\x22>\x0d\x0a  \
      <dc:format\
>image/svg+xml</\
dc:format>\x0d\x0a    \
    <dc:type\x0d\x0a  \
         rdf:res\
ource=\x22http://pu\
rl.org/dc/dcmity\
pe/StillImage\x22 /\
>\x0d\x0a        <dc:t\
itle />\x0d\x0a      <\
/cc:Work>\x0d\x0a    <\
/rdf:RDF>\x0d\x0a  </m\
etadata>\x0d\x0a  <def\
s\x0d\x0a     id=\x22defs\
6\x22 />\x0d\x0a  <sodipo\
di:namedview\x0d\x0a  \
   pagecolor=\x22#f\
fffff\x22\x0d\x0a     bor\
dercolor=\x22#66666\
6\x22\x0d\x0a     bordero\
pacity=\x221\x22\x0d\x0a    \
 objecttolerance\
=\x2210\x22\x0d\x0a     grid\
tolerance=\x2210\x22\x0d\x0a\
     guidetolera\
nce=\x2210\x22\x0d\x0a     i\
nkscape:pageopac\
ity=\x220\x22\x0d\x0a     in\
kscape:pageshado\
w=\x222\x22\x0d\x0a     inks\
cape:window-widt\
h=\x221863\x22\x0d\x0a     i\
nkscape:window-h\
eight=\x221025\x22\x0d\x0a  \
   id=\x22namedview\
4\x22\x0d\x0a     showgri\
d=\x22false\x22\x0d\x0a     \
inkscape:zoom=\x221\
.7383042\x22\x0d\x0a     \
inkscape:cx=\x22-21\
3.83542\x22\x0d\x0a     i\
nkscape:cy=\x22209.\
44504\x22\x0d\x0a     ink\
scape:window-x=\x22\
57\x22\x0d\x0a     inksca\
pe:window-y=\x2227\x22\
\x0d\x0a     inkscape:\
window-maximized\
=\x221\x22\x0d\x0a     inksc\
ape:current-laye\
r=\x22g831\x22 />\x0d\x0a  <\
g\x0d\x0a     id=\x22g831\
\x22\x0d\x0a     style=\x22s\
troke:#b3b3b3;st\
roke-linecap:rou\
nd\x22>\x0d\x0a    <path\x0d\
\x0a       sodipodi\
:nodetypes=\x22cc\x22\x0d\
\x0a       inkscape\
:connector-curva\
ture=\x220\x22\x0d\x0a      \
 id=\x22path812-3\x22\x0d\
\x0a       d=\x22m 134\
.96147,95.594487\
 -79.795108,0.09\
45\x22\x0d\x0a       styl\
e=\x22fill:#37c8ab;\
fill-rule:evenod\
d;stroke:#37c8ab\
;stroke-width:16\
;stroke-linecap:\
round;stroke-lin\
ejoin:miter;stro\
ke-miterlimit:4;\
stroke-dasharray\
:none;stroke-opa\
city:1\x22 />\x0d\x0a  </\
g>\x0d\x0a</svg>\x0d\x0a\
\x00\x00\x06\xfd\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<svg\x0d\x0a   \
xmlns:dc=\x22http:/\
/purl.org/dc/ele\
ments/1.1/\x22\x0d\x0a   \
xmlns:cc=\x22http:/\
/creativecommons\
.org/ns#\x22\x0d\x0a   xm\
lns:rdf=\x22http://\
www.w3.org/1999/\
02/22-rdf-syntax\
-ns#\x22\x0d\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0d\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0d\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0d\x0a   width=\x2248\x22\x0d\
\x0a   height=\x2248\x22\x0d\
\x0a   viewBox=\x220 0\
 48 48\x22\x0d\x0a   vers\
ion=\x221.1\x22\x0d\x0a   id\
=\x22svg4\x22\x0d\x0a   sodi\
podi:docname=\x22un\
check_all.svg\x22\x0d\x0a\
   inkscape:vers\
ion=\x220.92.3 (240\
5546, 2018-03-11\
)\x22>\x0d\x0a  <metadata\
\x0d\x0a     id=\x22metad\
ata10\x22>\x0d\x0a    <rd\
f:RDF>\x0d\x0a      <c\
c:Work\x0d\x0a        \
 rdf:about=\x22\x22>\x0d\x0a\
        <dc:form\
at>image/svg+xml\
</dc:format>\x0d\x0a  \
      <dc:type\x0d\x0a\
           rdf:r\
esource=\x22http://\
purl.org/dc/dcmi\
type/StillImage\x22\
 />\x0d\x0a        <dc\
:title />\x0d\x0a     \
 </cc:Work>\x0d\x0a   \
 </rdf:RDF>\x0d\x0a  <\
/metadata>\x0d\x0a  <d\
efs\x0d\x0a     id=\x22de\
fs8\x22 />\x0d\x0a  <sodi\
podi:namedview\x0d\x0a\
     pagecolor=\x22\
#ffffff\x22\x0d\x0a     b\
ordercolor=\x22#666\
666\x22\x0d\x0a     borde\
ropacity=\x221\x22\x0d\x0a  \
   objecttoleran\
ce=\x2210\x22\x0d\x0a     gr\
idtolerance=\x2210\x22\
\x0d\x0a     guidetole\
rance=\x2210\x22\x0d\x0a    \
 inkscape:pageop\
acity=\x220\x22\x0d\x0a     \
inkscape:pagesha\
dow=\x222\x22\x0d\x0a     in\
kscape:window-wi\
dth=\x221851\x22\x0d\x0a    \
 inkscape:window\
-height=\x221025\x22\x0d\x0a\
     id=\x22namedvi\
ew6\x22\x0d\x0a     showg\
rid=\x22false\x22\x0d\x0a   \
  inkscape:zoom=\
\x224.9166667\x22\x0d\x0a   \
  inkscape:cx=\x22-\
82.372882\x22\x0d\x0a    \
 inkscape:cy=\x2224\
\x22\x0d\x0a     inkscape\
:window-x=\x2269\x22\x0d\x0a\
     inkscape:wi\
ndow-y=\x2227\x22\x0d\x0a   \
  inkscape:windo\
w-maximized=\x221\x22\x0d\
\x0a     inkscape:c\
urrent-layer=\x22sv\
g4\x22 />\x0d\x0a  <rect\x0d\
\x0a     style=\x22opa\
city:0.328;fill:\
none;stroke:#000\
000;stroke-width\
:3;stroke-miterl\
imit:4;stroke-da\
sharray:none;str\
oke-opacity:1\x22\x0d\x0a\
     id=\x22rect818\
\x22\x0d\x0a     width=\x223\
8.033897\x22\x0d\x0a     \
height=\x2239.25423\
8\x22\x0d\x0a     x=\x225.08\
47454\x22\x0d\x0a     y=\x22\
4.6779661\x22\x0d\x0a    \
 ry=\x225.8983049\x22 \
/>\x0d\x0a</svg>\x0d\x0a\
\x00\x00\x07\xa8\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<svg\x0d\x0a   \
xmlns:dc=\x22http:/\
/purl.org/dc/ele\
ments/1.1/\x22\x0d\x0a   \
xmlns:cc=\x22http:/\
/creativecommons\
.org/ns#\x22\x0d\x0a   xm\
lns:rdf=\x22http://\
www.w3.org/1999/\
02/22-rdf-syntax\
-ns#\x22\x0d\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0d\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0d\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0d\x0a   width=\x2248\x22\x0d\
\x0a   height=\x2248\x22\x0d\
\x0a   viewBox=\x220 0\
 48 48\x22\x0d\x0a   vers\
ion=\x221.1\x22\x0d\x0a   id\
=\x22svg4\x22\x0d\x0a   sodi\
podi:docname=\x22ic\
_system_update_a\
lt_48px.svg\x22\x0d\x0a  \
 inkscape:versio\
n=\x220.92.3 (24055\
46, 2018-03-11)\x22\
>\x0d\x0a  <metadata\x0d\x0a\
     id=\x22metadat\
a10\x22>\x0d\x0a    <rdf:\
RDF>\x0d\x0a      <cc:\
Work\x0d\x0a         r\
df:about=\x22\x22>\x0d\x0a  \
      <dc:format\
>image/svg+xml</\
dc:format>\x0d\x0a    \
    <dc:type\x0d\x0a  \
         rdf:res\
ource=\x22http://pu\
rl.org/dc/dcmity\
pe/StillImage\x22 /\
>\x0d\x0a      </cc:Wo\
rk>\x0d\x0a    </rdf:R\
DF>\x0d\x0a  </metadat\
a>\x0d\x0a  <defs\x0d\x0a   \
  id=\x22defs8\x22 />\x0d\
\x0a  <sodipodi:nam\
edview\x0d\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0d\x0a     bordercol\
or=\x22#666666\x22\x0d\x0a  \
   borderopacity\
=\x221\x22\x0d\x0a     objec\
ttolerance=\x2210\x22\x0d\
\x0a     gridtolera\
nce=\x2210\x22\x0d\x0a     g\
uidetolerance=\x221\
0\x22\x0d\x0a     inkscap\
e:pageopacity=\x220\
\x22\x0d\x0a     inkscape\
:pageshadow=\x222\x22\x0d\
\x0a     inkscape:w\
indow-width=\x22185\
1\x22\x0d\x0a     inkscap\
e:window-height=\
\x221025\x22\x0d\x0a     id=\
\x22namedview6\x22\x0d\x0a  \
   showgrid=\x22fal\
se\x22\x0d\x0a     inksca\
pe:zoom=\x222.45833\
33\x22\x0d\x0a     inksca\
pe:cx=\x22-50.29297\
8\x22\x0d\x0a     inkscap\
e:cy=\x2274.807176\x22\
\x0d\x0a     inkscape:\
window-x=\x2269\x22\x0d\x0a \
    inkscape:win\
dow-y=\x2227\x22\x0d\x0a    \
 inkscape:window\
-maximized=\x221\x22\x0d\x0a\
     inkscape:cu\
rrent-layer=\x22svg\
4\x22 />\x0d\x0a  <path\x0d\x0a\
     style=\x22stro\
ke:#37c8ab;strok\
e-opacity:1;fill\
:#37c8ab;fill-op\
acity:1\x22\x0d\x0a     d\
=\x22m 24,32.5 8,-8\
 h -6 v -18 h -4\
 v 18 h -6 z\x22\x0d\x0a \
    id=\x22path819\x22\
 />\x0d\x0a  <path\x0d\x0a  \
   style=\x22stroke\
:#999999;stroke-\
opacity:1;fill:#\
999999;fill-opac\
ity:1\x22\x0d\x0a     d=\x22\
M 42,6.5 H 30 v \
3.97 H 42 V 38.5\
3 H 6 V 10.47 H \
18 V 6.5 H 6 c -\
2.21,0 -4,1.79 -\
4,4 v 28 c 0,2.2\
1 1.79,4 4,4 h 3\
6 c 2.21,0 4,-1.\
79 4,-4 v -28 c \
0,-2.21 -1.79,-4\
 -4,-4 z\x22\x0d\x0a     \
id=\x22path2\x22 />\x0d\x0a<\
/svg>\x0d\x0a\
\x00\x00\x09*\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  width=\x2248\x22\x0d\x0a  \
 height=\x2248\x22\x0d\x0a  \
 viewBox=\x220 0 48\
.000001 48.00000\
1\x22\x0d\x0a   id=\x22svg2\x22\
\x0d\x0a   version=\x221.\
1\x22\x0d\x0a   inkscape:\
version=\x220.92.2 \
(5c3e80d, 2017-0\
8-06)\x22\x0d\x0a   sodip\
odi:docname=\x22con\
sole.svg\x22>\x0d\x0a  <d\
efs\x0d\x0a     id=\x22de\
fs4\x22 />\x0d\x0a  <sodi\
podi:namedview\x0d\x0a\
     id=\x22base\x22\x0d\x0a\
     pagecolor=\x22\
#ffffff\x22\x0d\x0a     b\
ordercolor=\x22#666\
666\x22\x0d\x0a     borde\
ropacity=\x221.0\x22\x0d\x0a\
     inkscape:pa\
geopacity=\x220.0\x22\x0d\
\x0a     inkscape:p\
ageshadow=\x222\x22\x0d\x0a \
    inkscape:zoo\
m=\x227.9195959\x22\x0d\x0a \
    inkscape:cx=\
\x221.2311698\x22\x0d\x0a   \
  inkscape:cy=\x223\
1.52398\x22\x0d\x0a     i\
nkscape:document\
-units=\x22px\x22\x0d\x0a   \
  inkscape:curre\
nt-layer=\x22layer1\
\x22\x0d\x0a     showgrid\
=\x22false\x22\x0d\x0a     u\
nits=\x22px\x22\x0d\x0a     \
inkscape:window-\
width=\x221863\x22\x0d\x0a  \
   inkscape:wind\
ow-height=\x221025\x22\
\x0d\x0a     inkscape:\
window-x=\x2257\x22\x0d\x0a \
    inkscape:win\
dow-y=\x2227\x22\x0d\x0a    \
 inkscape:window\
-maximized=\x221\x22 /\
>\x0d\x0a  <metadata\x0d\x0a\
     id=\x22metadat\
a7\x22>\x0d\x0a    <rdf:R\
DF>\x0d\x0a      <cc:W\
ork\x0d\x0a         rd\
f:about=\x22\x22>\x0d\x0a   \
     <dc:format>\
image/svg+xml</d\
c:format>\x0d\x0a     \
   <dc:type\x0d\x0a   \
        rdf:reso\
urce=\x22http://pur\
l.org/dc/dcmityp\
e/StillImage\x22 />\
\x0d\x0a        <dc:ti\
tle />\x0d\x0a      </\
cc:Work>\x0d\x0a    </\
rdf:RDF>\x0d\x0a  </me\
tadata>\x0d\x0a  <g\x0d\x0a \
    inkscape:lab\
el=\x22Capa 1\x22\x0d\x0a   \
  inkscape:group\
mode=\x22layer\x22\x0d\x0a  \
   id=\x22layer1\x22\x0d\x0a\
     transform=\x22\
translate(0,-100\
4.3622)\x22>\x0d\x0a    <\
rect\x0d\x0a       sty\
le=\x22fill:none;fi\
ll-opacity:0.849\
51453;stroke:#99\
9999;stroke-widt\
h:3.85741425;str\
oke-linejoin:rou\
nd;stroke-miterl\
imit:4;stroke-da\
sharray:none\x22\x0d\x0a \
      id=\x22rect41\
36\x22\x0d\x0a       widt\
h=\x2244.142586\x22\x0d\x0a \
      height=\x2244\
.142586\x22\x0d\x0a      \
 x=\x221.9287071\x22\x0d\x0a\
       y=\x221006.2\
909\x22\x0d\x0a       ry=\
\x2210.186751\x22 />\x0d\x0a\
    <path\x0d\x0a     \
  style=\x22fill:no\
ne;fill-rule:eve\
nodd;stroke:#999\
999;stroke-width\
:3;stroke-lineca\
p:butt;stroke-li\
nejoin:miter;str\
oke-miterlimit:4\
;stroke-dasharra\
y:none;stroke-op\
acity:1\x22\x0d\x0a      \
 d=\x22M 8.0812208,\
1040.6192 H 22.2\
23356\x22\x0d\x0a       i\
d=\x22path817\x22\x0d\x0a   \
    inkscape:con\
nector-curvature\
=\x220\x22\x0d\x0a       sod\
ipodi:nodetypes=\
\x22cc\x22 />\x0d\x0a  </g>\x0d\
\x0a</svg>\x0d\x0a\
\x00\x00\x08\x97\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22b\
ars.svg\x22\x0d\x0a   ink\
scape:version=\x220\
.92.2 (5c3e80d, \
2017-08-06)\x22>\x0d\x0a \
 <metadata\x0d\x0a    \
 id=\x22metadata8\x22>\
\x0d\x0a    <rdf:RDF>\x0d\
\x0a      <cc:Work\x0d\
\x0a         rdf:ab\
out=\x22\x22>\x0d\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0d\x0a        <\
dc:type\x0d\x0a       \
    rdf:resource\
=\x22http://purl.or\
g/dc/dcmitype/St\
illImage\x22 />\x0d\x0a  \
      <dc:title \
/>\x0d\x0a      </cc:W\
ork>\x0d\x0a    </rdf:\
RDF>\x0d\x0a  </metada\
ta>\x0d\x0a  <defs\x0d\x0a  \
   id=\x22defs6\x22 />\
\x0d\x0a  <sodipodi:na\
medview\x0d\x0a     pa\
gecolor=\x22#ffffff\
\x22\x0d\x0a     borderco\
lor=\x22#666666\x22\x0d\x0a \
    borderopacit\
y=\x221\x22\x0d\x0a     obje\
cttolerance=\x2210\x22\
\x0d\x0a     gridtoler\
ance=\x2210\x22\x0d\x0a     \
guidetolerance=\x22\
10\x22\x0d\x0a     inksca\
pe:pageopacity=\x22\
0\x22\x0d\x0a     inkscap\
e:pageshadow=\x222\x22\
\x0d\x0a     inkscape:\
window-width=\x2278\
4\x22\x0d\x0a     inkscap\
e:window-height=\
\x22480\x22\x0d\x0a     id=\x22\
namedview4\x22\x0d\x0a   \
  showgrid=\x22fals\
e\x22\x0d\x0a     inkscap\
e:zoom=\x221.229166\
7\x22\x0d\x0a     inkscap\
e:cx=\x22-47.999997\
\x22\x0d\x0a     inkscape\
:cy=\x2296.000003\x22\x0d\
\x0a     inkscape:w\
indow-x=\x2257\x22\x0d\x0a  \
   inkscape:wind\
ow-y=\x2227\x22\x0d\x0a     \
inkscape:window-\
maximized=\x220\x22\x0d\x0a \
    inkscape:cur\
rent-layer=\x22svg2\
\x22 />\x0d\x0a  <path\x0d\x0a \
    style=\x22fill:\
#999999;stroke-w\
idth:1.33333337\x22\
\x0d\x0a     d=\x22m 34,1\
67.5618 c -1.466\
667,-0.6178 -4.1\
66667,-2.73724 -\
6,-4.70985 l -3.\
333333,-3.58656 \
V 96.731782 34.1\
98175 L 29.02564\
1,29.8392 33.384\
616,25.480226 H \
96 158.61539 l 4\
.35897,4.358974 \
4.35897,4.358975\
 v 62.615384 62.\
615391 l -4.3579\
8,4.35897 -4.358\
,4.35897 -60.975\
342,0.2691 C 64.\
105569,168.56399\
 35.466667,168.1\
7961 34,167.5618\
 Z M 72,108.8135\
6 V 80.813559 h \
-8 -8 v 28.00000\
1 28 h 8 8 z m 3\
2,-12.000001 v -\
40 h -8 -8 v 40 \
40.000001 h 8 8 \
z m 32,24.000001\
 v -16 h -8 -8 v\
 16 16 h 8 8 z\x22\x0d\
\x0a     id=\x22path81\
7\x22\x0d\x0a     inkscap\
e:connector-curv\
ature=\x220\x22 />\x0d\x0a</\
svg>\x0d\x0a\
\x00\x00\x08\xac\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22n\
ew2c.svg\x22\x0d\x0a   in\
kscape:version=\x22\
0.92.2 (5c3e80d,\
 2017-08-06)\x22>\x0d\x0a\
  <metadata\x0d\x0a   \
  id=\x22metadata8\x22\
>\x0d\x0a    <rdf:RDF>\
\x0d\x0a      <cc:Work\
\x0d\x0a         rdf:a\
bout=\x22\x22>\x0d\x0a      \
  <dc:format>ima\
ge/svg+xml</dc:f\
ormat>\x0d\x0a        \
<dc:type\x0d\x0a      \
     rdf:resourc\
e=\x22http://purl.o\
rg/dc/dcmitype/S\
tillImage\x22 />\x0d\x0a \
       <dc:title\
 />\x0d\x0a      </cc:\
Work>\x0d\x0a    </rdf\
:RDF>\x0d\x0a  </metad\
ata>\x0d\x0a  <defs\x0d\x0a \
    id=\x22defs6\x22 /\
>\x0d\x0a  <sodipodi:n\
amedview\x0d\x0a     p\
agecolor=\x22#fffff\
f\x22\x0d\x0a     borderc\
olor=\x22#666666\x22\x0d\x0a\
     borderopaci\
ty=\x221\x22\x0d\x0a     obj\
ecttolerance=\x2210\
\x22\x0d\x0a     gridtole\
rance=\x2210\x22\x0d\x0a    \
 guidetolerance=\
\x2210\x22\x0d\x0a     inksc\
ape:pageopacity=\
\x220\x22\x0d\x0a     inksca\
pe:pageshadow=\x222\
\x22\x0d\x0a     inkscape\
:window-width=\x221\
617\x22\x0d\x0a     inksc\
ape:window-heigh\
t=\x22628\x22\x0d\x0a     id\
=\x22namedview4\x22\x0d\x0a \
    showgrid=\x22fa\
lse\x22\x0d\x0a     inksc\
ape:zoom=\x221.2291\
667\x22\x0d\x0a     inksc\
ape:cx=\x22-192\x22\x0d\x0a \
    inkscape:cy=\
\x2296.000006\x22\x0d\x0a   \
  inkscape:windo\
w-x=\x2257\x22\x0d\x0a     i\
nkscape:window-y\
=\x2227\x22\x0d\x0a     inks\
cape:window-maxi\
mized=\x220\x22\x0d\x0a     \
inkscape:current\
-layer=\x22svg2\x22 />\
\x0d\x0a  <path\x0d\x0a     \
style=\x22fill:#6f7\
c91;stroke-width\
:1.33333337\x22\x0d\x0a  \
   d=\x22m 42,172.3\
1016 c -1.466667\
,-0.61924 -4.166\
667,-2.73984 -6,\
-4.71245 l -3.33\
3333,-3.58656 V \
93.477545 22.943\
938 l 4.35676,-4\
.358975 4.356761\
,-4.358974 34.97\
6572,-0.378076 3\
4.97657,-0.37807\
6 24.37995,24.43\
7904 24.37995,24\
.437905 -0.37995\
,50.915854 -0.37\
995,50.91586 -4.\
35774,4.35764 -4\
.35775,4.35765 -\
52.975588,0.2717\
 C 68.50568,173.\
31379 43.466667,\
172.9294 42,172.\
31016 Z M 148,69\
.210834 c 0,-0.1\
91669 -9.9,-10.2\
34849 -22,-22.31\
8179 l -22,-21.9\
6969 v 22.318178\
 22.318179 h 22 \
c 12.1,0 22,-0.1\
5682 22,-0.34848\
8 z\x22\x0d\x0a     id=\x22p\
ath817\x22\x0d\x0a     in\
kscape:connector\
-curvature=\x220\x22 /\
>\x0d\x0a</svg>\x0d\x0a\
\x00\x00\x08B\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<svg\x0d\x0a   \
xmlns:dc=\x22http:/\
/purl.org/dc/ele\
ments/1.1/\x22\x0d\x0a   \
xmlns:cc=\x22http:/\
/creativecommons\
.org/ns#\x22\x0d\x0a   xm\
lns:rdf=\x22http://\
www.w3.org/1999/\
02/22-rdf-syntax\
-ns#\x22\x0d\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
\x0d\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0d\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0d\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0d\x0a   width=\x2248\x22\x0d\
\x0a   height=\x2248\x22\x0d\
\x0a   viewBox=\x220 0\
 48 48\x22\x0d\x0a   vers\
ion=\x221.1\x22\x0d\x0a   id\
=\x22svg4\x22\x0d\x0a   sodi\
podi:docname=\x22ch\
eck_all.svg\x22\x0d\x0a  \
 inkscape:versio\
n=\x220.92.3 (24055\
46, 2018-03-11)\x22\
>\x0d\x0a  <metadata\x0d\x0a\
     id=\x22metadat\
a10\x22>\x0d\x0a    <rdf:\
RDF>\x0d\x0a      <cc:\
Work\x0d\x0a         r\
df:about=\x22\x22>\x0d\x0a  \
      <dc:format\
>image/svg+xml</\
dc:format>\x0d\x0a    \
    <dc:type\x0d\x0a  \
         rdf:res\
ource=\x22http://pu\
rl.org/dc/dcmity\
pe/StillImage\x22 /\
>\x0d\x0a      </cc:Wo\
rk>\x0d\x0a    </rdf:R\
DF>\x0d\x0a  </metadat\
a>\x0d\x0a  <defs\x0d\x0a   \
  id=\x22defs8\x22 />\x0d\
\x0a  <sodipodi:nam\
edview\x0d\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0d\x0a     bordercol\
or=\x22#666666\x22\x0d\x0a  \
   borderopacity\
=\x221\x22\x0d\x0a     objec\
ttolerance=\x2210\x22\x0d\
\x0a     gridtolera\
nce=\x2210\x22\x0d\x0a     g\
uidetolerance=\x221\
0\x22\x0d\x0a     inkscap\
e:pageopacity=\x220\
\x22\x0d\x0a     inkscape\
:pageshadow=\x222\x22\x0d\
\x0a     inkscape:w\
indow-width=\x22185\
1\x22\x0d\x0a     inkscap\
e:window-height=\
\x221025\x22\x0d\x0a     id=\
\x22namedview6\x22\x0d\x0a  \
   showgrid=\x22fal\
se\x22\x0d\x0a     inksca\
pe:zoom=\x224.91666\
67\x22\x0d\x0a     inksca\
pe:cx=\x22-78.05751\
7\x22\x0d\x0a     inkscap\
e:cy=\x2224\x22\x0d\x0a     \
inkscape:window-\
x=\x2269\x22\x0d\x0a     ink\
scape:window-y=\x22\
27\x22\x0d\x0a     inksca\
pe:window-maximi\
zed=\x221\x22\x0d\x0a     in\
kscape:current-l\
ayer=\x22svg4\x22 />\x0d\x0a\
  <rect\x0d\x0a     st\
yle=\x22opacity:0.3\
28;fill:none;str\
oke:#000000;stro\
ke-width:3;strok\
e-miterlimit:4;s\
troke-dasharray:\
none;stroke-opac\
ity:1\x22\x0d\x0a     id=\
\x22rect818\x22\x0d\x0a     \
width=\x2238.033897\
\x22\x0d\x0a     height=\x22\
39.254238\x22\x0d\x0a    \
 x=\x225.0847454\x22\x0d\x0a\
     y=\x224.677966\
1\x22\x0d\x0a     ry=\x225.8\
983049\x22 />\x0d\x0a  <p\
ath\x0d\x0a     style=\
\x22fill:#00d4aa;fi\
ll-rule:evenodd;\
stroke:#00d4aa;s\
troke-width:1.04\
499948px;stroke-\
linecap:butt;str\
oke-linejoin:mit\
er;stroke-opacit\
y:1\x22\x0d\x0a     d=\x22M \
8.5033805,21.366\
378 18.917951,34\
.543999 46.33590\
5,11.164348 42.2\
97602,8.4012989 \
20.193204,24.979\
595 12.754225,20\
.091123 Z\x22\x0d\x0a    \
 id=\x22path815\x22\x0d\x0a \
    inkscape:con\
nector-curvature\
=\x220\x22 />\x0d\x0a</svg>\x0d\
\x0a\
\x00\x00\x07\xd6\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0d\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0d\x0a \
  version=\x221.1\x22\x0d\
\x0a   id=\x22svg2\x22\x0d\x0a \
  width=\x22192\x22\x0d\x0a \
  height=\x22192\x22\x0d\x0a\
   viewBox=\x220 0 \
192 192\x22\x0d\x0a   sod\
ipodi:docname=\x22s\
ave.svg\x22\x0d\x0a   ink\
scape:version=\x220\
.92.4 (unknown)\x22\
>\x0d\x0a  <metadata\x0d\x0a\
     id=\x22metadat\
a8\x22>\x0d\x0a    <rdf:R\
DF>\x0d\x0a      <cc:W\
ork\x0d\x0a         rd\
f:about=\x22\x22>\x0d\x0a   \
     <dc:format>\
image/svg+xml</d\
c:format>\x0d\x0a     \
   <dc:type\x0d\x0a   \
        rdf:reso\
urce=\x22http://pur\
l.org/dc/dcmityp\
e/StillImage\x22 />\
\x0d\x0a        <dc:ti\
tle />\x0d\x0a      </\
cc:Work>\x0d\x0a    </\
rdf:RDF>\x0d\x0a  </me\
tadata>\x0d\x0a  <defs\
\x0d\x0a     id=\x22defs6\
\x22 />\x0d\x0a  <sodipod\
i:namedview\x0d\x0a   \
  pagecolor=\x22#ff\
ffff\x22\x0d\x0a     bord\
ercolor=\x22#666666\
\x22\x0d\x0a     borderop\
acity=\x221\x22\x0d\x0a     \
objecttolerance=\
\x2210\x22\x0d\x0a     gridt\
olerance=\x2210\x22\x0d\x0a \
    guidetoleran\
ce=\x2210\x22\x0d\x0a     in\
kscape:pageopaci\
ty=\x220\x22\x0d\x0a     ink\
scape:pageshadow\
=\x222\x22\x0d\x0a     inksc\
ape:window-width\
=\x22902\x22\x0d\x0a     ink\
scape:window-hei\
ght=\x22480\x22\x0d\x0a     \
id=\x22namedview4\x22\x0d\
\x0a     showgrid=\x22\
false\x22\x0d\x0a     ink\
scape:zoom=\x221.22\
91667\x22\x0d\x0a     ink\
scape:cx=\x22-47.99\
9998\x22\x0d\x0a     inks\
cape:cy=\x2296.0000\
06\x22\x0d\x0a     inksca\
pe:window-x=\x2257\x22\
\x0d\x0a     inkscape:\
window-y=\x2227\x22\x0d\x0a \
    inkscape:win\
dow-maximized=\x220\
\x22\x0d\x0a     inkscape\
:current-layer=\x22\
svg2\x22 />\x0d\x0a  <pat\
h\x0d\x0a     style=\x22f\
ill:#999999;stro\
ke-width:1.33333\
337\x22\x0d\x0a     d=\x22m \
37.559322,153.62\
712 v -8 h 56 55\
.999998 v 8 8 h \
-55.999998 -56 z\
 m 28,-52.66667 \
-27.30894,-27.33\
3331 h 15.654471\
 15.654469 v -24\
 -24 h 24 23.999\
998 v 24 24 h 15\
.65447 15.65446 \
l -27.30893,27.3\
33331 c -15.0199\
2,15.03334 -27.6\
19918,27.33334 -\
27.999998,27.333\
34 -0.38008,0 -1\
2.98008,-12.3 -2\
8,-27.33334 z\x22\x0d\x0a\
     id=\x22path817\
\x22\x0d\x0a     inkscape\
:connector-curva\
ture=\x220\x22 />\x0d\x0a</s\
vg>\x0d\x0a\
\x00\x00\x0cY\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0d\x0a\x0d\x0a<svg\x0d\x0a   xml\
ns:dc=\x22http://pu\
rl.org/dc/elemen\
ts/1.1/\x22\x0d\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0d\x0a   xmlns\
:rdf=\x22http://www\
.w3.org/1999/02/\
22-rdf-syntax-ns\
#\x22\x0d\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22\x0d\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0d\x0a   xmlns:x\
link=\x22http://www\
.w3.org/1999/xli\
nk\x22\x0d\x0a   xmlns:so\
dipodi=\x22http://s\
odipodi.sourcefo\
rge.net/DTD/sodi\
podi-0.dtd\x22\x0d\x0a   \
xmlns:inkscape=\x22\
http://www.inksc\
ape.org/namespac\
es/inkscape\x22\x0d\x0a  \
 version=\x221.1\x22\x0d\x0a\
   id=\x22svg2\x22\x0d\x0a  \
 width=\x22192\x22\x0d\x0a  \
 height=\x22192\x22\x0d\x0a \
  viewBox=\x220 0 1\
92 192\x22\x0d\x0a   sodi\
podi:docname=\x22pi\
c.svg\x22\x0d\x0a   inksc\
ape:version=\x220.9\
2.3 (2405546, 20\
18-03-11)\x22>\x0d\x0a  <\
metadata\x0d\x0a     i\
d=\x22metadata8\x22>\x0d\x0a\
    <rdf:RDF>\x0d\x0a \
     <cc:Work\x0d\x0a \
        rdf:abou\
t=\x22\x22>\x0d\x0a        <\
dc:format>image/\
svg+xml</dc:form\
at>\x0d\x0a        <dc\
:type\x0d\x0a         \
  rdf:resource=\x22\
http://purl.org/\
dc/dcmitype/Stil\
lImage\x22 />\x0d\x0a    \
    <dc:title />\
\x0d\x0a      </cc:Wor\
k>\x0d\x0a    </rdf:RD\
F>\x0d\x0a  </metadata\
>\x0d\x0a  <defs\x0d\x0a    \
 id=\x22defs6\x22>\x0d\x0a  \
  <linearGradien\
t\x0d\x0a       inksca\
pe:collect=\x22alwa\
ys\x22\x0d\x0a       id=\x22\
linearGradient81\
6\x22>\x0d\x0a      <stop\
\x0d\x0a         style\
=\x22stop-color:#1d\
b090;stop-opacit\
y:1\x22\x0d\x0a         o\
ffset=\x220\x22\x0d\x0a     \
    id=\x22stop812\x22\
 />\x0d\x0a      <stop\
\x0d\x0a         style\
=\x22stop-color:#50\
9fd7;stop-opacit\
y:0.788\x22\x0d\x0a      \
   offset=\x221\x22\x0d\x0a \
        id=\x22stop\
814\x22 />\x0d\x0a    </l\
inearGradient>\x0d\x0a\
    <linearGradi\
ent\x0d\x0a       inks\
cape:collect=\x22al\
ways\x22\x0d\x0a       xl\
ink:href=\x22#linea\
rGradient816\x22\x0d\x0a \
      id=\x22linear\
Gradient820\x22\x0d\x0a  \
     gradientUni\
ts=\x22userSpaceOnU\
se\x22\x0d\x0a       x1=\x22\
97.887009\x22\x0d\x0a    \
   y1=\x22158.79446\
\x22\x0d\x0a       x2=\x2298\
.180786\x22\x0d\x0a      \
 y2=\x2239.201252\x22 \
/>\x0d\x0a  </defs>\x0d\x0a \
 <sodipodi:named\
view\x0d\x0a     pagec\
olor=\x22#ffffff\x22\x0d\x0a\
     bordercolor\
=\x22#666666\x22\x0d\x0a    \
 borderopacity=\x22\
1\x22\x0d\x0a     objectt\
olerance=\x2210\x22\x0d\x0a \
    gridtoleranc\
e=\x2210\x22\x0d\x0a     gui\
detolerance=\x2210\x22\
\x0d\x0a     inkscape:\
pageopacity=\x220\x22\x0d\
\x0a     inkscape:p\
ageshadow=\x222\x22\x0d\x0a \
    inkscape:win\
dow-width=\x221851\x22\
\x0d\x0a     inkscape:\
window-height=\x221\
025\x22\x0d\x0a     id=\x22n\
amedview4\x22\x0d\x0a    \
 showgrid=\x22false\
\x22\x0d\x0a     inkscape\
:zoom=\x221.2291667\
\x22\x0d\x0a     inkscape\
:cx=\x22-192\x22\x0d\x0a    \
 inkscape:cy=\x2296\
.000006\x22\x0d\x0a     i\
nkscape:window-x\
=\x2269\x22\x0d\x0a     inks\
cape:window-y=\x222\
7\x22\x0d\x0a     inkscap\
e:window-maximiz\
ed=\x221\x22\x0d\x0a     ink\
scape:current-la\
yer=\x22svg2\x22 />\x0d\x0a \
 <path\x0d\x0a     sty\
le=\x22fill:url(#li\
nearGradient820)\
;stroke-width:1.\
33333337;fill-op\
acity:1\x22\x0d\x0a     d\
=\x22m 34,170.00247\
 c -1.466667,-0.\
6178 -4.166667,-\
2.73724 -6,-4.70\
985 l -3.333333,\
-3.58656 V 99.17\
246 36.638853 l \
4.358974,-4.3589\
75 4.358975,-4.3\
58974 H 96 158.6\
1539 l 4.35897,4\
.358974 4.35897,\
4.358975 v 62.61\
5384 62.615383 l\
 -4.35798,4.3589\
7 -4.358,4.35897\
 -60.975342,0.26\
91 C 64.105569,1\
71.00466 35.4666\
67,170.62028 34,\
170.00247 Z M 13\
4.51609,123.9209\
 c -9.63117,-12.\
83333 -17.99545,\
-23.33333 -18.58\
73,-23.33333 -0.\
59184,0 -6.89532\
,7.5 -14.00772,1\
6.66667 -7.11239\
9,9.16666 -13.40\
2486,16.66666 -1\
3.977969,16.6666\
6 -0.575482,0 -5\
.049877,-4.8 -9.\
943101,-10.66667\
 -4.893224,-5.86\
666 -9.395195,-1\
0.66666 -10.0043\
81,-10.66666 -0.\
609186,0 -5.1742\
63,5.25 -10.1446\
15,11.66666 -4.9\
70352,6.41667 -1\
1.092431,14.2166\
7 -13.60462,17.3\
3333 l -4.567616\
,5.66667 h 56.17\
4268 56.174274 z\
\x22\x0d\x0a     id=\x22path\
817\x22\x0d\x0a     inksc\
ape:connector-cu\
rvature=\x220\x22 />\x0d\x0a\
</svg>\x0d\x0a\
"

qt_resource_name = b"\
\x00\x05\
\x00O\xa6S\
\x00I\
\x00c\x00o\x00n\x00s\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x08\
\x03\xc6T'\
\x00p\
\x00l\x00u\x00s\x00.\x00s\x00v\x00g\
\x00\x08\
\x06\xe1W\xa7\
\x00d\
\x00o\x00w\x00n\x00.\x00s\x00v\x00g\
\x00\x0f\
\x00 ['\
\x00p\
\x00l\x00u\x00s\x00 \x00(\x00g\x00r\x00a\x00y\x00)\x00.\x00s\x00v\x00g\
\x00\x09\
\x0b\x98\xb7'\
\x00p\
\x00i\x00e\x00c\x00e\x00.\x00s\x00v\x00g\
\x00\x08\
\x04\xb2UG\
\x00u\
\x00n\x00d\x00o\x00.\x00s\x00v\x00g\
\x00\x08\
\x0b\x85Wg\
\x00g\
\x00e\x00a\x00r\x00.\x00s\x00v\x00g\
\x00\x08\
\x03gT'\
\x00p\
\x00l\x00o\x00t\x00.\x00s\x00v\x00g\
\x00\x0a\
\x01\x0bC\x87\
\x00r\
\x00e\x00s\x00i\x00z\x00e\x00.\x00s\x00v\x00g\
\x00\x0c\
\x09\xcd\xaeg\
\x00l\
\x00o\x00a\x00d\x00_\x00a\x00d\x00d\x00.\x00s\x00v\x00g\
\x00\x08\
\x0b\xb2U\xc7\
\x00r\
\x00e\x00d\x00o\x00.\x00s\x00v\x00g\
\x00\x0e\
\x01'M\x07\
\x00c\
\x00l\x00e\x00a\x00r\x00_\x00r\x00u\x00n\x00s\x00.\x00s\x00v\x00g\
\x00\x0d\
\x02.\xca\x07\
\x00c\
\x00o\x00p\x00y\x002\x00d\x00o\x00w\x00n\x00.\x00s\x00v\x00g\
\x00\x11\
\x00\x16|'\
\x00a\
\x00r\x00e\x00a\x00_\x00t\x00r\x00a\x00n\x00s\x00f\x00e\x00r\x00.\x00s\x00v\x00g\
\
\x00\x06\
\x07\xc3Z\xc7\
\x00u\
\x00p\x00.\x00s\x00v\x00g\
\x00\x07\
\x04\xcaZ'\
\x00n\
\x00e\x00w\x00.\x00s\x00v\x00g\
\x00\x09\
\x07\xa6\xbcg\
\x00l\
\x00o\x00a\x00d\x00c\x00.\x00s\x00v\x00g\
\x00\x11\
\x0b;\xcc'\
\x00i\
\x00m\x00p\x00o\x00r\x00t\x00_\x00m\x00o\x00d\x00e\x00l\x00s\x00.\x00s\x00v\x00g\
\
\x00\x09\
\x08\xb6\xaf\x87\
\x00s\
\x00t\x00a\x00t\x00s\x00.\x00s\x00v\x00g\
\x00\x0e\
\x0b0\xc5\xa7\
\x00c\
\x00a\x00l\x00c\x00u\x00l\x00a\x00t\x00o\x00r\x00.\x00s\x00v\x00g\
\x00\x0a\
\x0c\xad\x02\x87\
\x00d\
\x00e\x00l\x00e\x00t\x00e\x00.\x00s\x00v\x00g\
\x00\x0e\
\x04\x9aK\x87\
\x00c\
\x00o\x00l\x00o\x00r\x00_\x00g\x00r\x00i\x00d\x00.\x00s\x00v\x00g\
\x00\x0d\
\x06m0\xa7\
\x00h\
\x00i\x00s\x00t\x00o\x00g\x00r\x00a\x00m\x00.\x00s\x00v\x00g\
\x00\x08\
\x0b\x07W\xa7\
\x00e\
\x00d\x00i\x00t\x00.\x00s\x00v\x00g\
\x00\x08\
\x08\xc9T'\
\x00p\
\x00r\x00e\x00v\x00.\x00s\x00v\x00g\
\x00\x14\
\x0b3\xdd\x87\
\x00a\
\x00u\x00t\x00o\x00m\x00a\x00t\x00i\x00c\x00_\x00l\x00a\x00y\x00o\x00u\x00t\x00.\
\x00s\x00v\x00g\
\x00\x0a\
\x0c\xafw\xe7\
\x00r\
\x00o\x00s\x00e\x00t\x00a\x00.\x00s\x00v\x00g\
\x00\x0d\
\x0d\xa5]G\
\x00C\
\x00a\x00t\x00a\x00l\x00o\x00g\x00u\x00e\x00.\x00s\x00v\x00g\
\x00\x0b\
\x0aP\xdfG\
\x00d\
\x00e\x00l\x00e\x00t\x00e\x002\x00.\x00s\x00v\x00g\
\x00\x13\
\x0f-z\xc7\
\x00i\
\x00m\x00p\x00o\x00r\x00t\x00_\x00p\x00r\x00o\x00f\x00i\x00l\x00e\x00s\x00.\x00s\
\x00v\x00g\
\x00\x0e\
\x01\x0eq\xa7\
\x00c\
\x00o\x00p\x00y\x002\x00r\x00i\x00g\x00h\x00t\x00.\x00s\x00v\x00g\
\x00\x14\
\x0f\xaf \xc7\
\x00m\
\x00a\x00g\x00n\x00i\x00f\x00y\x00i\x00n\x00g\x00_\x00g\x00l\x00a\x00s\x00s\x00.\
\x00s\x00v\x00g\
\x00\x15\
\x0a\xf2\xfb'\
\x00m\
\x00a\x00g\x00n\x00i\x00f\x00y\x00i\x00n\x00g\x00_\x00g\x00l\x00a\x00s\x00s\x002\
\x00.\x00s\x00v\x00g\
\x00\x11\
\x04\xdbX'\
\x00e\
\x00x\x00p\x00o\x00r\x00t\x00_\x00p\x00i\x00c\x00k\x00l\x00e\x00.\x00s\x00v\x00g\
\
\x00\x09\
\x05\x9e\x8e\xa7\
\x00c\
\x00l\x00o\x00c\x00k\x00.\x00s\x00v\x00g\
\x00\x08\
\x0c\xf7TG\
\x00n\
\x00e\x00x\x00t\x00.\x00s\x00v\x00g\
\x00\x08\
\x0c\xa5TG\
\x00n\
\x00e\x00w\x002\x00.\x00s\x00v\x00g\
\x00\x15\
\x0d\x18\x91g\
\x00i\
\x00n\x00p\x00u\x00t\x00s\x00_\x00a\x00n\x00a\x00l\x00y\x00s\x00i\x00s\x00 \x002\
\x00.\x00s\x00v\x00g\
\x00\x0d\
\x09\xcb\xdc'\
\x00s\
\x00c\x00h\x00e\x00m\x00a\x00t\x00i\x00c\x00.\x00s\x00v\x00g\
\x00\x0a\
\x00l\xe3\x87\
\x00f\
\x00u\x00s\x00i\x00o\x00n\x00.\x00s\x00v\x00g\
\x00\x08\
\x06|W\x87\
\x00c\
\x00o\x00p\x00y\x00.\x00s\x00v\x00g\
\x00\x14\
\x09 i\x07\
\x00r\
\x00u\x00n\x00_\x00c\x00a\x00s\x00c\x00a\x00d\x00e\x00_\x00s\x00t\x00e\x00p\x00.\
\x00s\x00v\x00g\
\x00\x09\
\x0a\xa8\xb7\xc7\
\x00p\
\x00a\x00s\x00t\x00e\x00.\x00s\x00v\x00g\
\x00\x0b\
\x083M\xc7\
\x00s\
\x00q\x00u\x00a\x00r\x00e\x00s\x00.\x00s\x00v\x00g\
\x00\x0b\
\x09\x17\x95G\
\x00c\
\x00o\x00p\x00y\x002\x00u\x00p\x00.\x00s\x00v\x00g\
\x00\x09\
\x08\x8c\x8b\xe7\
\x00a\
\x00r\x00r\x00a\x00y\x00.\x00s\x00v\x00g\
\x00\x0d\
\x0f\x18\xc9'\
\x00c\
\x00o\x00p\x00y\x002\x00l\x00e\x00f\x00t\x00.\x00s\x00v\x00g\
\x00\x09\
\x0c\xb6\xa9\xc7\
\x00s\
\x00a\x00v\x00e\x00c\x00.\x00s\x00v\x00g\
\x00\x10\
\x00\x04\x86\xa7\
\x00m\
\x00i\x00n\x00u\x00s\x00 \x00(\x00g\x00r\x00a\x00y\x00)\x00.\x00s\x00v\x00g\
\x00\x08\
\x05wT\xa7\
\x00l\
\x00o\x00a\x00d\x00.\x00s\x00v\x00g\
\x00\x08\
\x08\xa4W\x87\
\x00d\
\x00a\x00t\x00a\x00.\x00s\x00v\x00g\
\x00\x09\
\x05\xc6\xb2\xc7\
\x00m\
\x00i\x00n\x00u\x00s\x00.\x00s\x00v\x00g\
\x00\x0f\
\x07\xf8iG\
\x00u\
\x00n\x00c\x00h\x00e\x00c\x00k\x00_\x00a\x00l\x00l\x00.\x00s\x00v\x00g\
\x00\x0a\
\x06\x99R'\
\x00i\
\x00m\x00p\x00o\x00r\x00t\x00.\x00s\x00v\x00g\
\x00\x0b\
\x06\xf4\x91\x87\
\x00c\
\x00o\x00n\x00s\x00o\x00l\x00e\x00.\x00s\x00v\x00g\
\x00\x08\
\x08\x96W\xc7\
\x00b\
\x00a\x00r\x00s\x00.\x00s\x00v\x00g\
\x00\x09\
\x0a\x86\xb3G\
\x00n\
\x00e\x00w\x002\x00c\x00.\x00s\x00v\x00g\
\x00\x0d\
\x07\xf8\x19\xc7\
\x00c\
\x00h\x00e\x00c\x00k\x00_\x00a\x00l\x00l\x00.\x00s\x00v\x00g\
\x00\x08\
\x08\xc8U\xe7\
\x00s\
\x00a\x00v\x00e\x00.\x00s\x00v\x00g\
\x00\x07\
\x06\xf6Z'\
\x00p\
\x00i\x00c\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x10\x00\x02\x00\x00\x00;\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x05\x94\x00\x00\x00\x00\x00\x01\x00\x01\xd6\xa5\
\x00\x00\x01\x8e4\x85\xffo\
\x00\x00\x01Z\x00\x00\x00\x00\x00\x01\x00\x00\x82\xff\
\x00\x00\x01\x8e4\x85\xffL\
\x00\x00\x00L\x00\x00\x00\x00\x00\x01\x00\x00\x10\xed\
\x00\x00\x01\x8e4\x85\xffz\
\x00\x00\x04\x96\x00\x00\x00\x00\x00\x01\x00\x01\x89\x94\
\x00\x00\x01\x8e4\x85\xffc\
\x00\x00\x00\xca\x00\x00\x00\x00\x00\x01\x00\x00Ln\
\x00\x00\x01\x8e4\x85\xff~\
\x00\x00\x03Z\x00\x00\x00\x00\x00\x01\x00\x01;\x96\
\x00\x00\x01\x8e4\x85\xff[\
\x00\x00\x01\x18\x00\x00\x00\x00\x00\x01\x00\x00m\xc9\
\x00\x00\x01\x8e4\x85\xffU\
\x00\x00\x01:\x00\x00\x00\x00\x00\x01\x00\x00w\xa0\
\x00\x00\x01\x8e4\x85\xffZ\
\x00\x00\x00\xb4\x00\x00\x00\x00\x00\x01\x00\x00<w\
\x00\x00\x01\x8e4\x85\xffz\
\x00\x00\x00 \x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x8e4\x85\xffz\
\x00\x00\x02<\x00\x01\x00\x00\x00\x01\x00\x00\xd5`\
\x00\x00\x01\x8e4\x85\xffV\
\x00\x00\x00\x88\x00\x00\x00\x00\x00\x01\x00\x00!\xb7\
\x00\x00\x01\x8e4\x85\xff\x87\
\x00\x00\x01\x94\x00\x00\x00\x00\x00\x01\x00\x00\x99\x0d\
\x00\x00\x01\x8e4\x85\xffq\
\x00\x00\x03\xda\x00\x00\x00\x00\x00\x01\x00\x01[3\
\x00\x00\x01\x8e4\x85\xffa\
\x00\x00\x05\xba\x00\x00\x00\x00\x00\x01\x00\x01\xde}\
\x00\x00\x01\x8e4\x85\xffj\
\x00\x00\x04\x02\x00\x01\x00\x00\x00\x01\x00\x01e\xc5\
\x00\x00\x01\x8e4\x85\xffU\
\x00\x00\x05\xe6\x00\x00\x00\x00\x00\x01\x00\x01\xec\xb1\
\x00\x00\x01\x8e4\x85\xffp\
\x00\x00\x02^\x00\x01\x00\x00\x00\x01\x00\x00\xdd\x07\
\x00\x00\x01\x8e4\x85\xffe\
\x00\x00\x04\xb0\x00\x00\x00\x00\x00\x01\x00\x01\x93\xea\
\x00\x00\x01\x8e4\x85\xffY\
\x00\x00\x06\x22\x00\x00\x00\x00\x00\x01\x00\x01\xfb\x83\
\x00\x00\x01\x8e4\x85\xfff\
\x00\x00\x006\x00\x00\x00\x00\x00\x01\x00\x00\x09/\
\x00\x00\x01\x8e4\x85\xff`\
\x00\x00\x06<\x00\x00\x00\x00\x00\x01\x00\x02\x03/\
\x00\x00\x01\x8e4\x85\xffV\
\x00\x00\x06\xbc\x00\x00\x00\x00\x00\x01\x00\x02-\xc8\
\x00\x00\x01\x8e4\x85\xffy\
\x00\x00\x01\xa8\x00\x00\x00\x00\x00\x01\x00\x00\xa2\xf1\
\x00\x00\x01\x8e4\x85\xffk\
\x00\x00\x01\x82\x00\x00\x00\x00\x00\x01\x00\x00\x91\x9c\
\x00\x00\x01\x8e4\x85\xff\x88\
\x00\x00\x06\x86\x00\x00\x00\x00\x00\x01\x00\x02\x1d\xa8\
\x00\x00\x01\x8e4\x85\xffS\
\x00\x00\x05\xfe\x00\x00\x00\x00\x00\x01\x00\x01\xf4\x82\
\x00\x00\x01\x8e4\x85\xff\x86\
\x00\x00\x05\x0c\x00\x00\x00\x00\x00\x01\x00\x01\xab\x96\
\x00\x00\x01\x8e4\x85\xff\x81\
\x00\x00\x05D\x00\x01\x00\x00\x00\x01\x00\x01\xbe\xc8\
\x00\x00\x01\x8e4\x85\xffM\
\x00\x00\x06X\x00\x00\x00\x00\x00\x01\x00\x02\x0c]\
\x00\x00\x01\x8e4\x85\xffP\
\x00\x00\x05\xd0\x00\x00\x00\x00\x00\x01\x00\x01\xe6:\
\x00\x00\x01\x8e4\x85\xff[\
\x00\x00\x01\xe8\x00\x00\x00\x00\x00\x01\x00\x00\xbd\xb7\
\x00\x00\x01\x8e4\x85\xff\x81\
\x00\x00\x06\xa6\x00\x00\x00\x00\x00\x01\x00\x02%\xee\
\x00\x00\x01\x8e4\x85\xff\x7f\
\x00\x00\x02\x94\x00\x00\x00\x00\x00\x01\x00\x00\xeat\
\x00\x00\x01\x8e4\x85\xff{\
\x00\x00\x05(\x00\x00\x00\x00\x00\x01\x00\x01\xb3w\
\x00\x00\x01\x8e4\x85\xff[\
\x00\x00\x04\xc6\x00\x00\x00\x00\x00\x01\x00\x01\x9d\x10\
\x00\x00\x01\x8e4\x85\xff~\
\x00\x00\x04v\x00\x01\x00\x00\x00\x01\x00\x01\x82\xbf\
\x00\x00\x01\x8e4\x85\xff\x7f\
\x00\x00\x00\xe4\x00\x00\x00\x00\x00\x01\x00\x00X\xfa\
\x00\x00\x01\x8e4\x85\xffj\
\x00\x00\x03\x12\x00\x00\x00\x00\x00\x01\x00\x01\x14\x8c\
\x00\x00\x01\x8e4\x85\xff^\
\x00\x00\x06n\x00\x00\x00\x00\x00\x01\x00\x02\x14\xf8\
\x00\x00\x01\x8e4\x85\xffr\
\x00\x00\x04\xf4\x00\x00\x00\x00\x00\x01\x00\x01\xa4\x8d\
\x00\x00\x01\x8e4\x85\xffw\
\x00\x00\x03\xaa\x00\x00\x00\x00\x00\x01\x00\x01Q\x15\
\x00\x00\x01\x8e4\x85\xffk\
\x00\x00\x02~\x00\x00\x00\x00\x00\x01\x00\x00\xe2\x17\
\x00\x00\x01\x8e4\x85\xffa\
\x00\x00\x02\x00\x00\x01\x00\x00\x00\x01\x00\x00\xc79\
\x00\x00\x01\x8e4\x85\xffR\
\x00\x00\x02\xaa\x00\x01\x00\x00\x00\x01\x00\x00\xf1\xec\
\x00\x00\x01\x8e4\x85\xffO\
\x00\x00\x01\xc0\x00\x00\x00\x00\x00\x01\x00\x00\xaa\xaa\
\x00\x00\x01\x8e4\x85\xffg\
\x00\x00\x00\x9e\x00\x00\x00\x00\x00\x01\x00\x00.\xdf\
\x00\x00\x01\x8e4\x85\xffc\
\x00\x00\x00p\x00\x00\x00\x00\x00\x01\x00\x00\x1ab\
\x00\x00\x01\x8e4\x85\xffy\
\x00\x00\x01\x02\x00\x00\x00\x00\x00\x01\x00\x00d\x0b\
\x00\x00\x01\x8e4\x85\xff|\
\x00\x00\x040\x00\x00\x00\x00\x00\x01\x00\x01q\xb3\
\x00\x00\x01\x8e4\x85\xffr\
\x00\x00\x02\x22\x00\x00\x00\x00\x00\x01\x00\x00\xcc\x0e\
\x00\x00\x01\x8e4\x85\xff\x5c\
\x00\x00\x02\xd8\x00\x00\x00\x00\x00\x01\x00\x00\xf9\x0d\
\x00\x00\x01\x8e4\x85\xff~\
\x00\x00\x05|\x00\x00\x00\x00\x00\x01\x00\x01\xce\x8a\
\x00\x00\x01\x8e4\x85\xff\x7f\
\x00\x00\x04\x1a\x00\x00\x00\x00\x00\x01\x00\x01j,\
\x00\x00\x01\x8e4\x85\xffs\
\x00\x00\x04F\x00\x01\x00\x00\x00\x01\x00\x01zg\
\x00\x00\x01\x8e4\x85\xffg\
\x00\x00\x02\xf2\x00\x00\x00\x00\x00\x01\x00\x01\x0b\x0a\
\x00\x00\x01\x8e4\x85\xffF\
\x00\x00\x05\x5c\x00\x00\x00\x00\x00\x01\x00\x01\xc3\x22\
\x00\x00\x01\x8e4\x85\xffZ\
\x00\x00\x03.\x00\x00\x00\x00\x00\x01\x00\x01#\x00\
\x00\x00\x01\x8e4\x85\xffg\
\x00\x00\x03|\x00\x00\x00\x00\x00\x01\x00\x01F\xff\
\x00\x00\x01\x8e4\x85\xffk\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
